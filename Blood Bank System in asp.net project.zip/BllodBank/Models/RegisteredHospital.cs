﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace BllodBank.Models
{
    public class RegisteredHospital
    {
        [Key]
        public int Id { get; set; }
        [Required]
        [StringLength(100, MinimumLength = 6,
        ErrorMessage = "Name Should be minimum 6 characters and a maximum of 100 characters")]
        public string Hospitalname { get; set; }
        [Required(ErrorMessage = "You need enter Address.")]
        [DataType(DataType.MultilineText)]
        public string HospitalAddress { get; set; }
        [Required]
        public string OwnerShip { get; set; }
        [Required]
        [StringLength(11,
        ErrorMessage = "Number Must be 11 digits")]
        public string phone { get; set; }
        [Required]
        [RegularExpression("^[a-zA-Z0-9_\\.-]+@([a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,6}$", ErrorMessage = "E-mail is not valid")]
        public string Email { get; set; }
        [Required]
        public string City { get; set; }
    }
}