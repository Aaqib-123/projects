﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace BllodBank.Models
{
    public class RegisteredBloodBank
    {
        [Key]
        public int Id { get; set; }
        [Required]
        [StringLength(100, MinimumLength = 6,
        ErrorMessage = "Name Should be minimum 6 characters and a maximum of 100 characters")]
        public string BloodBankName { get; set; }
        [Required(ErrorMessage = "You need enter Address.")]
        [DataType(DataType.MultilineText)]
        public string BloodBankAddress { get; set; }
        [Required]
        [StringLength(11,
        ErrorMessage = "Number Must be 11 digits")]
        public string BloodBankphoneNumber { get; set; }
        [Required]
        [RegularExpression("^[a-zA-Z0-9_\\.-]+@([a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,6}$", ErrorMessage = "E-mail is not valid")]
        public string BloodBankEmail { get; set; }
        [Required]
        public string BloodBankCity { get; set; }
    }
}