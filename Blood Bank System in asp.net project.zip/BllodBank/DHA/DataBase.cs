﻿using BllodBank.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.ModelConfiguration.Conventions;
using System.Linq;
using System.Web;

namespace BllodBank.DHA
{
    public class DataBase :DbContext
    {
        public DataBase():base("DataBase5")
        {
            this.Configuration.ProxyCreationEnabled = false;
        }
        public DbSet<RegisteredHospital>registeredHospitals { get; set; }
        public DbSet<RegisteredBloodBank> registeredBloodBanks { get; set; }
       // public IQueryable<RegisteredBloodBank> RegisteredBloodBanks { get; internal set; }
        public IConvention[] PualrizingTabelNameconvention { get; private set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Conventions.Remove<PluralizingTableNameConvention>();
        }

    }
}