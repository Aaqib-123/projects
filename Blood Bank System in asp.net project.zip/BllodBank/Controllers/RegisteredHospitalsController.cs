﻿using BllodBank.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Web;
using System.Web.Mvc;

namespace BllodBank.Controllers
{
    public class RegisteredHospitalsController : Controller
    {
        // GET: RegisteredHospitals
        public ActionResult Index()
        {

            IEnumerable<Models.RegisteredHospital> registeredHospitals = null;
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("http://localhost:21222/api/");
                var responseTask = client.GetAsync("registeredHospitals");
                responseTask.Wait();

                var result = responseTask.Result;
                if (result.IsSuccessStatusCode)
                {
                    var readTask = result.Content.ReadAsAsync<IList<Models.RegisteredHospital>>();
                    readTask.Wait();

                    registeredHospitals = readTask.Result;
                }
                else
                {
                    registeredHospitals = Enumerable.Empty<Models.RegisteredHospital>();
                    ModelState.AddModelError(string.Empty, "Server Error. Please contact admin.");
                }
            }
            return View(registeredHospitals);
        }
            public ActionResult Create()
            {
                return View();
            }

        [HttpPost]
        public ActionResult Create(RegisteredHospital registeredHospitals)
        {
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("http://localhost:21222/api/");
                var postTask = client.PostAsJsonAsync<RegisteredHospital>("RegisteredHospitals", registeredHospitals);
                postTask.Wait();

                var result = postTask.Result;
                if (result.IsSuccessStatusCode)
                {
                    return RedirectToAction("Index");
                }
            }

            ModelState.AddModelError(string.Empty, "Server Error. Please contact admin.");

            return View(registeredHospitals);
        }

        public ActionResult Edit(string id)
        {
            RegisteredHospital registeredHospitals = null;

            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("http://localhost:21222/api/");

                var responseTask = client.GetAsync("registeredHospitals?id=" + id.ToString());
                responseTask.Wait();

                var result = responseTask.Result;
                if (result.IsSuccessStatusCode)
                {
                    var readTask = result.Content.ReadAsAsync<RegisteredHospital>();
                    readTask.Wait();

                    registeredHospitals = readTask.Result;
                }
            }

            return View(registeredHospitals);
        }

        [HttpPost]
        public ActionResult Edit(RegisteredHospital registeredHospitals)
        {
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("http://localhost:21222/api/");

                var putTask = client.PutAsJsonAsync("registeredHospitals?id=" + registeredHospitals.Id, registeredHospitals);
                putTask.Wait();

                var result = putTask.Result;
                if (result.IsSuccessStatusCode)
                {
                    return RedirectToAction("Index");
                }
            }
            return RedirectToAction("Index");
        }
        

        public ActionResult Delete(string id)
        {
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("http://localhost:21222/api/");

                var deleteTask = client.DeleteAsync("registeredHospitals/" + id.ToString());
                deleteTask.Wait();

                var result = deleteTask.Result;
                if (result.IsSuccessStatusCode)
                {
                    return RedirectToAction("Index");
                }
            }

            ModelState.AddModelError(string.Empty, "Server Error. Please contact admin.");

            return RedirectToAction("Index");
        }
    }
    }
