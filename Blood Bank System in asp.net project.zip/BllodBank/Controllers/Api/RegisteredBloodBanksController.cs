﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using BllodBank.DHA;
using BllodBank.Models;

namespace BllodBank.Controllers.Api
{
    public class RegisteredBloodBanksController : ApiController
    {
        private DataBase db = new DataBase();

        // GET: api/RegisteredBloodBanks
        public IQueryable<RegisteredBloodBank> GetRegisteredBloodBanks()
        {
            return db.registeredBloodBanks;
        }

        // GET: api/RegisteredBloodBanks/5
        [ResponseType(typeof(RegisteredBloodBank))]
        public IHttpActionResult GetRegisteredBloodBank(int id)
        {
            RegisteredBloodBank registeredBloodBank = db.registeredBloodBanks.Find(id);
            if (registeredBloodBank == null)
            {
                return NotFound();
            }

            return Ok(registeredBloodBank);
        }

        // PUT: api/RegisteredBloodBanks/5
        [ResponseType(typeof(void))]
        public IHttpActionResult PutRegisteredBloodBank(int id, RegisteredBloodBank registeredBloodBank)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != registeredBloodBank.Id)
            {
                return BadRequest();
            }

            db.Entry(registeredBloodBank).State = EntityState.Modified;

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!RegisteredBloodBankExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        // POST: api/RegisteredBloodBanks
        [ResponseType(typeof(RegisteredBloodBank))]
        public IHttpActionResult PostRegisteredBloodBank(RegisteredBloodBank registeredBloodBank)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            db.registeredBloodBanks.Add(registeredBloodBank);
            db.SaveChanges();

            return CreatedAtRoute("DefaultApi", new { id = registeredBloodBank.Id }, registeredBloodBank);
        }

        // DELETE: api/RegisteredBloodBanks/5
        [ResponseType(typeof(RegisteredBloodBank))]
        public IHttpActionResult DeleteRegisteredBloodBank(int id)
        {
            RegisteredBloodBank registeredBloodBank = db.registeredBloodBanks.Find(id);
            if (registeredBloodBank == null)
            {
                return NotFound();
            }

            db.registeredBloodBanks.Remove(registeredBloodBank);
            db.SaveChanges();

            return Ok(registeredBloodBank);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool RegisteredBloodBankExists(int id)
        {
            return db.registeredBloodBanks.Count(e => e.Id == id) > 0;
        }
    }
}