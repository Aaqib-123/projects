﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using BllodBank.DHA;
using BllodBank.Models;

namespace BllodBank.Controllers.Api
{
    public class RegisteredHospitalsController : ApiController
    {
        private DataBase db = new DataBase();

        // GET: api/RegisteredHospitals
        public IQueryable<RegisteredHospital> GetregisteredHospitals()
        {
            return db.registeredHospitals;
        }

        // GET: api/RegisteredHospitals/5
        [ResponseType(typeof(RegisteredHospital))]
        public IHttpActionResult GetRegisteredHospital(int id)
        {
            RegisteredHospital registeredHospital = db.registeredHospitals.Find(id);
            if (registeredHospital == null)
            {
                return NotFound();
            }

            return Ok(registeredHospital);
        }

        // PUT: api/RegisteredHospitals/5
        [ResponseType(typeof(void))]
        public IHttpActionResult PutRegisteredHospital(int id, RegisteredHospital registeredHospital)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != registeredHospital.Id)
            {
                return BadRequest();
            }

            db.Entry(registeredHospital).State = EntityState.Modified;

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!RegisteredHospitalExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        // POST: api/RegisteredHospitals
        [ResponseType(typeof(RegisteredHospital))]
        public IHttpActionResult PostRegisteredHospital(RegisteredHospital registeredHospital)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            db.registeredHospitals.Add(registeredHospital);
            db.SaveChanges();

            return CreatedAtRoute("DefaultApi", new { id = registeredHospital.Id }, registeredHospital);
        }

        // DELETE: api/RegisteredHospitals/5
        [ResponseType(typeof(RegisteredHospital))]
        public IHttpActionResult DeleteRegisteredHospital(int id)
        {
            RegisteredHospital registeredHospital = db.registeredHospitals.Find(id);
            if (registeredHospital == null)
            {
                return NotFound();
            }

            db.registeredHospitals.Remove(registeredHospital);
            db.SaveChanges();

            return Ok(registeredHospital);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool RegisteredHospitalExists(int id)
        {
            return db.registeredHospitals.Count(e => e.Id == id) > 0;
        }
    }
}