﻿using BllodBank.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Web;
using System.Web.Mvc;

namespace BllodBank.Controllers
{
    public class RegisteredBloodBanksController : Controller
    {
        // GET: RegisteredBloodBanks
        public ActionResult Index()
        {
            IEnumerable<Models.RegisteredBloodBank> registeredBloodBanks = null;
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("http://localhost:21222/api/");
                var responseTask = client.GetAsync("registeredBloodBanks");
                responseTask.Wait();

                var result = responseTask.Result;
                if (result.IsSuccessStatusCode)
                {
                    var readTask = result.Content.ReadAsAsync<IList<Models.RegisteredBloodBank>>();
                    readTask.Wait();

                    registeredBloodBanks= readTask.Result;
                }
                else
                {
                    registeredBloodBanks = Enumerable.Empty<Models.RegisteredBloodBank>();
                    ModelState.AddModelError(string.Empty, "Server Error. Please contact admin.");
                }
            }
            return View(registeredBloodBanks);
        }
        public ActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Create(Models.RegisteredBloodBank registereBloodBanks)
        {
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("http://localhost:21222/api/");
                var postTask = client.PostAsJsonAsync<RegisteredBloodBank>("RegisteredBloodBanks", registereBloodBanks);
                postTask.Wait();

                var result = postTask.Result;
                if (result.IsSuccessStatusCode)
                {
                    return RedirectToAction("Index");
                }
            }

            ModelState.AddModelError(string.Empty, "Server Error. Please contact admin.");

            return View(registereBloodBanks);
        }

        public ActionResult Edit(string id)
        {
            RegisteredBloodBank registeredBloodBanks = null;

            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("http://localhost:21222/api/");

                var responseTask = client.GetAsync("registeredBloodBanks?id=" + id.ToString());
                responseTask.Wait();

                var result = responseTask.Result;
                if (result.IsSuccessStatusCode)
                {
                    var readTask = result.Content.ReadAsAsync<RegisteredBloodBank>();
                    readTask.Wait();

                    registeredBloodBanks = readTask.Result;
                }
            }

            return View(registeredBloodBanks);
        }

        [HttpPost]
        public ActionResult Edit(RegisteredBloodBank registeredBloodBanks )
        {
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("http://localhost:21222/api/");

                var putTask = client.PutAsJsonAsync("registeredBloodBanks?id=" + registeredBloodBanks.Id, registeredBloodBanks);
                putTask.Wait();

                var result = putTask.Result;
                if (result.IsSuccessStatusCode)
                {
                    return RedirectToAction("Index");
                }
            }
            return RedirectToAction("Index");
        }

        public ActionResult Delete(string id)
        {
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("http://localhost:21222/api/");

                var deleteTask = client.DeleteAsync("registeredBloodBanks/" + id.ToString());
                deleteTask.Wait();

                var result = deleteTask.Result;
                if (result.IsSuccessStatusCode)
                {
                    return RedirectToAction("Index");
                }
            }

            ModelState.AddModelError(string.Empty, "Server Error. Please contact admin.");

            return RedirectToAction("Index");
        }
       
    }
    }
