import java.awt.*;

import javax.swing.*;
import javax.swing.border.*;

import net.proteanit.sql.DbUtils;

import java.sql.*;
import java.awt.event.*;
import java.io.*;

import com.jgoodies.forms.factories.DefaultComponentFactory;

import java.util.Date;

public class Admin_Menu extends JFrame {
	private JLabel dateLabel;
	private JLabel nameLabel;
	private JLabel lblAdminMenu ;
	
	int count=0;
	Connection con = null;
	PreparedStatement pst =null;
	ResultSet rs =null;
	private JPanel createAccount;
	private JPanel searchUser;
	private JPanel deleteUser;
	private JPanel updateUser;
	private JLabel lblFirstname;
	private JLabel lblLastname;
	private JLabel lblUsername;
	private JLabel lblAccountNumber;
	private JLabel lblNationalId;
	private JLabel lblPresentAddress;
	private JLabel lblPermanentAddress;
	
	private JTextField fname;
	private JTextField lname;
	private JTextField uname;
	private JTextField presentAdd;
	private JTextField cnic;
	private JTextField acnum;
	private JTextField perAdd;
	private JLabel lblEmailAddress;
	private JTextField email;
	private JTextField OpenDate;
	private JLabel lblOpeningDate;
	private JLabel lblAmount;
	private JTextField amount;
	private JTextField dobTxtField;
	private JLabel lblDateOfBirth;
	private JLabel lblNationality;
	private JSeparator separator_1;
	private JButton btnExit;

	String fileName = null;
	byte[] personImage = null;
	JLabel userImage;
	ByteArrayOutputStream bos;
	String s;
	
	private JButton attachImage;
	private JLabel lblGender;
	private JTextField phone;
	private JLabel lblAccountType;
	private JComboBox<Object> country;
	private JComboBox<Object> acType;
	private JRadioButton rdbtnMale;
	private JRadioButton rdbtnFemale;
	private JTextField password;
	
	long cnicNo =0;
	long phoneNo=0;
	long accoNo =0;
	long amo = 0;
	long oDate=0;
	long dobirth=0;
	String gender;
	String gen;
	int num =0;
	int accran =0;
	int pinran =0;
	int searchAccount =0;
	int delAccount =0;
	int ac=0;
	int newPin = 0;
	
	private JTextField pin;
	private JTextField upFname;
	private JTextField upLname;
	private JTextField upUname;
	private JTextField upCnic;
	private JTextField upPresAdd;
	private JTextField upPerAdd;
	private JTextField upEmail;
	private JComboBox upNation;
	private JTextField upDate;
	private JLabel label_1;
	private JLabel label_2;
	private JLabel label_3;
	private JLabel label_4;
	private JLabel label_5;
	private JLabel label_6;
	private JLabel label_7;
	private JLabel label_8;
	private JLabel label_9;
	private JLabel label_11;
	private JTextField upFone;
	private JLabel label_12;
	private JComboBox upType;
	private JLabel label_13;
	private JLabel label_15;
	private JTextField upPass;
	private JTextField upDob;
	private JLabel label_16;
	private JTextField upAcNum;
	
	String comboValueNation;
	String comboValueAcType;
	private JTable table;
	private JTable table2;
	private JScrollPane scrollPane;
	private JLabel createUserBackImageLabel;
	private JTextField upPin;
	JLabel getUpImage;
	private JTextField searchAccountNumber;
	private JTextField searchUsername;
	private JLabel searchUserBackImageLabel;
	private JLabel deleteUserBackImageLabel;
	private JButton btnSearchUserDetails;
	private JTextField delAcNo;
	private JLabel label_20;
	private JLabel lblUsername_1;
	private JTextField delUname;
	private JButton btnDeleteUser;
	private JTable serachUserData;
	
	Date date = new Date();
	String date1 = date.toString();
	private JScrollPane searchUserPane;
	private JLabel monTransBackImageLabel;
	private JTable moneyTrasnfer;
	private JScrollPane scrollPane_2;
	private JTable withdrawAmount;
	private JTable depositAmount;
	private JLabel label_19;
	private JLabel imageLabel;
	private JLabel label_17;
	private JLabel label_21;
	private JLabel label_22;
	private JLabel label_23;
	private JLabel label_24;
	private JLabel label_25;
	private JLabel logout;
	private JSeparator separator_3;
	private JSeparator separator_4;
	private JSeparator separator_5;
	private JSeparator separator_6;
	private JSeparator separator_7;
	
	
	
	public void DBConnection()
	{
		String driver = "com.mysql.jdbc.Driver";
		String url  = "jdbc:mysql://localhost:3306/bankManagementSystem";
		String user = "root";
		String pass = "";
		try 
		{
			Class.forName(driver);
			con = DriverManager.getConnection(url,user,pass);
		}
		catch (ClassNotFoundException | SQLException e) 
		{
			JOptionPane.showMessageDialog(this, "Connection Error !");
		}}
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			@Override
			public void run() {
				try {
					UIManager.setLookAndFeel("com.jtattoo.plaf.hifi.HiFiLookAndFeel");
					Admin_Menu frame = new Admin_Menu();
					frame.setVisible(true);
					frame.setTitle("Admin Menu");
				} catch (Exception e) {
					Authentication.main(null);
				}
			}
		});
	}
	
	public Admin_Menu(){
		setIconImage(Toolkit.getDefaultToolkit().getImage("Images\\logoIcon.png"));
		addMouseListener(new MouseAdapter() {
			@Override
			public void mouseReleased(MouseEvent arg0) {
				setOpacity(1.0f);
			}
		});
		addMouseMotionListener(new MouseMotionAdapter() {
			@Override
			public void mouseDragged(MouseEvent arg0) {
				setOpacity(0.7f);
			}
		});
		
		setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 1374, 675);
		setLocationRelativeTo(null);
		setTitle("Admin Menu");
		getContentPane().setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBounds(10, 11, 1348, 625);
		getContentPane().add(panel);
		panel.setLayout(null);
		
		JTabbedPane tabbedPane = new JTabbedPane(SwingConstants.TOP);
		tabbedPane.setFont(new Font("Serif", Font.PLAIN, 22));
		tabbedPane.setForeground(Color.BLACK);
		tabbedPane.setBounds(0, 115, 1338, 499);
		panel.add(tabbedPane);
		
		createAccount = new JPanel();
		createAccount.setForeground(Color.BLACK);
		createAccount.setBorder(new TitledBorder(new LineBorder(new Color(0, 0, 0), 1, true), "Create Account", TitledBorder.LEADING, TitledBorder.TOP, null, Color.WHITE));
		tabbedPane.addTab("Create Account", new ImageIcon("Images\\user-add-icon.png"), createAccount, null);
		tabbedPane.setEnabledAt(0, true);
		createAccount.setLayout(null);
		
		lblFirstname = new JLabel("Firstname");
		lblFirstname.setForeground(Color.WHITE);
		lblFirstname.setFont(new Font("Modern No. 20", Font.PLAIN, 20));
		lblFirstname.setBounds(10, 83, 93, 25);
		createAccount.add(lblFirstname);
		
		lblLastname = new JLabel("Lastname");
		lblLastname.setForeground(Color.WHITE);
		lblLastname.setFont(new Font("Modern No. 20", Font.PLAIN, 20));
		lblLastname.setBounds(10, 124, 88, 25);
		createAccount.add(lblLastname);
		
		lblUsername = new JLabel("Username");
		lblUsername.setForeground(Color.WHITE);
		lblUsername.setFont(new Font("Modern No. 20", Font.PLAIN, 20));
		lblUsername.setBounds(10, 165, 89, 25);
		createAccount.add(lblUsername);
		
		lblAccountNumber = new JLabel("Account Number");
		lblAccountNumber.setForeground(Color.WHITE);
		lblAccountNumber.setFont(new Font("Modern No. 20", Font.PLAIN, 20));
		lblAccountNumber.setBounds(10, 215, 149, 25);
		createAccount.add(lblAccountNumber);
		
		lblNationalId = new JLabel("National ID");
		lblNationalId.setForeground(Color.WHITE);
		lblNationalId.setFont(new Font("Modern No. 20", Font.PLAIN, 20));
		lblNationalId.setBounds(10, 253, 108, 25);
		createAccount.add(lblNationalId);
		
		lblPresentAddress = new JLabel("Present Address");
		lblPresentAddress.setForeground(Color.WHITE);
		lblPresentAddress.setFont(new Font("Modern No. 20", Font.PLAIN, 20));
		lblPresentAddress.setBounds(10, 294, 144, 25);
		createAccount.add(lblPresentAddress);
		
		lblPermanentAddress = new JLabel("Permanent Address");
		lblPermanentAddress.setForeground(Color.WHITE);
		lblPermanentAddress.setFont(new Font("Modern No. 20", Font.PLAIN, 20));
		lblPermanentAddress.setBounds(407, 90, 175, 25);
		createAccount.add(lblPermanentAddress);
		
		fname = new JTextField();
		fname.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent ke) {
				if(ke.getKeyChar()>='a' && ke.getKeyChar()<='z' || ke.getKeyChar() >= 'A' && ke.getKeyChar()<='Z'|| ke.getKeyChar()==' ')
				{
					
				}
				else
				{
					
					ke.consume();
					}
			}
		});
		fname.setFont(new Font("Times New Roman", Font.PLAIN, 18));
		fname.setBounds(185, 83, 195, 30);
		createAccount.add(fname);
		fname.setColumns(10);
		
		lname = new JTextField();
		lname.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent ke) {
				if(ke.getKeyChar()>='a' && ke.getKeyChar()<='z' || ke.getKeyChar() >= 'A' && ke.getKeyChar()<='Z'|| ke.getKeyChar()==' ')
				{
					
				}
				else
				{
					
					ke.consume();
					}
			}
		});
		lname.setFont(new Font("Times New Roman", Font.PLAIN, 18));
		lname.setColumns(10);
		lname.setBounds(185, 124, 195, 30);
		createAccount.add(lname);
		
		uname = new JTextField();
		uname.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent ke) {
				if(ke.getKeyChar()>='a' && ke.getKeyChar()<='z' || ke.getKeyChar() >= 'A' && ke.getKeyChar()<='Z'|| ke.getKeyChar()==' ')
				{
					
				}
				else
				{
					
					ke.consume();
					}
			}
		});
		uname.setFont(new Font("Times New Roman", Font.PLAIN, 18));
		uname.setColumns(10);
		uname.setBounds(185, 165, 195, 30);
		createAccount.add(uname);
		
		presentAdd = new JTextField();
		presentAdd.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent ke) {
				if(ke.getKeyChar()>='a' && ke.getKeyChar()<='z' || ke.getKeyChar() >= 'A' && ke.getKeyChar()<='Z'|| ke.getKeyChar()==' ')
				{
					
				}
				else
				{
					
					ke.consume();
					}
			}
		});
		presentAdd.setFont(new Font("Times New Roman", Font.PLAIN, 18));
		presentAdd.setColumns(10);
		presentAdd.setBounds(185, 294, 195, 30);
		createAccount.add(presentAdd);
		
		cnic = new JTextField(13);
		cnic.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent ke) {
				if(ke.getKeyChar()>='0' && ke.getKeyChar()<='9')
				{
					
				}
				else
				{
					
					ke.consume();
					}
			}		
			});
		cnic.setFont(new Font("Times New Roman", Font.PLAIN, 18));
		cnic.setColumns(10);
		cnic.setBounds(185, 253, 195, 30);
		createAccount.add(cnic);
		
		acnum = new JTextField();
		acnum.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent ke) {
				if(ke.getKeyChar()>='0' && ke.getKeyChar()<='9')
				{
					
				}
				else
				{
					
					ke.consume();
					}
			}
		});
		acnum.setFont(new Font("Times New Roman", Font.PLAIN, 18));
		acnum.setEditable(false);
		acnum.setColumns(10);
		acnum.setBounds(185, 210, 195, 30);
		createAccount.add(acnum);
		
		perAdd = new JTextField();
		perAdd.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent ke) {
				if(ke.getKeyChar()>='a' && ke.getKeyChar()<='z' || ke.getKeyChar() >= 'A' && ke.getKeyChar()<='Z'|| ke.getKeyChar()==' ')
				{
					
				}
				else
				{
					
					ke.consume();
					}
			}
		});
		perAdd.setFont(new Font("Times New Roman", Font.PLAIN, 18));
		perAdd.setColumns(10);
		perAdd.setBounds(577, 90, 195, 30);
		createAccount.add(perAdd);
		
		lblEmailAddress = new JLabel("Email Address");
		lblEmailAddress.setForeground(Color.WHITE);
		lblEmailAddress.setFont(new Font("Modern No. 20", Font.PLAIN, 20));
		lblEmailAddress.setBounds(407, 131, 132, 25);
		createAccount.add(lblEmailAddress);
		
		email = new JTextField();
		email.setFont(new Font("Times New Roman", Font.PLAIN, 18));
		email.setColumns(10);
		email.setBounds(577, 131, 195, 30);
		createAccount.add(email);
		
		OpenDate = new JTextField();
		OpenDate.setEditable(false);
		OpenDate.setFont(new Font("Times New Roman", Font.PLAIN, 15));
		OpenDate.setColumns(10);
		OpenDate.setBounds(577, 213, 195, 30);
		createAccount.add(OpenDate);
		
		lblOpeningDate = new JLabel("Opening Date");
		lblOpeningDate.setForeground(Color.WHITE);
		lblOpeningDate.setFont(new Font("Modern No. 20", Font.PLAIN, 20));
		lblOpeningDate.setBounds(407, 213, 122, 25);
		createAccount.add(lblOpeningDate);
		
		lblAmount = new JLabel("Amount");
		lblAmount.setForeground(Color.WHITE);
		lblAmount.setFont(new Font("Modern No. 20", Font.PLAIN, 20));
		lblAmount.setBounds(805, 200, 72, 25);
		createAccount.add(lblAmount);
		
		amount = new JTextField();
		amount.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent ke) {
				if(ke.getKeyChar()>='0' && ke.getKeyChar()<='9')
				{
					
				}
				else
				{
					
					ke.consume();
					}
			}
		});
		amount.setFont(new Font("Times New Roman", Font.PLAIN, 18));
		amount.setColumns(10);
		amount.setBounds(953, 206, 195, 30);
		createAccount.add(amount);
		
		dobTxtField = new JTextField("Day-Month-Year");
		dobTxtField.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				dobTxtField.setText(null);
			}
		});
		dobTxtField.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent arg0) {
				dobTxtField.setText(null);
			}
		});
		dobTxtField.setToolTipText("Day-Month-Year");
		dobTxtField.setFont(new Font("Times New Roman", Font.PLAIN, 18));
		dobTxtField.setColumns(10);
		dobTxtField.setBounds(953, 165, 195, 30);
		createAccount.add(dobTxtField);
		
		lblDateOfBirth = new JLabel("Date Of Birth");
		lblDateOfBirth.setForeground(Color.WHITE);
		lblDateOfBirth.setFont(new Font("Modern No. 20", Font.PLAIN, 20));
		lblDateOfBirth.setBounds(805, 164, 125, 25);
		createAccount.add(lblDateOfBirth);
		
		lblNationality = new JLabel("Nationality");
		lblNationality.setForeground(Color.WHITE);
		lblNationality.setFont(new Font("Modern No. 20", Font.PLAIN, 20));
		lblNationality.setBounds(407, 172, 102, 25);
		createAccount.add(lblNationality);
		
		separator_1 = new JSeparator();
		separator_1.setBounds(10, 352, 1313, 10);
		createAccount.add(separator_1);
		
		
		
		OpenDate.setText(""+date1);
		JButton btnSave = new JButton("Save");
		btnSave.setForeground(Color.BLACK);
		btnSave.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e)
			{
				accran = (int )(Math.random() * 1026525 + 4544);
				pinran = (int )(Math.random() * 1025 +7546);
				DBConnection();
				pin.setText(""+pinran);
				acnum.setText(""+accran);
				
				 try{cnicNo= Long.parseLong(cnic.getText());}
					catch(NumberFormatException nfe)
					{JOptionPane.showMessageDialog(null, "Worng input for National ID".toUpperCase());}
				 try{phoneNo= Long.parseLong(phone.getText());}
					catch(NumberFormatException nfe)
					{JOptionPane.showMessageDialog(null, "Worng input for Phone Number".toUpperCase());}
				 try{amo= Long.parseLong(amount.getText());}
					catch(NumberFormatException nfe)
					{JOptionPane.showMessageDialog(null, "Worng input for Amount".toUpperCase());}			 
				 
				try
				{
					String query = "INSERT INTO `useraccount_data`(`fname`, `lname`, `uname`, `accNo`, `cnic`, `pinCode`,"
							+ " `presAdd`,`premAdd`, `email`, `nationality`, `openDate`, `gender`,"
							+ " `phone`, `acType`, `dob`,`password`, `amount`,`image`)"
							+ " VALUES (?,?, ?,? ,?,? ,?,? ,?,? ,?,? ,?,?, ?,? ,?,?)";
					pst= con.prepareStatement(query);
					pst.setString(1, fname.getText());
					pst.setString(2, lname.getText());		
					pst.setString(3,uname.getText());
					pst.setInt(4, accran);
					pst.setLong(5,cnicNo);
					pst.setInt(6, pinran);
					pst.setString(7,presentAdd.getText());
					pst.setString(8, perAdd.getText());
					pst.setString(9, email.getText());
					pst.setString(10, comboValueNation);
					pst.setString(11, date1);
					pst.setString(12, gender);
					pst.setLong(13, phoneNo);
					pst.setString(14, comboValueAcType);
					pst.setString(15, dobTxtField.getText());
					pst.setString(16, password.getText());
					pst.setLong(17, amo);
					pst.setBytes(18,personImage);
					int rs = pst.executeUpdate();
					if(rs ==1)
					{
					JOptionPane.showMessageDialog(null, "Data Inserted Successfully");
					}
					else
					{
						JOptionPane.showMessageDialog(null, "Error During Insertion..!");
						
					}
					
					fname.setText(null);
					lname.setText(null);
					uname.setText(null);
					presentAdd.setText(null);
					amount.setText(null);
					dobTxtField.setText(null);
					perAdd.setText(null);
					OpenDate.setText(null);
					userImage.setText(null);
					email.setText(null);
					acnum.setText(null);
					cnic.setText(null);
					phone.setText(null);
					country.setSelectedItem("Select The Country");
					password.setText(null);
					amount.setText(null);
					pin.setText(null);
					userImage.setText(null);
					
					
				}
				catch(SQLException se)
				{
					se.printStackTrace();
				}
			}
		});
		btnSave.setIcon(new ImageIcon("Images\\save.png"));
		btnSave.setFont(new Font("Stencil", Font.PLAIN, 20));
		btnSave.setFocusPainted(false);
		btnSave.setBorderPainted(false);
		btnSave.setBorder(null);
		btnSave.setBounds(891, 364, 120, 37);
		createAccount.add(btnSave);
		OpenDate.setEditable(false);
		JButton btnClear = new JButton("Clear");
		btnClear.setForeground(Color.BLACK);
		btnClear.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e)
			{
				if (JOptionPane.showConfirmDialog(null,"Are you sure you want to Clear?","Please confirm",JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION)
				{	
				fname.setText(null);
				lname.setText(null);
				uname.setText(null);
				presentAdd.setText(null);
				amount.setText(null);
				dobTxtField.setText(null);
				perAdd.setText(null);
				OpenDate.setEditable(false);
				userImage.setText(null);
				email.setText(null);
				acnum.setText(null);
				cnic.setText(null);
				phone.setText(null);
				country.setSelectedItem("Select The Country");
				password.setText(null);
			}
			}
		});
		btnClear.setIcon(new ImageIcon("Images\\clear.png"));
		btnClear.setFont(new Font("Stencil", Font.PLAIN, 20));
		btnClear.setFocusPainted(false);
		btnClear.setBorderPainted(false);
		btnClear.setBorder(null);
		btnClear.setBounds(1021, 364, 120, 37);
		createAccount.add(btnClear);
		
		btnExit = new JButton("exit");
		btnExit.setForeground(Color.BLACK);
		btnExit.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e)
			{
				if (JOptionPane.showConfirmDialog(null,"Are you sure you want to Exit?","Please confirm",JOptionPane.YES_OPTION) == JOptionPane.YES_OPTION)
				{
				System.exit(0);
				}
				
			}
		});
		btnExit.setIcon(new ImageIcon("Images\\exit.png"));
		btnExit.setFont(new Font("Stencil", Font.PLAIN, 20));
		btnExit.setFocusPainted(false);
		btnExit.setBorderPainted(false);
		btnExit.setBorder(null);
		btnExit.setBounds(1151, 364, 120, 37);
		createAccount.add(btnExit);
		
		attachImage = new JButton("Add Image");
		attachImage.setForeground(Color.BLACK);
		attachImage.setIcon(new ImageIcon("Images\\camera.png"));
		attachImage.setFont(new Font("Stencil", Font.PLAIN, 17));
		attachImage.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) 
			{
				JFileChooser jfc = new JFileChooser();
				jfc.showOpenDialog(null);
				File f = jfc.getSelectedFile();
				fileName = f.getAbsolutePath();
				ImageIcon imgicon = new ImageIcon(new ImageIcon(fileName).getImage().getScaledInstance(userImage.getWidth(),userImage.getHeight(),Image.SCALE_DEFAULT));
				userImage.setIcon(imgicon);
				
				try
				{
					File f1 = new File(fileName);
					FileInputStream fix = new FileInputStream(f1);
					ByteArrayOutputStream bos = new ByteArrayOutputStream();
					byte [] buf = new byte[1024];
					for(int number ;(number = fix.read(buf))!= -1;)
					{
						bos.write(buf, 0, number);
					}
					personImage = bos.toByteArray();
					fix.close();
					bos.close();
				}catch(Exception ec)
				{ec.getMessage();}

			}
		});
		attachImage.setBounds(1156, 300, 165, 41);
		createAccount.add(attachImage);
		
		lblGender = new JLabel("Gender");
		lblGender.setForeground(Color.WHITE);
		lblGender.setFont(new Font("Modern No. 20", Font.PLAIN, 20));
		lblGender.setBounds(407, 254, 65, 25);
		createAccount.add(lblGender);
		
		rdbtnMale = new JRadioButton("Male");
		rdbtnMale.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				if(rdbtnMale.isSelected())
				{
					gender="Male";
					rdbtnFemale.setSelected(false);
				}
			}
		});
		rdbtnMale.setFont(new Font("Times New Roman", Font.PLAIN, 18));
		rdbtnMale.setBounds(577, 254, 79, 29);
		createAccount.add(rdbtnMale);
		
	    rdbtnFemale = new JRadioButton("Female");
		rdbtnFemale.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				if(rdbtnFemale.isSelected())
				{
					gender="Female";
					rdbtnMale.setSelected(false);
				}			}
		});
		rdbtnFemale.setFont(new Font("Times New Roman", Font.PLAIN, 18));
		rdbtnFemale.setBounds(672, 254, 100, 29);
		createAccount.add(rdbtnFemale);
		
		JLabel lblPhone = new JLabel("Phone #");
		lblPhone.setForeground(Color.WHITE);
		lblPhone.setFont(new Font("Modern No. 20", Font.PLAIN, 20));
		lblPhone.setBounds(407, 294, 72, 25);
		createAccount.add(lblPhone);
		
		phone = new JTextField();
		phone.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent ke) {
				if(ke.getKeyChar()>='0' && ke.getKeyChar()<='9')
				{
					
				}
				else
				{
					
					ke.consume();
					}
			}
		});
		phone.setFont(new Font("Times New Roman", Font.PLAIN, 18));
		phone.setColumns(10);
		phone.setBounds(577, 294, 195, 30);
		createAccount.add(phone);
		
		acType = new JComboBox<Object>();
		acType.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) 
			{
			 comboValueAcType = acType.getSelectedItem().toString();
				
			}
		});
		acType.setFont(new Font("Times New Roman", Font.PLAIN, 18));
		acType.setModel(new DefaultComboBoxModel(new String[] {"Select Account Type", "Current", "Saving", "Default"}));
		acType.setBounds(953, 81, 195, 30);
		createAccount.add(acType);
		
		lblAccountType = new JLabel("Account Type");
		lblAccountType.setForeground(Color.WHITE);
		lblAccountType.setFont(new Font("Modern No. 20", Font.PLAIN, 20));
		lblAccountType.setBounds(805, 83, 121, 25);
		createAccount.add(lblAccountType);
		
		country = new JComboBox();
		country.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) 
			{
				comboValueNation=country.getSelectedItem().toString();
			}
		});
		country.setModel(new DefaultComboBoxModel(new String[] {"Select The Country", "Afghanistan", "Albania", "Algeria", "Andorra", "Angola", "Bahamas, The", "Bahrain", "Bangladesh", "Barbados", "Belarus", "Canada", "Cabo Verde", "Central African Republic", "Chile", "China", "Denmark", "Djibouti", "Dominica", "Dominican Republic", "Pakistan", "Palau", "Philippines", "Poland", "Portugal", "Romania", "Russia", "Rwanda", "Spain", "Swaziland", "Sweden", "Switzerland", "Ukraine", "United Arab Emirates", "United Kingdom", "Uruguay", "Other"}));
		country.setFont(new Font("Times New Roman", Font.PLAIN, 18));
		country.setBounds(577, 172, 195, 30);
		createAccount.add(country);
		
		JLabel lblPassword = new JLabel("Password");
		lblPassword.setForeground(Color.WHITE);
		lblPassword.setFont(new Font("Modern No. 20", Font.PLAIN, 20));
		lblPassword.setBounds(800, 247, 84, 25);
		createAccount.add(lblPassword);
		
		password = new JTextField();
		password.setFont(new Font("Times New Roman", Font.PLAIN, 18));
		password.setColumns(10);
		password.setBounds(953, 247, 195, 30);
		createAccount.add(password);
		
		JLabel label = new JLabel("Pin Code");
		label.setForeground(Color.WHITE);
		label.setFont(new Font("Modern No. 20", Font.PLAIN, 20));
		label.setBounds(805, 123, 80, 25);
		createAccount.add(label);
		
		pin = new JTextField();
		pin.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent ke) {
				if(ke.getKeyChar()>='0' && ke.getKeyChar()<='9')
				{
					
				}
				else
				{
					
					ke.consume();
					}
			}
		});
		pin.setFont(new Font("Times New Roman", Font.PLAIN, 18));
		pin.setColumns(10);
		pin.setBounds(953, 124, 195, 30);
		pin.setEditable(false);
		createAccount.add(pin);
		
		userImage = new JLabel("");
		userImage.setBorder(new TitledBorder(new LineBorder(new Color(0, 0, 0)), "User Image", TitledBorder.LEADING, TitledBorder.TOP, null, Color.WHITE));
		userImage.setBounds(1151, 83, 170, 208);
		createAccount.add(userImage);
		
		JLabel lblCreateUser = DefaultComponentFactory.getInstance().createTitle("Create User");
		lblCreateUser.setHorizontalAlignment(SwingConstants.CENTER);
		lblCreateUser.setFont(new Font("Niagara Engraved", Font.PLAIN, 70));
		lblCreateUser.setBounds(374, 15, 479, 62);
		createAccount.add(lblCreateUser);
		
		JLabel copyRight = new JLabel("Copyright \u00A9 2017");
		copyRight.setFont(new Font("Georgia", Font.PLAIN, 15));
		copyRight.setBounds(20, 373, 132, 18);
		createAccount.add(copyRight);
		
		createUserBackImageLabel = new JLabel("");
		createUserBackImageLabel.setIcon(new ImageIcon("Images\\backImg.png"));
		createUserBackImageLabel.setBounds(2, 13, 1328, 440);
		createAccount.add(createUserBackImageLabel);
		
		searchUser = new JPanel();
		searchUser.setBorder(new TitledBorder(new LineBorder(new Color(0, 0, 0)), "Search User", TitledBorder.LEADING, TitledBorder.TOP, null, Color.WHITE));
		tabbedPane.addTab("Search User", new ImageIcon("Images\\search.png"), searchUser, null);
		searchUser.setLayout(null);
		
		JScrollPane scrollPane_1 = new JScrollPane();
		
		scrollPane_1.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		scrollPane_1.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
		scrollPane_1.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_ALWAYS);
		scrollPane_1.setBorder(new LineBorder(new Color(130, 135, 144)));
		scrollPane_1.setViewportBorder(new LineBorder(new Color(0, 0, 0)));
		scrollPane_1.setBounds(10, 60, 1317, 277);
		
		searchAccountNumber = new JTextField();
		searchAccountNumber.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent e) {
				if(e.getKeyChar()=='0' || e.getKeyChar()=='9')
				{}else
				{
					
					e.consume();
				}
			}
		});
		searchAccountNumber.setFont(new Font("Times New Roman", Font.PLAIN, 18));
		searchAccountNumber.setBounds(172, 37, 195, 29);
		searchAccountNumber.setColumns(10);
		searchUser.add(searchAccountNumber);
		
		searchUsername = new JTextField();
		searchUsername.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent ke) {
				if(ke.getKeyChar()>='a' && ke.getKeyChar()<='z' ||ke.getKeyChar()>='A' && ke.getKeyChar()<='Z' ||ke.getKeyChar()==' ')
				{}
				else
				{
					
					ke.consume();
				}
			}
		});
		searchUsername.setFont(new Font("Times New Roman", Font.PLAIN, 18));
		searchUsername.setBounds(172, 77, 195, 30);
		searchUsername.setColumns(10);
		searchUser.add(searchUsername);
		
		JLabel lblUsername_2 = new JLabel("Username");
		lblUsername_2.setForeground(Color.WHITE);
		lblUsername_2.setBounds(10, 77, 152, 22);
		lblUsername_2.setFont(new Font("Modern No. 20", Font.PLAIN, 20));
		searchUser.add(lblUsername_2);
		
		JLabel label_18 = new JLabel("Account Number");
		label_18.setForeground(Color.WHITE);
		label_18.setBounds(10, 37, 152, 29);
		label_18.setFont(new Font("Modern No. 20", Font.PLAIN, 20));
		searchUser.add(label_18);
		
		JLabel lblSearchUser = DefaultComponentFactory.getInstance().createTitle("Search User");
		lblSearchUser.setForeground(Color.WHITE);
		lblSearchUser.setHorizontalAlignment(SwingConstants.CENTER);
		lblSearchUser.setFont(new Font("Niagara Engraved", Font.PLAIN, 70));
		lblSearchUser.setBounds(481, 15, 373, 62);
		searchUser.add(lblSearchUser);
		
		btnSearchUserDetails = new JButton("Search User Details");
		btnSearchUserDetails.setIcon(new ImageIcon("Images\\search.png"));
		btnSearchUserDetails.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				try 
				{
				searchAccount = Integer.parseInt(searchAccountNumber.getText());
				DBConnection();
				
				String search = "SELECT `uname` as'Username',`accNo`as 'Account Number',`cnic`as'CNIC',`pinCode`as'Pin Code',`presAdd`as 'Present Address',"
						+ "`email`as'Email',`nationality`as'Country',`gender`as'Gender',`phone`as'Phone',`acType`as'Account Type',`amount` as'Amount' "
						+ "FROM `useraccount_data` where accNo = '"+searchAccount+"' and uname='"+searchUsername.getText()+"'";
				pst= con.prepareStatement(search);
				rs = pst.executeQuery();
				serachUserData.setModel(DbUtils.resultSetToTableModel(rs));
				} catch (SQLException e) {}
				catch(NumberFormatException e)
				{
					JOptionPane.showMessageDialog(null,"Please Enter the Correct Account Number");
				}
				
			}
		});
		btnSearchUserDetails.setForeground(Color.BLACK);
		btnSearchUserDetails.setFont(new Font("Stencil", Font.PLAIN, 20));
		btnSearchUserDetails.setFocusPainted(false);
		btnSearchUserDetails.setBorderPainted(false);
		btnSearchUserDetails.setBorder(null);
		btnSearchUserDetails.setBounds(531, 378, 262, 37);
		searchUser.add(btnSearchUserDetails);
		
		searchUserPane = new JScrollPane();
		searchUserPane.setBounds(10, 123, 1300, 232);
		searchUser.add(searchUserPane);
		
		JScrollPane searchUserTable = new JScrollPane();
		searchUserTable.setBounds(10, 124, 1300, 231);
		searchUser.add(searchUserTable);
		
		serachUserData = new JTable();
		searchUserTable.setViewportView(serachUserData);
		
		deleteUser = new JPanel();
		deleteUser.setBorder(new TitledBorder(new LineBorder(new Color(0, 0, 0)), "Delete User", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		tabbedPane.addTab("Delete User", new ImageIcon("Images\\delete.png"), deleteUser, null);
		deleteUser.setLayout(null);
		
		delAcNo = new JTextField();
		delAcNo.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent ke) {
				if(ke.getKeyChar()>='0' && ke.getKeyChar()<='9')
				{}
				else
				{
					
					ke.consume();
				}
			}
		});
		delAcNo.setFont(new Font("Times New Roman", Font.PLAIN, 18));
		delAcNo.setColumns(10);
		delAcNo.setBounds(596, 139, 195, 29);
		deleteUser.add(delAcNo);
		
		label_20 = new JLabel("Account Number");
		label_20.setForeground(Color.WHITE);
		label_20.setFont(new Font("Modern No. 20", Font.PLAIN, 20));
		label_20.setBounds(434, 139, 152, 29);
		deleteUser.add(label_20);
		
		lblUsername_1 = new JLabel("Username");
		lblUsername_1.setForeground(Color.WHITE);
		lblUsername_1.setFont(new Font("Modern No. 20", Font.PLAIN, 20));
		lblUsername_1.setBounds(434, 179, 152, 22);
		deleteUser.add(lblUsername_1);
		
		delUname = new JTextField();
		delUname.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent ke) {
				if(ke.getKeyChar()>='a' && ke.getKeyChar()<='z' ||ke.getKeyChar()>='A' && ke.getKeyChar()<='Z' ||ke.getKeyChar()==' ')
				{}
				else
				{
					
					ke.consume();
				}
			}
		});
		delUname.setFont(new Font("Times New Roman", Font.PLAIN, 18));
		delUname.setColumns(10);
		delUname.setBounds(596, 179, 195, 30);
		deleteUser.add(delUname);
		
		btnDeleteUser = new JButton("Delete User");
		btnDeleteUser.setIcon(new ImageIcon("Images\\delIcon.png"));
		btnDeleteUser.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				
				try {
					delAccount = Integer.parseInt(delAcNo.getText());
				DBConnection();
				
				int rs  =0;
				if (JOptionPane.showConfirmDialog(null,"Sure you Want to delete?","Please confirm",JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION)
				{
				String delete  = "DELETE FROM `useraccount_data` WHERE `accNo`='"+delAccount+"'and`uname`='"+delUname.getText()+"'";
					pst = con.prepareStatement(delete);
					rs =pst.executeUpdate();
					if(rs==1)
					{
					JOptionPane.showMessageDialog(null, "User Deleted Successfully ");
					delAcNo.setText(null);
					delUname.setText(null);
					}
					
					else
					{
						JOptionPane.showMessageDialog(null, "User not Found ");	
					}
				}
				}catch(SQLException e)
				{
					JOptionPane.showMessageDialog(null,"Connection Error..!");
				}
				catch(NumberFormatException e)
				{
					JOptionPane.showMessageDialog(null,"Please Enter the Correct Account Number");
				}
				
			}
			
		});
		btnDeleteUser.setForeground(Color.BLACK);
		btnDeleteUser.setFont(new Font("Stencil", Font.PLAIN, 20));
		btnDeleteUser.setFocusPainted(false);
		btnDeleteUser.setBorderPainted(false);
		btnDeleteUser.setBorder(null);
		btnDeleteUser.setBounds(561, 364, 176, 37);
		deleteUser.add(btnDeleteUser);
		
		JLabel lblNewJgoodiesTitle_1 = DefaultComponentFactory.getInstance().createTitle("Delete User");
		lblNewJgoodiesTitle_1.setForeground(Color.WHITE);
		lblNewJgoodiesTitle_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewJgoodiesTitle_1.setFont(new Font("Niagara Engraved", Font.PLAIN, 70));
		lblNewJgoodiesTitle_1.setBounds(537, 15, 190, 76);
		deleteUser.add(lblNewJgoodiesTitle_1);
		
			
		imageLabel = new JLabel("");
		imageLabel.setIcon(new ImageIcon("Images\\deleteUser.png"));
		imageLabel.setFont(new Font("Imprint MT Shadow", Font.PLAIN, 18));
		imageLabel.setBounds(130, 78, 256, 256);
		deleteUser.add(imageLabel);
		
		label_17 = new JLabel("Copyright \u00A9 2017");
		label_17.setFont(new Font("Georgia", Font.PLAIN, 15));
		label_17.setBounds(20, 373, 132, 18);
		deleteUser.add(label_17);
		
		separator_3 = new JSeparator();
		separator_3.setBounds(10, 345, 1313, 10);
		deleteUser.add(separator_3);
		
		deleteUserBackImageLabel = new JLabel("");
		deleteUserBackImageLabel.setIcon(new ImageIcon("Images\\backImg.png"));
		deleteUserBackImageLabel.setBounds(2, 14, 1328, 440);
		deleteUser.add(deleteUserBackImageLabel);
		
		updateUser = new JPanel();
		updateUser.setBorder(new TitledBorder(new LineBorder(new Color(0, 0, 0)), "Update User", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		tabbedPane.addTab("Update User", new ImageIcon("Images\\update.png"), updateUser, null);
		updateUser.setLayout(null);
		
		upFname = new JTextField();
		upFname.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent ke) {
				if(ke.getKeyChar()>='a' && ke.getKeyChar()<='z' ||ke.getKeyChar()>='A' && ke.getKeyChar()<='Z' || ke.getKeyChar()==' ')
				{}
				else
				{
					
					ke.consume();
				}
			}
		});
		upFname.setColumns(10);
		upFname.setBounds(172, 130, 195, 30);
		updateUser.add(upFname);
		
		upLname = new JTextField();
		upLname.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent ke) {
				if(ke.getKeyChar()>='a' && ke.getKeyChar()<='z' ||ke.getKeyChar()>='A' && ke.getKeyChar()<='Z' || ke.getKeyChar()==' ')
				{}
				else
				{
					
					ke.consume();
				}
			}
		});
		upLname.setColumns(10);
		upLname.setBounds(172, 172, 195, 30);
		updateUser.add(upLname);
		
		upUname = new JTextField();
		upUname.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent ke) {
				if(ke.getKeyChar()>='a' && ke.getKeyChar()<='z' ||ke.getKeyChar()>='A' && ke.getKeyChar()<='Z' || ke.getKeyChar()==' ')
				{}
				else
				{
					
					ke.consume();
				}
			}
		});
		upUname.setColumns(10);
		upUname.setBounds(172, 218, 195, 30);
		updateUser.add(upUname);
		
		upCnic = new JTextField();
		upCnic.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent ke) {
				if(ke.getKeyChar()>='0' && ke.getKeyChar()<='9')
				{}
				else
				{
					
					ke.consume();
				}
			}
		});
		upCnic.setColumns(10);
		upCnic.setBounds(172, 299, 195, 30);
		updateUser.add(upCnic);
		
		upPresAdd = new JTextField();
		upPresAdd.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent ke) {
				if(ke.getKeyChar()>='a' && ke.getKeyChar()<='z' ||ke.getKeyChar()>='A' && ke.getKeyChar()<='Z' || ke.getKeyChar()==' ')
				{}
				else
				{
					
					ke.consume();
				}
			}
		});
		upPresAdd.setColumns(10);
		upPresAdd.setBounds(586, 128, 195, 30);
		updateUser.add(upPresAdd);
		
		upPerAdd = new JTextField();
		upPerAdd.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent ke) {
				if(ke.getKeyChar()>='a' && ke.getKeyChar()<='z' ||ke.getKeyChar()>='A' && ke.getKeyChar()<='Z' || ke.getKeyChar()==' ')
				{}
				else
				{
					
					ke.consume();
				}
			}
		});
		upPerAdd.setColumns(10);
		upPerAdd.setBounds(586, 172, 195, 30);
		updateUser.add(upPerAdd);
		
		upEmail = new JTextField();
		upEmail.setColumns(10);
		upEmail.setBounds(586, 212, 195, 30);
		updateUser.add(upEmail);
		
		upNation = new JComboBox();
		upNation.setModel(new DefaultComboBoxModel(new String[] {"Select The Country", "Afghanistan", "Albania", "Algeria", "Andorra", "Angola", "Bahamas, The", "Bahrain", "Bangladesh", "Barbados", "Belarus", "Canada", "Cabo Verde", "Central African Republic", "Chile", "China", "Denmark", "Djibouti", "Dominica", "Dominican Republic", "Pakistan", "Palau", "Philippines", "Poland", "Portugal", "Romania", "Russia", "Rwanda", "Spain", "Swaziland", "Sweden", "Switzerland", "Ukraine", "United Arab Emirates", "United Kingdom", "Uruguay", "Other"}));
		upNation.setFont(new Font("Serif", Font.PLAIN, 17));
		upNation.setBounds(586, 255, 195, 30);
		updateUser.add(upNation);
		
		upDate = new JTextField();
		upDate.setColumns(10);
		upDate.setBounds(586, 299, 195, 30);
		updateUser.add(upDate);
		
		label_1 = new JLabel("Opening Date");
		label_1.setForeground(Color.WHITE);
		label_1.setFont(new Font("Modern No. 20", Font.PLAIN, 20));
		label_1.setBounds(416, 304, 111, 22);
		updateUser.add(label_1);
		
		label_2 = new JLabel("Nationality");
		label_2.setForeground(Color.WHITE);
		label_2.setFont(new Font("Modern No. 20", Font.PLAIN, 20));
		label_2.setBounds(416, 260, 91, 22);
		updateUser.add(label_2);
		
		label_3 = new JLabel("Email Address");
		label_3.setForeground(Color.WHITE);
		label_3.setFont(new Font("Modern No. 20", Font.PLAIN, 20));
		label_3.setBounds(416, 220, 119, 22);
		updateUser.add(label_3);
		
		label_4 = new JLabel("Permanent Address");
		label_4.setForeground(Color.WHITE);
		label_4.setFont(new Font("Modern No. 20", Font.PLAIN, 20));
		label_4.setBounds(416, 174, 158, 22);
		updateUser.add(label_4);
		
		label_5 = new JLabel("Present Address");
		label_5.setForeground(Color.WHITE);
		label_5.setFont(new Font("Modern No. 20", Font.PLAIN, 20));
		label_5.setBounds(416, 132, 130, 22);
		updateUser.add(label_5);
		
		label_6 = new JLabel("National ID");
		label_6.setForeground(Color.WHITE);
		label_6.setFont(new Font("Modern No. 20", Font.PLAIN, 20));
		label_6.setBounds(10, 301, 98, 22);
		updateUser.add(label_6);
		
		label_7 = new JLabel("Username");
		label_7.setForeground(Color.WHITE);
		label_7.setFont(new Font("Modern No. 20", Font.PLAIN, 20));
		label_7.setBounds(10, 218, 80, 22);
		updateUser.add(label_7);
		
		label_8 = new JLabel("Lastname");
		label_8.setForeground(Color.WHITE);
		label_8.setFont(new Font("Modern No. 20", Font.PLAIN, 20));
		label_8.setBounds(10, 172, 79, 22);
		updateUser.add(label_8);
		
		label_9 = new JLabel("Firstname");
		label_9.setForeground(Color.WHITE);
		label_9.setFont(new Font("Modern No. 20", Font.PLAIN, 20));
		label_9.setBounds(10, 130, 82, 22);
		updateUser.add(label_9);
		
		label_11 = new JLabel("Phone #");
		label_11.setForeground(Color.WHITE);
		label_11.setFont(new Font("Modern No. 20", Font.PLAIN, 20));
		label_11.setBounds(818, 217, 66, 22);
		updateUser.add(label_11);
		
		upFone = new JTextField();
		upFone.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent ke) {
				if(ke.getKeyChar()>='0' && ke.getKeyChar()<='9')
				{}
				else
				{
					
					ke.consume();
				}
			}
		});
		upFone.setColumns(10);
		upFone.setBounds(957, 215, 195, 30);
		updateUser.add(upFone);
		
		label_12 = new JLabel("Account Type");
		label_12.setForeground(Color.WHITE);
		label_12.setFont(new Font("Modern No. 20", Font.PLAIN, 20));
		label_12.setBounds(818, 263, 110, 22);
		updateUser.add(label_12);
		
		upType = new JComboBox();
		upType.setModel(new DefaultComboBoxModel(new String[] {"Select Account Type", "Current", "Saving", "Default"}));
		upType.setFont(new Font("Serif", Font.PLAIN, 17));
		upType.setBounds(957, 258, 195, 30);
		updateUser.add(upType);
		
		label_13 = new JLabel("Date Of Birth");
		label_13.setForeground(Color.WHITE);
		label_13.setFont(new Font("Modern No. 20", Font.PLAIN, 20));
		label_13.setBounds(10, 260, 113, 22);
		updateUser.add(label_13);
		
		label_15 = new JLabel("Password");
		label_15.setForeground(Color.WHITE);
		label_15.setFont(new Font("Modern No. 20", Font.PLAIN, 20));
		label_15.setBounds(818, 304, 76, 22);
		updateUser.add(label_15);
		
		upPass = new JTextField();
		upPass.setColumns(10);
		upPass.setBounds(957, 299, 195, 30);
		updateUser.add(upPass);
		
		upDob = new JTextField();
		upDob.setColumns(10);
		upDob.setBounds(172, 260, 195, 30);
		updateUser.add(upDob);
		
		JButton btnUpdate = new JButton("Update");
		btnUpdate.setForeground(Color.BLACK);
		btnUpdate.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) 
			{	
				try{cnicNo= Long.parseLong(upCnic.getText());}
				catch(NumberFormatException nfe)
				{JOptionPane.showMessageDialog(null, "Worng input for National ID".toUpperCase());}
				
				try{phoneNo= Long.parseLong(upFone.getText());}
				catch(NumberFormatException nfe)
				{JOptionPane.showMessageDialog(null, "Worng input for Phone Number".toUpperCase());}
				
				try{newPin = Integer.parseInt(upPin.getText());}
				catch(NumberFormatException nfe)
				{JOptionPane.showMessageDialog(null, "Worng input for Pin".toUpperCase());}
				
				DBConnection();
				try {
					String updateQuery = "UPDATE `useraccount_data` SET `fname`='"+upFname.getText()+"',`lname`='"+upLname.getText()+"',`uname`='"+upUname.getText()+"',"
							+ "`cnic`='"+cnicNo+"',`pinCode`='"+newPin+"',`presAdd`='"+upPresAdd.getText()+"',`premAdd`='"+upPerAdd.getText()+"',"
							+ "`email`='"+upEmail.getText()+"',`nationality`='"+upNation.getSelectedItem()+"',`openDate`='"+upDate.getText()+"',"
							+ "`phone`='"+phoneNo+"',`acType`='"+upType.getSelectedItem()+"',`dob`='"+upDob.getText()+"',"
							+ "`password`='"+upPass.getText()+"' WHERE accNo = '"+upAcNum.getText()+"'"; 
					pst = con.prepareStatement(updateQuery);
					pst.executeUpdate();
					JOptionPane.showMessageDialog(null, "Data Updated Successfully.");

				} catch (SQLException e1) {}
				
			}
		});
		btnUpdate.setIcon(new ImageIcon("Images\\update-icon.png"));
		btnUpdate.setFont(new Font("Stencil", Font.PLAIN, 20));
		btnUpdate.setBorder(null);
		btnUpdate.setBounds(1042, 361, 120, 37);
		updateUser.add(btnUpdate);
		
		JButton updateExitBtn = new JButton("exit");
		updateExitBtn.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				if (JOptionPane.showConfirmDialog(null,"Sure you Want to Exit?","Please confirm",JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION)
				{
					System.exit(0);
				}
			}
		});
		updateExitBtn.setForeground(Color.BLACK);
		updateExitBtn.setIcon(new ImageIcon("Images\\exit.png"));
		updateExitBtn.setFont(new Font("Stencil", Font.PLAIN, 20));
		updateExitBtn.setBorder(null);
		updateExitBtn.setBounds(1190, 361, 120, 37);
		updateUser.add(updateExitBtn);
		
		label_16 = new JLabel("Account Number");
		label_16.setForeground(Color.WHITE);
		label_16.setFont(new Font("Modern No. 20", Font.PLAIN, 20));
		label_16.setBounds(10, 90, 135, 22);
		updateUser.add(label_16);
		
		upAcNum = new JTextField();
		upAcNum.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent ke) {

				if(ke.getKeyChar()>='0' && ke.getKeyChar()<='9')
				{}
				else
				{
					
					ke.consume();
				}
			}
		});
		upAcNum.setColumns(10);
		upAcNum.setBounds(172, 90, 195, 30);
		updateUser.add(upAcNum);
		
		JLabel lblNewJgoodiesTitle = DefaultComponentFactory.getInstance().createTitle("Update User");
		lblNewJgoodiesTitle.setForeground(Color.WHITE);
		lblNewJgoodiesTitle.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewJgoodiesTitle.setFont(new Font("Niagara Engraved", Font.PLAIN, 70));
		lblNewJgoodiesTitle.setBounds(449, 11, 198, 76);
		updateUser.add(lblNewJgoodiesTitle);
		
		JSeparator separator = new JSeparator();
		separator.setBounds(10, 349, 1313, 10);
		updateUser.add(separator);
		
		JLabel lblPin = new JLabel("Pin");
		lblPin.setForeground(Color.WHITE);
		lblPin.setFont(new Font("Modern No. 20", Font.PLAIN, 20));
		lblPin.setBounds(416, 90, 30, 22);
		updateUser.add(lblPin);
		
		upPin = new JTextField();
		upPin.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent ke) {

				if(ke.getKeyChar()>='0' && ke.getKeyChar()<='9')
				{}
				else
				{
					
					ke.consume();
				}
			}
		});
		upPin.setEditable(false);
		upPin.setColumns(10);
		upPin.setBounds(586, 90, 195, 30);
		updateUser.add(upPin);
		
		upFname.setEditable(false);
		upFone.setEditable(false);
		upCnic.setEditable(false);
		upDate.setEditable(false);
		upDob.setEditable(false);
		upEmail.setEditable(false);
		upLname.setEditable(false);
		upPass.setEditable(false);
		upPerAdd.setEditable(false);
		upPin.setEditable(false);;
		upPresAdd.setEditable(false);
		upUname.setEditable(false);
		upType.setEnabled(false);
		upNation.setEnabled(false);
		JLabel getUpImage = new JLabel("");
		getUpImage.setBorder(new TitledBorder(new LineBorder(new Color(0, 0, 0)), "User Image", TitledBorder.LEADING, TitledBorder.TOP, null, Color.WHITE));
		getUpImage.setBounds(1162, 90, 162, 202);
		updateUser.add(getUpImage);
		
		JButton btnEdit = new JButton("Edit");
		btnEdit.addActionListener(new ActionListener() {
			

			@Override
			public void actionPerformed(ActionEvent arg0) 
			{
				count++;
				upFname.setEditable(true);
				upFone.setEditable(true);
				upCnic.setEditable(true);
				upDob.setEditable(true);
				upEmail.setEditable(true);
				upLname.setEditable(true);
				upNation.setEnabled(true);
				upPass.setEditable(true);
				upPerAdd.setEditable(true);
				upPin.setEditable(true);
				upType.setEnabled(true);
				upPresAdd.setEditable(true);
				upUname.setEditable(true);
				DBConnection();
				try{
					ac = Integer.parseInt(upAcNum.getText());
				}
				catch(NumberFormatException ae)
				{
					JOptionPane.showMessageDialog(null, "Invalid Account Number");
				}
				try
				{
					String query="SELECT * FROM `useraccount_data` where accNo = '"+ac+"'";
					pst = con.prepareStatement(query);
					rs=pst.executeQuery();
					while(rs.next())
					{
						count++;
						upFname.setText(rs.getString(2));
						upLname.setText(rs.getString(3));
						upUname.setText(rs.getString(4));
						upDob.setText(rs.getString(16));
						upCnic.setText(rs.getString(6));
						upPin.setText(rs.getString(7));
						upPresAdd.setText(rs.getString(8));
						upPerAdd.setText(rs.getString(9));
						upEmail.setText(rs.getString(10));
						upNation.setSelectedItem(rs.getString(11));
						upDate.setText(rs.getString(12));
						upFone.setText(rs.getString(14));	
						upType.setSelectedItem(rs.getString(15));
						upPass.setText(rs.getString(17));
					}
					if(count <1)
					{
						JOptionPane.showMessageDialog(null, "Invalid Account Number");
					}
					}
				catch(SQLException s)
				{}
			}
		});
		btnEdit.setIcon(new ImageIcon("Images\\edit.png"));
		btnEdit.setForeground(Color.BLACK);
		btnEdit.setFont(new Font("Stencil", Font.PLAIN, 20));
		btnEdit.setBorder(null);
		btnEdit.setBounds(890, 361, 120, 37);
		updateUser.add(btnEdit);
		
		JButton btnShowImage = new JButton("Show Image");
		btnShowImage.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				DBConnection();
				try {
					String d = "SELECT `image` FROM `useraccount_data` WHERE `accNo`='"+upAcNum.getText()+"'";
					pst = con.prepareStatement(d);
					 rs = pst.executeQuery();
				if(rs.next())
				{
					byte [] img = rs.getBytes("Image");
					ImageIcon image = new ImageIcon(img);
					Image imag  = image.getImage();
					Image myImg = imag.getScaledInstance(getUpImage.getWidth(), getUpImage.getHeight(), Image.SCALE_SMOOTH);
					ImageIcon image1 = new ImageIcon(myImg);
					getUpImage.setIcon(image1);
				}
				else{
				JOptionPane.showMessageDialog(null, "No Image Found");
			}
			} catch (SQLException es) {es.printStackTrace();}
			
			}
		});
		btnShowImage.setIcon(new ImageIcon("Images\\showCam.png"));
		btnShowImage.setForeground(Color.BLACK);
		btnShowImage.setFont(new Font("Stencil", Font.PLAIN, 18));
		btnShowImage.setFocusPainted(false);
		btnShowImage.setBorderPainted(false);
		btnShowImage.setBorder(null);
		btnShowImage.setBounds(1163, 301, 161, 37);
		updateUser.add(btnShowImage);
		
		label_21 = new JLabel("Copyright \u00A9 2017");
		label_21.setFont(new Font("Georgia", Font.PLAIN, 15));
		label_21.setBounds(20, 373, 132, 18);
		updateUser.add(label_21);
		
		JLabel updateUserBackImageLabel = new JLabel("");
		updateUserBackImageLabel.setIcon(new ImageIcon("Images\\backImg.png"));
		updateUserBackImageLabel.setBounds(2, 14, 1328, 440);
		updateUser.add(updateUserBackImageLabel);
		
		JPanel showAllUser = new JPanel();
		showAllUser.setBorder(new TitledBorder(new LineBorder(new Color(0, 0, 0)), "Users Data", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		tabbedPane.addTab("Users Data", new ImageIcon("Images\\users.png"), showAllUser, null);
		showAllUser.setLayout(null);
		
		JButton btnShowData = new JButton("Show data");
		btnShowData.setIcon(new ImageIcon("Images\\sh.png"));
		btnShowData.setBounds(598, 380, 157, 37);
		btnShowData.setForeground(Color.BLACK);
		btnShowData.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) 
			{
				try 
				{
				
				DBConnection();
				String allUser = "SELECT `uname` as 'Username',`accNo` as 'Account Number',`cnic` as 'CNIC',`pinCode` as 'Pin Code',`presAdd`as'Present Address',`email`as 'Email ID',`nationality` as'Nationality' ,`openDate`as'Opening Date',`gender`as'Gender',`phone`as'Contact',`acType`as'Account Type',`amount`as 'Total Amount' FROM `useraccount_data`";
				pst= con.prepareStatement(allUser);
				rs = pst.executeQuery();
				table.setModel(DbUtils.resultSetToTableModel(rs));
				} catch (SQLException e) {}
				
			}
		});
		btnShowData.setFont(new Font("Stencil", Font.PLAIN, 20));
		btnShowData.setFocusPainted(false);
		btnShowData.setBorderPainted(false);
		btnShowData.setBorder(null);
		showAllUser.add(btnShowData);
		
		JLabel lblAllUsersList = DefaultComponentFactory.getInstance().createTitle("All users List");
		lblAllUsersList.setForeground(Color.WHITE);
		lblAllUsersList.setHorizontalAlignment(SwingConstants.CENTER);
		lblAllUsersList.setBounds(422, 15, 210, 76);
		lblAllUsersList.setFont(new Font("Niagara Engraved", Font.PLAIN, 70));
		showAllUser.add(lblAllUsersList);
		
		scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 93, 1300, 269);
		showAllUser.add(scrollPane);
		scrollPane.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		scrollPane.setBorder(new LineBorder(new Color(130, 135, 144)));
		scrollPane.setViewportBorder(new TitledBorder(new LineBorder(new Color(255, 255, 255), 2), "Users Data", TitledBorder.LEADING, TitledBorder.TOP, null, Color.WHITE));
		
		table = new JTable();
		scrollPane.setViewportView(table);
		
		JPanel TransferInfo = new JPanel();
		tabbedPane.addTab("Transfer Info", new ImageIcon("Images\\trans.png"), TransferInfo, null);
		TransferInfo.setLayout(null);
		
		JPanel moneyTransfer = new JPanel();
		moneyTransfer.setForeground(Color.BLACK);
		moneyTransfer.setBorder(new TitledBorder(new LineBorder(new Color(0, 0, 0)), "Money Transfer Information", TitledBorder.LEADING, TitledBorder.TOP, null, Color.WHITE));
		moneyTransfer.setBounds(0, 0, 1333, 443);
		TransferInfo.add(moneyTransfer);
		moneyTransfer.setLayout(null);
		
		JLabel lblMoneyTransferInformation = DefaultComponentFactory.getInstance().createTitle("Money Transfer Information");
		lblMoneyTransferInformation.setForeground(Color.WHITE);
		lblMoneyTransferInformation.setBounds(374, 15, 457, 76);
		lblMoneyTransferInformation.setHorizontalAlignment(SwingConstants.CENTER);
		lblMoneyTransferInformation.setFont(new Font("Niagara Engraved", Font.PLAIN, 70));
		moneyTransfer.add(lblMoneyTransferInformation);
		
		scrollPane_2 = new JScrollPane();
		scrollPane_2.setViewportBorder(new TitledBorder(new LineBorder(new Color(255, 255, 255), 2), "Trasnfer Data", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(255, 255, 255)));
		scrollPane_2.setBounds(15, 96, 1300, 269);
		moneyTransfer.add(scrollPane_2);
		
		moneyTrasnfer = new JTable();
		scrollPane_2.setViewportView(moneyTrasnfer);
		
		lblAdminMenu = new JLabel("Admin Menu");
		lblAdminMenu.setHorizontalAlignment(SwingConstants.CENTER);
		lblAdminMenu.setForeground(Color.WHITE);
		lblAdminMenu.setFont(new Font("Niagara Engraved", Font.PLAIN, 99));
		lblAdminMenu.setBounds(36, 0, 1312, 114);
		panel.add(lblAdminMenu);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBorder(new LineBorder(new Color(0, 0, 0)));
		panel_1.setBounds(1064, 11, 274, 79);
		panel.add(panel_1);
		panel_1.setLayout(null);
		
		 nameLabel = new JLabel("");
		 nameLabel.setHorizontalAlignment(SwingConstants.LEFT);
		 nameLabel.setForeground(Color.WHITE);
		 nameLabel.setBounds(10, 11, 254, 24);
		 nameLabel.setFont(new Font("Times New Roman", Font.PLAIN, 22));
		 panel_1.add(nameLabel);
		 
		  dateLabel = new JLabel("");
		  dateLabel.setHorizontalAlignment(SwingConstants.CENTER);
		  dateLabel.setBounds(10, 46, 254, 26);
		  panel_1.add(dateLabel);
		  dateLabel.setForeground(Color.WHITE);
		  dateLabel.setFont(new Font("Times New Roman", Font.PLAIN, 16));
		  dateLabel.setText("Date :"+date1);

			JPanel withdrawInfo = new JPanel();
			withdrawInfo.setForeground(Color.WHITE);
			withdrawInfo.setBorder(new TitledBorder(new LineBorder(new Color(0, 0, 0)), "Withdraw Information", TitledBorder.LEADING, TitledBorder.TOP, null, null));
			tabbedPane.addTab("Withdraw Info", new ImageIcon("Images\\with.png"), withdrawInfo, null);
			withdrawInfo.setLayout(null);
			
			JLabel lblWithdrawAmountInformation = new JLabel("Withdraw Amount Information");
			lblWithdrawAmountInformation.setBounds(355, 15, 550, 89);
			lblWithdrawAmountInformation.setForeground(Color.WHITE);
			lblWithdrawAmountInformation.setFont(new Font("Niagara Engraved", Font.PLAIN, 70));
			lblWithdrawAmountInformation.setHorizontalAlignment(SwingConstants.CENTER);
			withdrawInfo.add(lblWithdrawAmountInformation);
			
			JScrollPane scrollPane_4 = new JScrollPane();
			scrollPane_4.setViewportBorder(new TitledBorder(new LineBorder(new Color(255, 255, 255), 2), "Withdraw Data", TitledBorder.LEADING, TitledBorder.TOP, null, Color.WHITE));
			scrollPane_4.setBounds(15, 96, 1300, 269);
			withdrawInfo.add(scrollPane_4);
			
			withdrawAmount = new JTable();
			scrollPane_4.setViewportView(withdrawAmount);
			
			JPanel depositInfo = new JPanel();
			depositInfo.setForeground(Color.WHITE);
			depositInfo.setBorder(new TitledBorder(new LineBorder(new Color(0, 0, 0)), "Deposit Information", TitledBorder.LEADING, TitledBorder.TOP, null, null));
			tabbedPane.addTab("Deposit Info", new ImageIcon("Images\\depo.png"), depositInfo, null);
			depositInfo.setLayout(null);
			
			JLabel lblDepositAmountInformation = new JLabel("Deposit Amount Information");
			lblDepositAmountInformation.setHorizontalAlignment(SwingConstants.CENTER);
			lblDepositAmountInformation.setForeground(Color.WHITE);
			lblDepositAmountInformation.setFont(new Font("Niagara Engraved", Font.PLAIN, 70));
			lblDepositAmountInformation.setBounds(5, 15, 1320, 76);
			depositInfo.add(lblDepositAmountInformation);
			
			JScrollPane scrollPane_3 = new JScrollPane();
			scrollPane_3.setViewportBorder(new TitledBorder(new LineBorder(new Color(255, 255, 255), 2), "Deposit Data", TitledBorder.LEADING, TitledBorder.TOP, null, Color.WHITE));
			scrollPane_3.setBounds(15, 96, 1300, 269);
			depositInfo.add(scrollPane_3);
			
			depositAmount = new JTable();
			scrollPane_3.setViewportView(depositAmount);
		
			DBConnection();
			try
			{
				String query="Select * from admin where username='"+Authentication.userTextField.getText()+"'and password='"+Authentication.passTextField.getText()+"'";
				pst = con.prepareStatement(query);
				rs=pst.executeQuery();
				while(rs.next())
				{
					count++;
					rs.getString(1);
					rs.getString(2);
				}
				if(count>0)
				{
					nameLabel.setText( "Welcome "+Authentication.userTextField.getText());
				}
				else
				{
					Authentication.main(null);
					JOptionPane.showMessageDialog(null, "User Not Found.");
				}

			} 
			catch (SQLException e1)
			{
				JOptionPane.showMessageDialog(this, "Please Login From Admin Menu");
			}
			
			try 
			{
				DBConnection();
			String moneyTrans = "SELECT`senderName` as 'Sender Name', `accountNo` as 'Account Number', `TotalAmount` as 'Previous Amount', `tranAmo` as 'Trasnfer Amount', `recAccNo` as 'Reciever Account', `date`as 'Trasnfer Date' FROM `moneytransfer`";
			pst= con.prepareStatement(moneyTrans);
			rs = pst.executeQuery();
			moneyTrasnfer.setModel(DbUtils.resultSetToTableModel(rs));
			
			
			
			String moneyDepo= "SELECT `DepositrName` as 'Depositr Name' , `accountNo` as 'Account Number', `PerviousAmount` as 'Previous Amount', `addedAmount` as'Depositd Amount', `TotalAmount` as 'Total Amount', `date` as 'Depositd Date' FROM `moneydeposit`";
			pst= con.prepareStatement(moneyDepo);
			rs = pst.executeQuery();
			depositAmount.setModel(DbUtils.resultSetToTableModel(rs));
			
			String moneyWith= "SELECT  `WithdrawerName` as 'Withdrawer Name', `accountNo` as 'Account Number', `PreviousAmount` as'Previous Amount', `withdrawAmount`as'Amount Withdrawn', `RemainAmount` as'Remaining Amount', `date` as 'Withdrawn Date' FROM `moneywithdraw`";
			pst= con.prepareStatement(moneyWith);
			rs = pst.executeQuery();
			withdrawAmount.setModel(DbUtils.resultSetToTableModel(rs));
			
			
			} catch (SQLException e) {}
			
			serachUserData.setEnabled(false);
			
			label_19 = new JLabel("Copyright \u00A9 2017");
			label_19.setFont(new Font("Georgia", Font.PLAIN, 15));
			label_19.setBounds(20, 373, 132, 18);
			searchUser.add(label_19);
			
			JSeparator separator_2 = new JSeparator();
			separator_2.setBounds(12, 366, 1313, 10);
			searchUser.add(separator_2);
			
			searchUserBackImageLabel = new JLabel("");
			searchUserBackImageLabel.setIcon(new ImageIcon("Images\\backImg.png"));
			searchUserBackImageLabel.setBounds(2, 14, 1328, 440);
			searchUser.add(searchUserBackImageLabel);
			moneyTrasnfer.setEnabled(false);
			
			label_23 = new JLabel("Copyright \u00A9 2017");
			label_23.setFont(new Font("Georgia", Font.PLAIN, 15));
			label_23.setBounds(15, 383, 132, 18);
			moneyTransfer.add(label_23);
			
			separator_5 = new JSeparator();
			separator_5.setBounds(15, 376, 1313, 10);
			moneyTransfer.add(separator_5);
			
			monTransBackImageLabel = new JLabel("");
			monTransBackImageLabel.setBounds(2, 14, 1328, 440);
			monTransBackImageLabel.setHorizontalAlignment(SwingConstants.CENTER);
			monTransBackImageLabel.setIcon(new ImageIcon("Images\\backImg.png"));
			moneyTransfer.add(monTransBackImageLabel);
			withdrawAmount.setEnabled(false);
			
			label_24 = new JLabel("Copyright \u00A9 2017");
			label_24.setFont(new Font("Georgia", Font.PLAIN, 15));
			label_24.setBounds(15, 385, 132, 18);
			withdrawInfo.add(label_24);
			
			separator_7 = new JSeparator();
			separator_7.setBounds(15, 377, 1313, 10);
			withdrawInfo.add(separator_7);
			
			JLabel label_10 = new JLabel("");
			label_10.setBounds(2, 14, 1328, 440);
			label_10.setIcon(new ImageIcon("Images\\backImg.png"));
			label_10.setHorizontalAlignment(SwingConstants.CENTER);
			withdrawInfo.add(label_10);
			depositAmount.setEnabled(false);
			
			label_25 = new JLabel("Copyright \u00A9 2017");
			label_25.setFont(new Font("Georgia", Font.PLAIN, 15));
			label_25.setBounds(15, 387, 132, 18);
			depositInfo.add(label_25);
			
			separator_6 = new JSeparator();
			separator_6.setBounds(12, 376, 1313, 10);
			depositInfo.add(separator_6);
			
			JLabel label_14 = new JLabel("");
			label_14.setIcon(new ImageIcon("Images\\backImg.png"));
			label_14.setHorizontalAlignment(SwingConstants.CENTER);
			label_14.setBounds(2, 14, 1328, 440);
			depositInfo.add(label_14);
			table.setEnabled(false);
			
			label_22 = new JLabel("Copyright \u00A9 2017");
			label_22.setFont(new Font("Georgia", Font.PLAIN, 15));
			label_22.setBounds(20, 380, 132, 18);
			showAllUser.add(label_22);
			
			separator_4 = new JSeparator();
			separator_4.setBounds(10, 373, 1313, 10);
			showAllUser.add(separator_4);
			
			JLabel userDataBackImageLabel = new JLabel("");
			userDataBackImageLabel.setBounds(2, 14, 1328, 440);
			userDataBackImageLabel.setIcon(new ImageIcon("Images\\backImg.png"));
			showAllUser.add(userDataBackImageLabel);
			
			logout = new JLabel("");
			logout.addMouseListener(new MouseAdapter() {
				@Override
				public void mouseEntered(MouseEvent arg0) {
					logout.setIcon(new ImageIcon("Images\\adLog.png"));
				}
				@Override
				public void mouseExited(MouseEvent e) {
					logout.setIcon(new ImageIcon("Images\\adLog1.png"));
				}
				@Override
				public void mouseClicked(MouseEvent e) {
					if(JOptionPane.showConfirmDialog(null, "Are you Sure?","", JOptionPane.YES_NO_OPTION)==JOptionPane.YES_NO_OPTION)
					{
					setVisible(false);
					Authentication.main(null);
				}
				}
			});
			logout.setHorizontalAlignment(SwingConstants.CENTER);
			logout.setIcon(new ImageIcon("Images\\adLog1.png"));
			logout.setBounds(0, 0, 74, 65);
			panel.add(logout);
			
			
			}
}
