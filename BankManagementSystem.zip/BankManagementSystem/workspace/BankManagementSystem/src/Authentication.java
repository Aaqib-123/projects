import java.awt.*;

import javax.swing.*;
import javax.swing.border.*;

import java.awt.event.*;
import java.sql.*;


public class Authentication extends JFrame {

	private JPanel contentPane;
	public  static JTextField userTextField;
	public static JPasswordField passTextField;
	public JComboBox comboBox;
	JLabel wrongPassMsg;
	int attempts =4;
	
	Connection con = null;
	

	public void DBConnection()
	{
		String driver = "com.mysql.jdbc.Driver";
		String url  = "jdbc:mysql://localhost:3306/BankManagementSystem";
		String user = "root";
		String pass = "";
		try 
		{
			Class.forName(driver);
			con = DriverManager.getConnection(url,user,pass);
		}
		catch (ClassNotFoundException | SQLException e) 
		{
			JOptionPane.showMessageDialog(this, "Exception Occured");
		}
		
		
	}
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			@Override
			public void run() {
				try {
					 UIManager.setLookAndFeel("com.jtattoo.plaf.hifi.HiFiLookAndFeel");
					 Authentication frame = new Authentication();
					 frame.setVisible(true);
				} catch (Exception e) {
				e.printStackTrace();
}
			}
		});
	}
	public Authentication(){
		addMouseListener(new MouseAdapter() {
			@Override
			public void mouseReleased(MouseEvent arg0) {
				setOpacity(1.0f);
			}
		});
		addMouseMotionListener(new MouseMotionAdapter() {
			@Override
			public void mouseDragged(MouseEvent arg0) {
				setOpacity(0.7f);
			}
		});
		setIconImage(Toolkit.getDefaultToolkit().getImage("Images\\logoIcon.png"));
		setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 799, 493);
		setLocationRelativeTo(null);
		setResizable(false);
		setTitle("Admin Login");
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setForeground(Color.BLACK);
		panel.setBounds(0, 0, 783, 453);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblLogin = new JLabel("Login Menu");
		lblLogin.setHorizontalAlignment(SwingConstants.CENTER);
		lblLogin.setForeground(Color.WHITE);
		lblLogin.setFont(new Font("Niagara Engraved", Font.PLAIN, 70));
		lblLogin.setBounds(226, 166, 319, 65);
		panel.add(lblLogin);
		
		JLabel logoImgLabel = new JLabel("");
		logoImgLabel.setIcon(new ImageIcon("Images\\loginIcon.png"));
		logoImgLabel.setBounds(77, 116, 128, 128);
		panel.add(logoImgLabel);
		
		JButton btnLogin = new JButton("Login");
		btnLogin.setToolTipText("Hit Login Button To Enter");
		btnLogin.setIcon(new ImageIcon("Images\\log.png"));
		btnLogin.setForeground(Color.BLACK);
		btnLogin.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) 
			{
				DBConnection();
				int count=0;
				PreparedStatement pst=null;
				ResultSet rs = null;
				if((userTextField.getText().equals("") && passTextField.getText().equals("")))
				{
					JOptionPane.showMessageDialog(null, "Invalid Credintial");
				}
				else if(comboBox.getSelectedItem().equals("Admin"))
				{	
				try
				{
					String query1 = "Select * from admin where username='"+userTextField.getText()+"'and password='"+passTextField.getText()+"'";
					pst = con.prepareStatement(query1);
					rs=pst.executeQuery();
					while(rs.next())
					{
						count++;
						rs.getString(1);
						rs.getString(2);
					}
					if(count>0)
					{
						setVisible(false);
						Admin_Menu.main(null);
					}
					else
					{
						JOptionPane.showMessageDialog(null, "Admin Not Found.");
						setVisible(false);
						Authentication.main(null);
					}
				} 
				catch (SQLException e1)
				{
					JOptionPane.showMessageDialog(null, "Connection Error...!");
				}
				}
			else if(comboBox.getSelectedItem().equals("User"))
				{
					try
					{
						String query2 ="SELECT uname,password FROM `useraccount_data` WHERE`uname`='"+userTextField.getText()+"' and `password`='"+passTextField.getText()+"'";
						pst = con.prepareStatement(query2);
						rs=pst.executeQuery();
						while(rs.next())
						{
							count++;
							rs.getString(1);
							rs.getString(2);
						}
						if(count>0)
						{
							setVisible(false);
							User_Menu.main(null);
						}
						else
						{
							attempts--;
							wrongPassMsg.setForeground(Color.red);
							wrongPassMsg.setFont(new Font("",Font.BOLD,13));
							wrongPassMsg.setText( "Wrong Password..! \nTotal Attempts ".toUpperCase()+attempts);
							
							if(attempts ==0)
							{
								if (JOptionPane.showConfirmDialog(null,"Do you want to Update Password?","Please confirm",JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION)
								{
								setVisible(false);
								Update_Password.main(null);
								}
								else
								{JOptionPane.showMessageDialog (null, "System is Closing See You Again", "Closing System", JOptionPane.ERROR_MESSAGE);
									try {
										Thread.sleep(1000);
										System.exit(0);
									} catch (InterruptedException e1) {
										JOptionPane.showMessageDialog(null, "System Crashed");
									}
									
								}
							}
							
						}
					} 
					catch (SQLException e1)
					{
						JOptionPane.showMessageDialog(null, "Connection Error...!");
					}
					finally
					{try 
						{
							rs.close();
							pst.close();
						} 
						catch (SQLException e1) {
							
						}
					}}}
		});
		btnLogin.setFocusPainted(false);
		btnLogin.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		btnLogin.setBorderPainted(false);
		btnLogin.setBorder(null);
		btnLogin.setFont(new Font("Stencil", Font.PLAIN, 20));
		btnLogin.setBounds(286, 394, 125, 37);
		panel.add(btnLogin);
		
		JLabel lblUsername = new JLabel("Username :");
		lblUsername.setForeground(Color.WHITE);
		lblUsername.setFont(new Font("Imprint MT Shadow", Font.PLAIN, 24));
		lblUsername.setBounds(110, 255, 141, 25);
		panel.add(lblUsername);
		
		JLabel lblPassword = new JLabel("Password :");
		lblPassword.setForeground(Color.WHITE);
		lblPassword.setFont(new Font("Imprint MT Shadow", Font.PLAIN, 24));
		lblPassword.setBounds(109, 298, 142, 25);
		panel.add(lblPassword);
		
		userTextField = new JTextField();
		userTextField.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent ke) {
				if(ke.getKeyChar()>='a' && ke.getKeyChar()<='z' ||ke.getKeyChar()>='A' && ke.getKeyChar()<='Z' ||ke.getKeyChar()==' ')
				{}
				else
				{
					
					ke.consume();
				}
			}
			@Override
			public void keyReleased(KeyEvent ke) {
				if(ke.getKeyCode() == KeyEvent.VK_BACK_SPACE)
				{}else{ke.consume();}
			}
		});
		userTextField.setToolTipText("Enter Username to login");
		userTextField.setHorizontalAlignment(SwingConstants.LEFT);
		userTextField.setForeground(Color.WHITE);
		userTextField.setOpaque(false);
		userTextField.setFont(new Font("Times New Roman", Font.PLAIN, 18));
		userTextField.setBounds(257, 255, 225, 30);
		panel.add(userTextField);
		userTextField.setColumns(10);
		
		passTextField = new JPasswordField();
		passTextField.setToolTipText("Enter Password to Login");
		passTextField.setHorizontalAlignment(SwingConstants.LEFT);
		passTextField.setForeground(Color.WHITE);
		passTextField.setOpaque(false);
		passTextField.setFont(new Font("Times New Roman", Font.PLAIN, 18));
		passTextField.setBounds(257, 298, 225, 30);
		panel.add(passTextField);
		
		JCheckBox passChkBox = new JCheckBox("Show Password");
		passChkBox.setToolTipText("Check to See Password");
		passChkBox.setHorizontalAlignment(SwingConstants.LEFT);
		passChkBox.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				if(passChkBox.isSelected())
				{
					passTextField.setEchoChar((char)0);
					passChkBox.setText("Hide Password");
				}
				else
				{
					passTextField.setEchoChar('*');
					passChkBox.setText("Show Password");
				}
			}
		});
		passChkBox.setForeground(Color.WHITE);
		passChkBox.setFont(new Font("Serif", Font.PLAIN, 16));
		passChkBox.setOpaque(false);
		passChkBox.setBounds(522, 301, 154, 31);
		panel.add(passChkBox);
		LineBorder lineBorder =new LineBorder(Color.white, 1, true);
		userTextField.setBorder(lineBorder);
		passTextField.setBorder(lineBorder);
		
		comboBox = new JComboBox();
		comboBox.setEditable(true);
		comboBox.setBackground(Color.BLACK);
		 
		comboBox.setToolTipText("Select Admin or User");
		comboBox.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		comboBox.setFocusable(false);
		comboBox.setOpaque(false);
		comboBox.setForeground(Color.WHITE);
		comboBox.setFont(new Font("Century", Font.PLAIN, 20));
		comboBox.setModel(new DefaultComboBoxModel(new String[] {"Admin", "User"}));
		comboBox.setBounds(257, 339, 225, 30);
		panel.add(comboBox);
		comboBox.setBorder(lineBorder);
		
		JLabel lblNewLabel_1 = new JLabel("Login As :");
		lblNewLabel_1.setForeground(Color.WHITE);
		lblNewLabel_1.setFont(new Font("Imprint MT Shadow", Font.PLAIN, 24));
		lblNewLabel_1.setBounds(110, 339, 141, 30);
		panel.add(lblNewLabel_1);
		
		JLabel lblBankManagementSystem = new JLabel("Bank Management System");
		lblBankManagementSystem.setHorizontalAlignment(SwingConstants.CENTER);
		lblBankManagementSystem.setFont(new Font("Niagara Engraved", Font.PLAIN, 99));
		lblBankManagementSystem.setBounds(0, 22, 773, 100);
		panel.add(lblBankManagementSystem);
		
		JLabel label = new JLabel("");
		label.setToolTipText("Password");
		label.setIcon(new ImageIcon("Images\\pass.png"));
		label.setBounds(492, 304, 24, 24);
		panel.add(label);
		
		JLabel lblNewLabel_2 = new JLabel("");
		lblNewLabel_2.setToolTipText("Username");
		lblNewLabel_2.setIcon(new ImageIcon("Images\\user.png"));
		lblNewLabel_2.setBounds(492, 255, 24, 24);
		panel.add(lblNewLabel_2);
		
		 wrongPassMsg = new JLabel("");
		 wrongPassMsg.setFont(new Font("Serif", Font.BOLD, 12));
		 wrongPassMsg.setBounds(492, 339, 281, 30);
		 panel.add(wrongPassMsg);
		 
		 JLabel lblNewLabel = new JLabel("");
		 lblNewLabel.setFont(new Font("Imprint MT Shadow", Font.PLAIN, 24));
		 lblNewLabel.setForeground(Color.WHITE);
		 lblNewLabel.setIcon(new ImageIcon("Images\\backImg.png"));
		 lblNewLabel.setBounds(0, 0, 783, 453);
		 panel.add(lblNewLabel);

	}
}
