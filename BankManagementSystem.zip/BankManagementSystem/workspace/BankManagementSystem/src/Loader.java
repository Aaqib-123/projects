import javax.swing.*;
import javax.swing.border.*;

import com.jgoodies.forms.factories.DefaultComponentFactory;

import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;
public class Loader extends JFrame {

	private JPanel contentPane;
	public static 	JProgressBar progressBar;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			@Override
			public void run() {
				try {
					 UIManager.setLookAndFeel("com.jtattoo.plaf.hifi.HiFiLookAndFeel");
					Loader frame = new Loader();
					frame.setVisible(true);
					frame.setResizable(false);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Loader() {
		addMouseListener(new MouseAdapter() {
			@Override
			public void mouseReleased(MouseEvent arg0) {
				setOpacity(1.0f);
			}
		});
		addMouseMotionListener(new MouseMotionAdapter() {
			@Override
			public void mouseDragged(MouseEvent arg0) {
				setOpacity(0.7f);
			}
		});
		setIconImage(Toolkit.getDefaultToolkit().getImage("Images\\logoIcon.png"));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setTitle("Homepage");
		setBounds(100, 100, 798, 453);
		contentPane = new JPanel();
		setResizable(false);
		setLocationRelativeTo(null);
		contentPane.setBorder(new LineBorder(new Color(0, 0, 0), 2));
		setContentPane(contentPane);
		setBackground(Color.black);
		contentPane.setLayout(null);
		
		JLabel lblBankManagementSystem = DefaultComponentFactory.getInstance().createTitle("Bank Management System");
		lblBankManagementSystem.setBackground(Color.WHITE);
		lblBankManagementSystem.setForeground(Color.WHITE);
		lblBankManagementSystem.setHorizontalAlignment(SwingConstants.CENTER);
		lblBankManagementSystem.setFont(new Font("Niagara Engraved", Font.PLAIN, 99));
		lblBankManagementSystem.setBounds(10, 31, 762, 107);
		contentPane.add(lblBankManagementSystem);
		
		progressBar = new JProgressBar();
		progressBar.setFont(new Font("OCR A Extended", Font.PLAIN, 30));
		progressBar.setStringPainted(true);
		progressBar.setForeground(new Color(30, 144, 255));
		progressBar.setBounds(107, 175, 583, 43);
		contentPane.add(progressBar);
		
		 	JLabel msgLabel = new JLabel("Please be Patient while Loading....");
			msgLabel.setForeground(Color.WHITE);
			msgLabel.setHorizontalAlignment(SwingConstants.CENTER);
			msgLabel.setFont(new Font("Serif", Font.PLAIN, 20));
			msgLabel.setBounds(10, 245, 762, 43);
			contentPane.add(msgLabel);
			
			
			JLabel copyLabel = new JLabel("Copyright � 2017");
			copyLabel.setForeground(Color.WHITE);
			copyLabel.setHorizontalAlignment(SwingConstants.LEFT);
			copyLabel.setFont(new Font("Serif", Font.PLAIN, 15));
			copyLabel.setBounds(10, 370, 762, 43);
			contentPane.add(copyLabel);
		
		JLabel label = new JLabel("");
		label.setIcon(new ImageIcon("Images\\backImg.png"));
		label.setBounds(0, 0, 782, 414);
		contentPane.add(label);
	}
}
