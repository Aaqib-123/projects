import java.awt.*;

import javax.swing.*;
import javax.swing.border.*;

import com.jgoodies.forms.factories.DefaultComponentFactory;

import java.awt.event.*;
import java.sql.*;


public class Update_Password extends JFrame {

	private JPanel contentPane;
	private JTextField updateUserAccNo;
	private JTextField updatePassUname;
	Connection con = null;
	PreparedStatement  pst= null;
	ResultSet rs = null;
	int valid;
	int accNo;
	private JPasswordField newPass;
	private JPasswordField confNewPass;

	public void DBConnection()
	{
		String driver = "com.mysql.jdbc.Driver";
		String url  = "jdbc:mysql://localhost:3306/BankManagementSystem";
		String user = "root";
		String pass = "";
		try 
		{
			Class.forName(driver);
			con = DriverManager.getConnection(url,user,pass);
		}
		catch (ClassNotFoundException | SQLException e) 
		{
			JOptionPane.showMessageDialog(this, "Connection Error!");
		}		
	}
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			@Override
			public void run() {
				try {
					 UIManager.setLookAndFeel("com.jtattoo.plaf.hifi.HiFiLookAndFeel");
					Update_Password frame = new Update_Password();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Update_Password() {
		setResizable(false);
		
		setIconImage(Toolkit.getDefaultToolkit().getImage("Images\\logoImg.png"));
		addMouseListener(new MouseAdapter() {
			@Override
			public void mouseReleased(MouseEvent arg0) {
				setOpacity(1.0f);
			}
			@Override
			public void mouseDragged(MouseEvent arg0) {
				setOpacity(0.7f);
			}
			@Override
			public void mousePressed(MouseEvent arg0) {
				setOpacity(0.7f);
			}
		});
		setTitle("Password Update");
	
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 763, 399);
		setLocationRelativeTo(null);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblUpdateUserPassword = DefaultComponentFactory.getInstance().createTitle("Update User Password");
		lblUpdateUserPassword.setHorizontalAlignment(SwingConstants.CENTER);
		lblUpdateUserPassword.setVerticalAlignment(SwingConstants.TOP);
		lblUpdateUserPassword.setForeground(Color.WHITE);
		lblUpdateUserPassword.setFont(new Font("Niagara Engraved", Font.PLAIN, 110));
		lblUpdateUserPassword.setBounds(29, -1, 717, 108);
		contentPane.add(lblUpdateUserPassword);
		
		JSeparator separator = new JSeparator();
		separator.setBounds(10, 111, 726, 7);
		contentPane.add(separator);
		
		JLabel lblAccountNumber = new JLabel("Account Number  :");
		lblAccountNumber.setForeground(Color.WHITE);
		lblAccountNumber.setFont(new Font("Modern No. 20", Font.PLAIN, 20));
		lblAccountNumber.setBounds(220, 157, 150, 22);
		contentPane.add(lblAccountNumber);
		
		JLabel lblUsername = new JLabel("Enter Username   : ");
		lblUsername.setForeground(Color.WHITE);
		lblUsername.setFont(new Font("Modern No. 20", Font.PLAIN, 20));
		lblUsername.setBounds(220, 193, 162, 22);
		contentPane.add(lblUsername);
		
		updateUserAccNo = new JTextField();
		updateUserAccNo.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent e) {
				if(e.getKeyChar()>='0'&&e.getKeyChar()<='9')
				{}else
				{e.consume();}
			}
		});
		updateUserAccNo.setToolTipText("Please enter Account Number");
		updateUserAccNo.setBounds(380, 155, 200, 27);
		contentPane.add(updateUserAccNo);
		updateUserAccNo.setColumns(10);
		
		updatePassUname = new JTextField();
		updatePassUname.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent e) {
				if(e.getKeyChar()>='a'&&e.getKeyChar()<='z'||e.getKeyChar()>='A'&&e.getKeyChar()<='Z'||e.getKeyChar()==' ')
				{}else
				{e.consume();}
			}
		});
		updatePassUname.setToolTipText("Please enter Account Username");
		updatePassUname.setColumns(10);
		updatePassUname.setBounds(380, 191, 200, 27);
		contentPane.add(updatePassUname);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon("Images\\chpassImg.png"));
		lblNewLabel.setBounds(10, 118, 200, 194);
		contentPane.add(lblNewLabel);
		
		JButton btnUpdatePassword = new JButton("Update Password");
		btnUpdatePassword.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) { 
				DBConnection();
				
				if(updatePassUname.getText().equals("")||newPass.getText().equals("")||confNewPass.getText().equals("")||updateUserAccNo.getText().equals(""))
				{
					JOptionPane.showMessageDialog(null, "Please fill the Credintials First");
				}
				else
				{
					try{
						accNo =Integer.parseInt(updateUserAccNo.getText());}
					catch(NumberFormatException nf)
						{
							JOptionPane.showMessageDialog(null, "Invalid Account Number");
						}
				if(newPass.getText().equals(confNewPass.getText()))
				{
				String sql = "UPDATE `useraccount_data` SET `password`='"+newPass.getText()+"'  WHERE `accNo`='"+accNo+"' AND `uname`='"+updatePassUname.getText()+"'";
				try 
				{
					pst = con.prepareStatement(sql);
					valid= pst.executeUpdate();
					if(valid == 1)
					{
						JOptionPane.showMessageDialog(null, "Password Updated Successfully..!".toUpperCase());
					}
					else
					{
						JOptionPane.showMessageDialog(null, "Error During Password Update".toUpperCase());
					}
				} 
				catch (SQLException e) 
				{	
					JOptionPane.showMessageDialog(null, "SQL Conncetion Error...!".toUpperCase());
				}	

				}
				else
				{
					JOptionPane.showMessageDialog (null, "Password Mismatch ".toUpperCase(), "", JOptionPane.ERROR_MESSAGE);
				}
				
			}
			}
		});
		btnUpdatePassword.setIcon(new ImageIcon("Images\\changpass.png"));
		btnUpdatePassword.setForeground(Color.BLACK);
		btnUpdatePassword.setFont(new Font("Stencil", Font.PLAIN, 20));
		btnUpdatePassword.setFocusPainted(false);
		btnUpdatePassword.setBorderPainted(false);
		btnUpdatePassword.setBorder(null);
		btnUpdatePassword.setBounds(307, 320, 222, 37);
		contentPane.add(btnUpdatePassword);
		
		JLabel lblNewPassword = new JLabel("Enter Password    :");
		lblNewPassword.setForeground(Color.WHITE);
		lblNewPassword.setFont(new Font("Modern No. 20", Font.PLAIN, 20));
		lblNewPassword.setBounds(220, 229, 178, 22);
		contentPane.add(lblNewPassword);
		
		JLabel lblConfirmPassword = new JLabel("Confirm Password :");
		lblConfirmPassword.setForeground(Color.WHITE);
		lblConfirmPassword.setFont(new Font("Modern No. 20", Font.PLAIN, 20));
		lblConfirmPassword.setBounds(220, 265, 163, 22);
		contentPane.add(lblConfirmPassword);
		
		JLabel label_1 = new JLabel("");
		label_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent arg0) {

				label_1.setEnabled(true);
				newPass.setEchoChar((char)0);
			}
			@Override
			public void mouseReleased(MouseEvent e) {
				label_1.setEnabled(false);
				newPass.setEchoChar('*');
				newPass.setFont(new Font("",Font.BOLD,20));
			}
			
		});
		label_1.setIcon(new ImageIcon("Images\\sh.png"));
		label_1.setBounds(590, 227, 24, 24);
		contentPane.add(label_1);
		
		JLabel label_2 = new JLabel("");
		label_2.setFont(new Font("Tahoma", Font.PLAIN, 24));
		label_2.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent arg0) {
				label_2.setEnabled(true);
				confNewPass.setEchoChar((char)0);
			}
			@Override
			public void mouseReleased(MouseEvent e) {
				label_2.setEnabled(false);
				confNewPass.setEchoChar('*');
				confNewPass.setFont(new Font("",Font.BOLD,20));
				
			}
		});
		label_2.setIcon(new ImageIcon("Images\\sh.png"));
		label_2.setBounds(590, 263, 24, 24);
		contentPane.add(label_2);
		
		newPass = new JPasswordField();
		newPass.setToolTipText("Enter New Password");
		newPass.setText("");
		newPass.setBounds(380, 226, 200, 27);
		contentPane.add(newPass);
		
		confNewPass = new JPasswordField();
		confNewPass.setToolTipText("Confirm new Password");
		confNewPass.setBounds(380, 262, 200, 27);
		contentPane.add(confNewPass);
		
		JLabel label_3 = new JLabel("");
		label_3.setHorizontalAlignment(SwingConstants.CENTER);
		label_3.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent arg0) {
				label_3.setIcon(new ImageIcon("Images\\back1Up.png"));
			}
			@Override
			public void mouseExited(MouseEvent e) {
				label_3.setIcon(new ImageIcon("Images\\back1.png"));
			}
			@Override
			public void mouseClicked(MouseEvent e) {
				setVisible(false);
				Authentication.main(null);
			}
		});
		label_3.setIcon(new ImageIcon("Images\\back1.png"));
		label_3.setBounds(0, -1, 62, 61);
		contentPane.add(label_3);
		
		JLabel label_4 = new JLabel("Copyright \u00A9 2017");
		label_4.setFont(new Font("Georgia", Font.PLAIN, 15));
		label_4.setBounds(615, 329, 132, 18);
		contentPane.add(label_4);
		
		JSeparator separator_1 = new JSeparator();
		separator_1.setBounds(10, 312, 726, 7);
		contentPane.add(separator_1);
		
		JLabel label = new JLabel("");
		label.setIcon(new ImageIcon("Images\\backImg.png"));
		label.setBounds(0, 0, 746, 360);
		contentPane.add(label);
	}
}
