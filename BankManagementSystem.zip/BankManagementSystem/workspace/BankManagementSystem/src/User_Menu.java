import java.awt.*;

import javax.swing.*;
import javax.swing.border.*;

import java.sql.*;
import java.text.MessageFormat;
import java.awt.event.*;

import com.itextpdf.text.Document;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.pdf.PdfWriter;
import com.jgoodies.forms.factories.DefaultComponentFactory;

import java.io.*;
import java.util.Date;
import java.util.prefs.BackingStoreException;


public class User_Menu extends JFrame {

	private JPanel contentPane;
	int count=0;
	int Slipcount=0;
	
	private JTextField viewCnic;
	private JTextField viewName;
	private JTextField viewAcNo;
	private JTextField withName;
	private JTextField withAcNo;
	private JTextField withAvBal;
	private JTextField amoToWith;
	private JTextField transDate;
	private JTextField transAcNo;
	private JTextField transAvBal;
	private JTextField viewCont;
	private JTextField viewAvalBal;
	private JTextField viewActype;
	private JTextField transAmou;
	private JTextField transRecAcNo;
	private JTextField depName;
	private JTextField depAvlBal;
	private JTextField amoToDepo;
	private JTextField depAcNo;
	private JTextField viewPin;
	private JTextField viewEmail;
	private JTextField viewPreAdd;
	private JTextField viewPass;
	private JTextArea withSlipGen;

	Connection con = null;
	PreparedStatement  pst= null;
	ResultSet rs = null;
	int depoAmount =0 ;
	String d ;
	int withAmount =0 ;
	int val=0;
	
	int depoVal=0;
	int transVal=0;
	
	long recieverAccountNumber=0;
	
	int val1=0;
	int WithVal1=0;
	
	int trans =0 ;
	
	int transAmount=0;
	Date date = new Date();
	String date1= date.toString();
	private JTextField depoDate;
	private JTextField withDate;
	private JTextField remainBal;
	

	public void DBConnection()
	{
		String driver = "com.mysql.jdbc.Driver";
		String url  = "jdbc:mysql://localhost:3306/BankManagementSystem";
		String user = "root";
		String pass = "";
		try 
		{
			Class.forName(driver);
			con = DriverManager.getConnection(url,user,pass);
		}
		catch (ClassNotFoundException | SQLException e) 
		{
			JOptionPane.showMessageDialog(this, "Connection Error!");
		}		
	}
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			@Override
			public void run() {
				try {
					 UIManager.setLookAndFeel("com.jtattoo.plaf.hifi.HiFiLookAndFeel");
					User_Menu frame = new User_Menu();
					frame.setVisible(true);
				} catch (Exception e) {
					Authentication.main(null);
				}
			}
		});
	}
	public User_Menu(){
		setIconImage(Toolkit.getDefaultToolkit().getImage("Images\\logoIcon.png"));
		setResizable(false);
		addMouseListener(new MouseAdapter() {
			@Override
			public void mouseReleased(MouseEvent arg0) {
				setOpacity(1.0f);
			}
			@Override
			public void mouseDragged(MouseEvent arg0) {
				setOpacity(0.7f);
			}
		});
		setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 883, 502);
		setLocationRelativeTo(null);
		setTitle("User Menu");
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBounds(0, 0, 877, 466);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblUserData = new JLabel("User Menu");
		lblUserData.setHorizontalAlignment(SwingConstants.CENTER);
		lblUserData.setForeground(Color.WHITE);
		lblUserData.setFont(new Font("Niagara Engraved", Font.PLAIN, 99));
		lblUserData.setBounds(10, 0, 835, 96);
		panel.add(lblUserData);
		
		JTabbedPane tabbedPane = new JTabbedPane(SwingConstants.TOP);
		tabbedPane.setFont(new Font("Serif", Font.PLAIN, 22));
		tabbedPane.setBounds(0, 90, 870, 375);
		panel.add(tabbedPane);
		
		JPanel ViewBalance = new JPanel();
		tabbedPane.addTab("View Balance", new ImageIcon("Images\\mon.png"), ViewBalance, null);
		ViewBalance.setLayout(null);
		
		JLabel label_1 = new JLabel("Name");
		label_1.setForeground(Color.WHITE);
		label_1.setFont(new Font("Times New Roman", Font.BOLD, 20));
		label_1.setBounds(44, 88, 133, 24);
		ViewBalance.add(label_1);
		
		JLabel label_2 = new JLabel("AccountNo");
		label_2.setForeground(Color.WHITE);
		label_2.setFont(new Font("Times New Roman", Font.BOLD, 20));
		label_2.setBounds(44, 123, 133, 24);
		ViewBalance.add(label_2);
		
		JLabel lblNationalId = new JLabel("National ID");
		lblNationalId.setForeground(Color.WHITE);
		lblNationalId.setFont(new Font("Times New Roman", Font.BOLD, 20));
		lblNationalId.setBounds(44, 158, 133, 24);
		ViewBalance.add(lblNationalId);
		
		viewCnic = new JTextField();
		viewCnic.setHorizontalAlignment(SwingConstants.CENTER);
		viewCnic.setFont(new Font("Times New Roman", Font.PLAIN, 16));
		viewCnic.setEditable(false);
		viewCnic.setColumns(10);
		viewCnic.setBounds(186, 162, 220, 20);
		ViewBalance.add(viewCnic);
		
		viewName = new JTextField();
		viewName.setHorizontalAlignment(SwingConstants.CENTER);
		viewName.setFont(new Font("Times New Roman", Font.PLAIN, 16));
		viewName.setEditable(false);
		viewName.setColumns(10);
		viewName.setBounds(186, 92, 220, 20);
		ViewBalance.add(viewName);
		
		viewAcNo = new JTextField();
		viewAcNo.setHorizontalAlignment(SwingConstants.CENTER);
		viewAcNo.setFont(new Font("Times New Roman", Font.PLAIN, 16));
		viewAcNo.setEditable(false);
		viewAcNo.setColumns(10);
		viewAcNo.setBounds(186, 127, 220, 20);
		ViewBalance.add(viewAcNo);
		
		viewCont = new JTextField();
		viewCont.setHorizontalAlignment(SwingConstants.CENTER);
		viewCont.setFont(new Font("Times New Roman", Font.PLAIN, 16));
		viewCont.setEditable(false);
		viewCont.setColumns(10);
		viewCont.setBounds(186, 197, 220, 20);
		ViewBalance.add(viewCont);
		
		JLabel lblContect = new JLabel("Contect #");
		lblContect.setForeground(Color.WHITE);
		lblContect.setFont(new Font("Times New Roman", Font.BOLD, 20));
		lblContect.setBounds(44, 193, 133, 24);
		ViewBalance.add(lblContect);
		
		viewAvalBal = new JTextField();
		viewAvalBal.setHorizontalAlignment(SwingConstants.CENTER);
		viewAvalBal.setFont(new Font("Times New Roman", Font.PLAIN, 16));
		viewAvalBal.setEditable(false);
		viewAvalBal.setColumns(10);
		viewAvalBal.setBounds(602, 92, 220, 20);
		ViewBalance.add(viewAvalBal);
		
		JLabel label_13 = new JLabel("Avaliable Balance");
		label_13.setForeground(Color.WHITE);
		label_13.setFont(new Font("Times New Roman", Font.BOLD, 20));
		label_13.setBounds(441, 88, 151, 24);
		ViewBalance.add(label_13);
		
		viewActype = new JTextField();
		viewActype.setHorizontalAlignment(SwingConstants.CENTER);
		viewActype.setFont(new Font("Times New Roman", Font.PLAIN, 16));
		viewActype.setEditable(false);
		viewActype.setColumns(10);
		viewActype.setBounds(186, 234, 220, 20);
		ViewBalance.add(viewActype);
		
		JLabel lblAmount = new JLabel("Account Type");
		lblAmount.setForeground(Color.WHITE);
		lblAmount.setFont(new Font("Times New Roman", Font.BOLD, 20));
		lblAmount.setBounds(44, 230, 133, 24);
		ViewBalance.add(lblAmount);
		
		JLabel lblViewBalance = DefaultComponentFactory.getInstance().createTitle("User Details");
		lblViewBalance.setForeground(Color.WHITE);
		lblViewBalance.setHorizontalAlignment(SwingConstants.CENTER);
		lblViewBalance.setFont(new Font("Niagara Engraved", Font.PLAIN, 60));
		lblViewBalance.setBounds(0, 0, 870, 65);
		ViewBalance.add(lblViewBalance);
		
		viewPin = new JTextField();
		viewPin.setHorizontalAlignment(SwingConstants.CENTER);
		viewPin.setFont(new Font("Times New Roman", Font.PLAIN, 16));
		viewPin.setEditable(false);
		viewPin.setColumns(10);
		viewPin.setBounds(602, 128, 220, 20);
		ViewBalance.add(viewPin);
		
		viewEmail = new JTextField();
		viewEmail.setHorizontalAlignment(SwingConstants.CENTER);
		viewEmail.setFont(new Font("Times New Roman", Font.PLAIN, 16));
		viewEmail.setEditable(false);
		viewEmail.setColumns(10);
		viewEmail.setBounds(602, 163, 220, 20);
		ViewBalance.add(viewEmail);
		
		viewPreAdd = new JTextField();
		viewPreAdd.setHorizontalAlignment(SwingConstants.CENTER);
		viewPreAdd.setFont(new Font("Times New Roman", Font.PLAIN, 16));
		viewPreAdd.setEditable(false);
		viewPreAdd.setColumns(10);
		viewPreAdd.setBounds(602, 198, 220, 20);
		ViewBalance.add(viewPreAdd);
		
		JLabel lblPresentAddress = new JLabel("Present Address");
		lblPresentAddress.setForeground(Color.WHITE);
		lblPresentAddress.setFont(new Font("Times New Roman", Font.BOLD, 20));
		lblPresentAddress.setBounds(441, 194, 151, 24);
		ViewBalance.add(lblPresentAddress);
		
		JLabel lblEmailAddress = new JLabel("Email Address");
		lblEmailAddress.setForeground(Color.WHITE);
		lblEmailAddress.setFont(new Font("Times New Roman", Font.BOLD, 20));
		lblEmailAddress.setBounds(441, 159, 151, 24);
		ViewBalance.add(lblEmailAddress);
		
		JLabel lblPinCode = new JLabel("Pin Code");
		lblPinCode.setForeground(Color.WHITE);
		lblPinCode.setFont(new Font("Times New Roman", Font.BOLD, 20));
		lblPinCode.setBounds(441, 124, 105, 24);
		ViewBalance.add(lblPinCode);
		
		JLabel lblPassword = new JLabel("Password");
		lblPassword.setForeground(Color.WHITE);
		lblPassword.setFont(new Font("Times New Roman", Font.BOLD, 20));
		lblPassword.setBounds(441, 231, 151, 24);
		ViewBalance.add(lblPassword);
		
		viewPass = new JTextField();
		viewPass.setHorizontalAlignment(SwingConstants.CENTER);
		viewPass.setFont(new Font("Times New Roman", Font.PLAIN, 16));
		viewPass.setEditable(false);
		viewPass.setColumns(10);
		viewPass.setBounds(602, 235, 220, 20);
		ViewBalance.add(viewPass);
		
		JLabel label = new JLabel("Copyright \u00A9 2017");
		label.setFont(new Font("Georgia", Font.PLAIN, 15));
		label.setBounds(723, 300, 132, 18);
		ViewBalance.add(label);
		
		JSeparator separator = new JSeparator();
		separator.setBounds(10, 70, 845, 2);
		ViewBalance.add(separator);
		
		JSeparator separator_1 = new JSeparator();
		separator_1.setBounds(10, 279, 845, 10);
		ViewBalance.add(separator_1);
		
		JLabel label_10 = new JLabel("");
		label_10.setForeground(Color.WHITE);
		label_10.setIcon(new ImageIcon("Images\\backImg.png"));
		label_10.setBounds(0, 0, 870, 330);
		ViewBalance.add(label_10);
		
		JPanel Deposit = new JPanel();
		tabbedPane.addTab("Deposit", new ImageIcon("Images\\depo.png"), Deposit, null);
		Deposit.setLayout(null);
		
		JTextArea depoSlip = new JTextArea();
		depoSlip.setFont(new Font("Times New Roman", Font.PLAIN, 14));
		depoSlip.setTabSize(4);
		depoSlip.setCursor(Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR));
		depoSlip.setEditable(false);
		depoSlip.setBorder(new TitledBorder(new LineBorder(new Color(0, 0, 0)), "Deposit Slip", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(255, 255, 255)));
		depoSlip.setBounds(585, 15, 270, 285);
		Deposit.add(depoSlip);
		
		depName = new JTextField();
		depName.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		depName.setEditable(false);
		depName.setColumns(10);
		depName.setBounds(236, 79, 260, 20);
		Deposit.add(depName);
		
		JLabel lblDepositerName = new JLabel("Depositer Name");
		lblDepositerName.setForeground(Color.WHITE);
		lblDepositerName.setFont(new Font("Times New Roman", Font.BOLD, 20));
		lblDepositerName.setBounds(43, 79, 183, 24);
		Deposit.add(lblDepositerName);
		
		JLabel lblAccountNumber_1 = new JLabel("Account Number");
		lblAccountNumber_1.setForeground(Color.WHITE);
		lblAccountNumber_1.setFont(new Font("Times New Roman", Font.BOLD, 20));
		lblAccountNumber_1.setBounds(43, 110, 167, 24);
		Deposit.add(lblAccountNumber_1);
		
		JLabel label_12 = new JLabel("Avaliable Balance");
		label_12.setForeground(Color.WHITE);
		label_12.setFont(new Font("Times New Roman", Font.BOLD, 20));
		label_12.setBounds(43, 145, 151, 24);
		Deposit.add(label_12);
		
		depAvlBal = new JTextField();
		depAvlBal.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		depAvlBal.setEditable(false);
		depAvlBal.setColumns(10);
		depAvlBal.setBounds(236, 145, 260, 20);
		Deposit.add(depAvlBal);
		
		JLabel lblAmountToDeposit = new JLabel("Amount to Deposit");
		lblAmountToDeposit.setForeground(Color.WHITE);
		lblAmountToDeposit.setFont(new Font("Times New Roman", Font.BOLD, 20));
		lblAmountToDeposit.setBounds(43, 215, 183, 24);
		Deposit.add(lblAmountToDeposit);
		
		amoToDepo = new JTextField();
		amoToDepo.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent ke) {
				if(ke.getKeyChar()>='0' && ke.getKeyChar()<='9')
				{}
				else
				{
					
					ke.consume();
				}
			}
		});
		amoToDepo.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		amoToDepo.setColumns(10);
		amoToDepo.setBounds(236, 215, 260, 20);
		Deposit.add(amoToDepo);
		
		depAcNo = new JTextField();
		depAcNo.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		depAcNo.setEditable(false);
		depAcNo.setColumns(10);
		depAcNo.setBounds(236, 110, 260, 20);
		Deposit.add(depAcNo);
		
		JButton btnDeposite = new JButton("Deposite");
		btnDeposite.setIcon(new ImageIcon("Images\\deppp.png"));
		btnDeposite.setForeground(Color.BLACK);
		btnDeposite.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) 
			{
				if(amoToDepo.getText().equals(""))
				{
					JOptionPane.showMessageDialog(null, "Please Enter the Amount");
				}else{
				try{
					depoAmount = Integer.parseInt(amoToDepo.getText());					
				}catch(NumberFormatException e2){
					JOptionPane.showMessageDialog(null, "Amount Should be in Digits");
					}
				  val = Integer.parseInt(depAvlBal.getText());
				  if(depoAmount <500)
				  {
					  JOptionPane.showMessageDialog(null, "Amount Should be greater then 500 ".toUpperCase());
				  }
				  else
				  {
				  depoVal = depoAmount+val;
				try {
					d = viewAvalBal.getText();
					DBConnection();
					String deposit1= "INSERT INTO `moneydeposit`(`DepositrName`, `accountNo`, `PerviousAmount`, `addedAmount`, `TotalAmount`, `date`) VALUES (?,?,?,?,?,?)";
					pst = con.prepareStatement(deposit1);
					pst.setString(1, depName.getText());
					pst.setString(2, depAcNo.getText());
					pst.setString(3, depAvlBal.getText());
					pst.setInt(4, depoAmount);
					pst.setInt(5,depoVal);
					pst.setString(6, date1);
					int rs =pst.executeUpdate();
					if(rs == 1)
					{
					String deposit = "UPDATE `useraccount_data` SET`amount`='"+depoVal+"' WHERE `accNo`='"+depAcNo.getText()+"' and `uname`='"+depName.getText()+"'";
					pst = con.prepareStatement(deposit);
					pst.executeUpdate();
					JOptionPane.showMessageDialog(null, "Amount Deposite Successfully.");
					viewAvalBal.setText(""+depoVal);
					depAvlBal.setText(""+depoVal);
					withAvBal.setText(""+depoVal);
					transAvBal.setText(""+depoVal);
					}	
				} 
				
				catch (SQLException e1) {}
				
			}}
			}
		});
		btnDeposite.setFont(new Font("Stencil", Font.PLAIN, 20));
		btnDeposite.setFocusPainted(false);
		btnDeposite.setBorderPainted(false);
		btnDeposite.setBorder(null);
		btnDeposite.setBounds(43, 260, 150, 40);
		Deposit.add(btnDeposite);
		
		JButton btnGenerateSlip_1 = new JButton("Generate Slip");
		btnGenerateSlip_1.setIcon(new ImageIcon("Images\\silp.png"));
		btnGenerateSlip_1.setForeground(Color.BLACK);
		btnGenerateSlip_1.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				if(amoToDepo.getText().equals(""))
				{JOptionPane.showMessageDialog(null, "Enter Amount to Generate Slip");}else{
				depoSlip.setText("-----------------------------------------------------------------\n"+
								"***Bank Management System***".toUpperCase()+
								"\n---------------------------------------------------------------\n"
								+"\nAccount Username :   "+depName.getText()
								+"\nAccount Number   :   "+depAcNo.getText()
								+"\nPrevious Balance :   "+d
								+"\nDeposite Date    :   "+date1
								+"\nDeposited Amount :   "+depoAmount
								+"\nTotal Balance    :   "+(depoAmount+val)
								+"\n\n\tThanks".toUpperCase());
			}
				}
		});
		btnGenerateSlip_1.setFont(new Font("Stencil", Font.PLAIN, 20));
		btnGenerateSlip_1.setFocusPainted(false);
		btnGenerateSlip_1.setBorderPainted(false);
		btnGenerateSlip_1.setBorder(null);
		btnGenerateSlip_1.setBounds(204, 260, 205, 40);
		Deposit.add(btnGenerateSlip_1);
		
		JLabel lblDepositeMoney = DefaultComponentFactory.getInstance().createTitle("Deposit Money");
		lblDepositeMoney.setForeground(Color.WHITE);
		lblDepositeMoney.setHorizontalAlignment(SwingConstants.CENTER);
		lblDepositeMoney.setFont(new Font("Niagara Engraved", Font.PLAIN, 60));
		lblDepositeMoney.setBounds(0, 0, 881, 60);
		Deposit.add(lblDepositeMoney);
		
		JButton button_2 = new JButton("Print Slip");
		button_2.setIcon(new ImageIcon("Images\\prin.png"));
		button_2.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				try{
					if(amoToDepo.getText().equals(""))
					{
						JOptionPane.showMessageDialog(null, "Please enter the Amount First");
					}else
					{
				Document doc  = new Document();
				Slipcount++;
				PdfWriter.getInstance(doc, new FileOutputStream("DepositReceipt\\"+depAcNo.getText()+" Recipt"+Slipcount+" .pdf"));
				doc.open();
				doc.add(new Paragraph(depoSlip.getText().toString()));
				doc.close();
				JOptionPane.showMessageDialog(null, "Slip Generated Succssfully...");
				}}catch(DocumentException | FileNotFoundException e2)
				{
					JOptionPane.showMessageDialog(null, "No Data Found to Print Slip");
				}
			
			}
		});
		button_2.setForeground(Color.BLACK);
		button_2.setFont(new Font("Stencil", Font.PLAIN, 20));
		button_2.setFocusPainted(false);
		button_2.setBorderPainted(false);
		button_2.setBorder(null);
		button_2.setBounds(415, 260, 150, 40);
		Deposit.add(button_2);
		
		depoDate = new JTextField();
		depoDate.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		depoDate.setEditable(false);
		depoDate.setColumns(10);
		depoDate.setBounds(236, 180, 260, 20);
		Deposit.add(depoDate);
		
		JLabel lblDepositeDate = new JLabel("Deposite Date");
		lblDepositeDate.setForeground(Color.WHITE);
		lblDepositeDate.setFont(new Font("Times New Roman", Font.BOLD, 20));
		lblDepositeDate.setBounds(43, 180, 151, 24);
		Deposit.add(lblDepositeDate);
		
		JLabel label_4 = new JLabel("Copyright \u00A9 2017");
		label_4.setFont(new Font("Georgia", Font.PLAIN, 15));
		label_4.setBounds(723, 300, 132, 18);
		Deposit.add(label_4);
		
		JSeparator separator_2 = new JSeparator();
		separator_2.setBounds(10, 250, 566, 10);
		Deposit.add(separator_2);
		
		JSeparator separator_5 = new JSeparator();
		separator_5.setBounds(9, 70, 566, 10);
		Deposit.add(separator_5);
		
		JLabel label_8 = new JLabel("");
		label_8.setForeground(Color.WHITE);
		label_8.setIcon(new ImageIcon("Images\\backImg.png"));
		label_8.setBounds(0, 0, 870, 330);
		Deposit.add(label_8);
		
		JPanel withdraw = new JPanel();
		tabbedPane.addTab("Withdraw", new ImageIcon("Images\\with.png"), withdraw, null);
		withdraw.setLayout(null);
		
		withName = new JTextField();
		withName.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		withName.setEditable(false);
		withName.setBounds(238, 74, 260, 20);
		withName.setColumns(10);
		withdraw.add(withName);
		
		withAcNo = new JTextField();
		withAcNo.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		withAcNo.setEditable(false);
		withAcNo.setBounds(238, 101, 260, 20);
		withAcNo.setColumns(10);
		withdraw.add(withAcNo);
		
		withAvBal = new JTextField();
		withAvBal.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		withAvBal.setEditable(false);
		withAvBal.setBounds(238, 128, 260, 20);
		withAvBal.setColumns(10);
		withdraw.add(withAvBal);
		
		amoToWith = new JTextField();
		amoToWith.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent ke) {
				if(ke.getKeyChar()>='0' && ke.getKeyChar()<='9')
				{}
				else
				{
					
					ke.consume();
				}
			}
		});
		amoToWith.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		amoToWith.setBounds(238, 213, 260, 20);
		amoToWith.setColumns(10);
		withdraw.add(amoToWith);
		
		JLabel lblAmountToWithdraw = new JLabel("Amount to Withdraw");
		lblAmountToWithdraw.setBounds(32, 213, 176, 24);
		lblAmountToWithdraw.setForeground(Color.WHITE);
		lblAmountToWithdraw.setFont(new Font("Times New Roman", Font.BOLD, 20));
		withdraw.add(lblAmountToWithdraw);
		
		JLabel label_5 = new JLabel("Avaliable Balance");
		label_5.setBounds(32, 128, 162, 24);
		label_5.setForeground(Color.WHITE);
		label_5.setFont(new Font("Times New Roman", Font.BOLD, 20));
		withdraw.add(label_5);
		
		JLabel lblAccountNumber = new JLabel("Account Number");
		lblAccountNumber.setBounds(32, 101, 162, 24);
		lblAccountNumber.setForeground(Color.WHITE);
		lblAccountNumber.setFont(new Font("Times New Roman", Font.BOLD, 20));
		withdraw.add(lblAccountNumber);
		
		JLabel lblUsername = new JLabel("Username");
		lblUsername.setBounds(32, 70, 116, 24);
		lblUsername.setForeground(Color.WHITE);
		lblUsername.setFont(new Font("Times New Roman", Font.BOLD, 20));
		withdraw.add(lblUsername);
		
		JButton btnWithdraw = new JButton("Withdraw");
		btnWithdraw.setIcon(new ImageIcon("Images\\deo.png"));
		btnWithdraw.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				if(amoToWith.getText().equals(""))
				{JOptionPane.showMessageDialog(null,"Please Enter the Amount");
					}else{
				
				try{
					withAmount = Integer.parseInt(amoToWith.getText());					
				}catch(NumberFormatException e2){
					JOptionPane.showMessageDialog(null, "Amount Should be in Digits");
					}
				  val1 = Integer.parseInt(withAvBal.getText());
				 
				  if(withAmount < 500 || withAmount > val1)
				  {
						JOptionPane.showMessageDialog(null, "You can not withdraw the requested amount.".toUpperCase());  
				  }
				  else
				  {
				try {
					d = viewAvalBal.getText();
					 WithVal1 = val1-withAmount; 
					DBConnection();
					String withData = "INSERT INTO `moneywithdraw`(`WithdrawerName`, `accountNo`, `PreviousAmount`, `withdrawAmount`, `RemainAmount`, `date`) VALUES (?,?,?,?,?,?)";
					pst = con.prepareStatement(withData);
					pst.setString(1, withName.getText());
					pst.setString(2, withAcNo.getText());
					pst.setString(3, withAvBal.getText());
					pst.setInt(4, withAmount);
					pst.setInt(5, WithVal1);
					pst.setString(6, date1);
				int chk =pst.executeUpdate();
					if(chk==1)
					{					
					String withdraw = "UPDATE `useraccount_data` SET`amount`='"+WithVal1+"' WHERE `accNo`='"+depAcNo.getText()+"' and `uname`='"+depName.getText()+"'";
					pst = con.prepareStatement(withdraw);
					pst.executeUpdate();
					JOptionPane.showMessageDialog(null, "Amount Withdrawn Successfully.");
					viewAvalBal.setText(""+WithVal1);
					depAvlBal.setText(""+WithVal1);
					withAvBal.setText(""+d);
					transAvBal.setText(""+WithVal1);
					remainBal.setText(""+WithVal1);
					}
					else
					{
						JOptionPane.showMessageDialog(null, "Error..!During Withdraw");
							
					}
					}catch(SQLException e)
				{e.printStackTrace();}
			}
					}
			}
		});
		btnWithdraw.setForeground(Color.BLACK);
		btnWithdraw.setBounds(32, 260, 160, 40);
		btnWithdraw.setFont(new Font("Stencil", Font.PLAIN, 20));
		btnWithdraw.setFocusPainted(false);
		btnWithdraw.setBorderPainted(false);
		btnWithdraw.setBorder(null);
		withdraw.add(btnWithdraw);
		
		JButton btnGenerateSlip = new JButton("Generate Slip");
		btnGenerateSlip.setIcon(new ImageIcon("Images\\silp.png"));
		btnGenerateSlip.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				if(amoToWith.getText().equals(""))
				{
					JOptionPane.showMessageDialog(null, "Please Enter Amount to Generate Slip");
				}else{
				withSlipGen.setText("-----------------------------------------------------------------\n"+
						"*****Bank Management System*****".toUpperCase()+
						"\n---------------------------------------------------------------\n"
						+"Account Username :   "+withName.getText()
						+"\nAccount Number   :   "+withAcNo.getText()
						+"\nAvailable Amount :   "+d
						+"\nWithdrawn Date   :   "+date1
						+"\nWithdrawn Amount :   "+withAmount
						+"\nRemaining Balance:   "+remainBal.getText()
						+"\n\n\tThanks\n\n".toUpperCase());
			}}
		});
		btnGenerateSlip.setForeground(Color.BLACK);
		btnGenerateSlip.setBounds(204, 260, 205, 40);
		btnGenerateSlip.setFont(new Font("Stencil", Font.PLAIN, 20));
		btnGenerateSlip.setFocusPainted(false);
		btnGenerateSlip.setBorderPainted(false);
		btnGenerateSlip.setBorder(null);
		withdraw.add(btnGenerateSlip);
		
		withSlipGen = new JTextArea();
		withSlipGen.setFont(new Font("Times New Roman", Font.PLAIN, 14));
		withSlipGen.setTabSize(4);
		withSlipGen.setCursor(Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR));
		withSlipGen.setBounds(585, 15, 270, 285);
		withdraw.add(withSlipGen);
		withSlipGen.setEditable(false);
		withSlipGen.setBorder(new TitledBorder(new LineBorder(new Color(0, 0, 0)), "Generate Slip", TitledBorder.LEADING, TitledBorder.TOP, null, Color.WHITE));
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(585, 15, 270, 284);
		withdraw.add(scrollPane);
		
		JLabel lblWithdrawMoney = DefaultComponentFactory.getInstance().createTitle("Withdraw Money");
		lblWithdrawMoney.setForeground(Color.WHITE);
		lblWithdrawMoney.setHorizontalAlignment(SwingConstants.CENTER);
		lblWithdrawMoney.setFont(new Font("Niagara Engraved", Font.PLAIN, 60));
		lblWithdrawMoney.setBounds(0, 0, 881, 60);
		withdraw.add(lblWithdrawMoney);
		
		JButton btnPrintSlip = new JButton("Print Slip");
		btnPrintSlip.setIcon(new ImageIcon("Images\\prin.png"));
		btnPrintSlip.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
			try{
				if(amoToWith.getText().equals(""))
				{
					JOptionPane.showMessageDialog(null, "Please enter the Amount First");
				}else
				{
			Document doc  = new Document();
			int count=0;
			count++;
			PdfWriter.getInstance(doc, new FileOutputStream("WithdrawReceipt\\"+withAcNo.getText()+" Recipt"+count+" .pdf"));
			doc.open();
			doc.add(new Paragraph(withSlipGen.getText().toString()));
			doc.close();
			JOptionPane.showMessageDialog(null, "Slip Generated Succssfully...");
			}
			}catch(DocumentException|FileNotFoundException e)
			{
				JOptionPane.showMessageDialog(null, "Error During Slip Generation!");
			}
			
			}
		});
		btnPrintSlip.setForeground(Color.BLACK);
		btnPrintSlip.setFont(new Font("Stencil", Font.PLAIN, 20));
		btnPrintSlip.setFocusPainted(false);
		btnPrintSlip.setBorderPainted(false);
		btnPrintSlip.setBorder(null);
		btnPrintSlip.setBounds(419, 260, 150, 40);
		withdraw.add(btnPrintSlip);
		
		withDate = new JTextField();
		withDate.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		withDate.setEditable(false);
		withDate.setColumns(10);
		withDate.setBounds(238, 156, 260, 20);
		withdraw.add(withDate);
		
		JLabel lblWithdrawDate = new JLabel("Withdraw Date");
		lblWithdrawDate.setForeground(Color.WHITE);
		lblWithdrawDate.setFont(new Font("Times New Roman", Font.BOLD, 20));
		lblWithdrawDate.setBounds(32, 156, 197, 24);
		withdraw.add(lblWithdrawDate);
		
		JLabel lblRemainingBalance = new JLabel("Remaining Balance");
		lblRemainingBalance.setForeground(Color.WHITE);
		lblRemainingBalance.setFont(new Font("Times New Roman", Font.BOLD, 20));
		lblRemainingBalance.setBounds(32, 183, 197, 24);
		withdraw.add(lblRemainingBalance);
		
		remainBal = new JTextField();
		remainBal.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		remainBal.setEditable(false);
		remainBal.setColumns(10);
		remainBal.setBounds(238, 183, 260, 20);
		withdraw.add(remainBal);
		
		JLabel label_9 = new JLabel("Copyright \u00A9 2017");
		label_9.setFont(new Font("Georgia", Font.PLAIN, 15));
		label_9.setBounds(723, 300, 132, 18);
		withdraw.add(label_9);
		
		JSeparator separator_3 = new JSeparator();
		separator_3.setBounds(10, 250, 556, 10);
		withdraw.add(separator_3);
		
		JSeparator separator_6 = new JSeparator();
		separator_6.setBounds(10, 70, 566, 10);
		withdraw.add(separator_6);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setBounds(0, 0, 870, 330);
		lblNewLabel.setIcon(new ImageIcon("Images\\backImg.png"));
		withdraw.add(lblNewLabel);
		
		JPanel moneyTrans = new JPanel();
		tabbedPane.addTab("Money Transfer", new ImageIcon("Images\\tra.png"), moneyTrans, null);
		moneyTrans.setLayout(null);
		
		transDate = new JTextField();
		transDate.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		transDate.setEditable(false);
		transDate.setColumns(10);
		transDate.setBounds(226, 112, 260, 20);
		moneyTrans.add(transDate);
		
		JLabel lblTransferDate = new JLabel(" Transfer Date");
		lblTransferDate.setForeground(Color.WHITE);
		lblTransferDate.setFont(new Font("Times New Roman", Font.BOLD, 20));
		lblTransferDate.setBounds(33, 107, 151, 24);
		moneyTrans.add(lblTransferDate);
		
		JLabel lblAccountNo = new JLabel("Account Number");
		lblAccountNo.setForeground(Color.WHITE);
		lblAccountNo.setFont(new Font("Times New Roman", Font.BOLD, 20));
		lblAccountNo.setBounds(33, 72, 169, 24);
		moneyTrans.add(lblAccountNo);
		
		transAcNo = new JTextField();
		transAcNo.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		transAcNo.setEditable(false);
		transAcNo.setColumns(10);
		transAcNo.setBounds(226, 77, 260, 20);
		moneyTrans.add(transAcNo);
		
		JLabel label_6 = new JLabel("Avaliable Balance");
		label_6.setForeground(Color.WHITE);
		label_6.setFont(new Font("Times New Roman", Font.BOLD, 20));
		label_6.setBounds(33, 143, 151, 24);
		moneyTrans.add(label_6);
		
		transAvBal = new JTextField();
		transAvBal.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		transAvBal.setEditable(false);
		transAvBal.setColumns(10);
		transAvBal.setBounds(226, 148, 260, 20);
		moneyTrans.add(transAvBal);
		
		JLabel label_7 = new JLabel("Transfer Amount");
		label_7.setForeground(Color.WHITE);
		label_7.setFont(new Font("Times New Roman", Font.BOLD, 20));
		label_7.setBounds(33, 178, 151, 24);
		moneyTrans.add(label_7);
		
		JLabel lblRecieverAccount = new JLabel("Reciever Account #\r\n");
		lblRecieverAccount.setForeground(Color.WHITE);
		lblRecieverAccount.setFont(new Font("Times New Roman", Font.BOLD, 20));
		lblRecieverAccount.setBounds(33, 213, 183, 24);
		moneyTrans.add(lblRecieverAccount);
		
		transAmou = new JTextField();
		transAmou.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent ke) {
				if(ke.getKeyChar()>='0' && ke.getKeyChar()<='9' || ke.getKeyCode() == KeyEvent.VK_BACK_SPACE)
				{}
				else
				{
					
					ke.consume();
				}
			}
			
		});
		transAmou.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		transAmou.setColumns(10);
		transAmou.setBounds(226, 182, 260, 20);
		moneyTrans.add(transAmou);
		
		transRecAcNo = new JTextField(15);
		transRecAcNo.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent ke) {
				if(ke.getKeyChar()>='0' && ke.getKeyChar()<='9')
				{}
				else
				{
					
					ke.consume();
				}
			}
		});
		transRecAcNo.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		transRecAcNo.setColumns(10);
		transRecAcNo.setBounds(226, 217, 260, 20);
		moneyTrans.add(transRecAcNo);
		
		JTextArea transSlip = new JTextArea();
		transSlip.setTabSize(4);
		transSlip.setFont(new Font("Times New Roman", Font.PLAIN, 14));
		transSlip.setCursor(Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR));
		transSlip.setEditable(false);
		transSlip.setBorder(new TitledBorder(new LineBorder(new Color(0, 0, 0)), "Money Transfer Slip", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(255, 255, 255)));
		transSlip.setBounds(585, 15, 270, 285);
		moneyTrans.add(transSlip);
		
		JLabel lblMoneyTransfer = DefaultComponentFactory.getInstance().createTitle("Money Transfer");
		lblMoneyTransfer.setHorizontalAlignment(SwingConstants.CENTER);
		lblMoneyTransfer.setForeground(Color.WHITE);
		lblMoneyTransfer.setFont(new Font("Niagara Engraved", Font.PLAIN, 60));
		lblMoneyTransfer.setBounds(0, 0, 881, 65);
		moneyTrans.add(lblMoneyTransfer);
		
		JButton button = new JButton("Generate Slip");
		button.setIcon(new ImageIcon("Images\\silp.png"));
		button.setForeground(Color.BLACK);
		button.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				if(transAmou.getText().equals("") || transRecAcNo.getText().equals(""))
				{
					JOptionPane.showMessageDialog(null, "Please fill Credentials Generate Slip");
				}else{
				transSlip.setText("-----------------------------------------------------------------\n"+
						"*****Bank Management System*****".toUpperCase()+
						"\n---------------------------------------------------------------\n"
						+"\nSender Name   :  "+viewName.getText()
						+"\nTransfer Data :  "+date1
						+"\nAccount Number:  "+transAcNo.getText()
						+"\nTotal Amount  :  "+d
						+"\nTransfer Amount: "+transAmou.getText()
						+"\n\n\tThanks".toUpperCase());
			}
		}
		});
		button.setFont(new Font("Stencil", Font.PLAIN, 20));
		button.setFocusPainted(false);
		button.setBorderPainted(false);
		button.setBorder(null);
		button.setBounds(194, 260, 205, 40);
		moneyTrans.add(button);
		
		JButton btnTransfer = new JButton("Transfer");
		btnTransfer.setIcon(new ImageIcon("Images\\tras.png"));
		btnTransfer.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) 
			{
				DBConnection();
				if(transAvBal.getText().equals("")||transRecAcNo.getText().equals(""))
				{
					JOptionPane.showMessageDialog(null,	"Please fill the Credentials");
				}else{
				 try{transAmount = Integer.parseInt(transAmou.getText());}
				 catch(NumberFormatException ex)
				 {JOptionPane.showMessageDialog(null, "Amount Should be in Integer.");}
				 
				 try{recieverAccountNumber =Long.parseLong(transRecAcNo.getText());}
				 catch(NumberFormatException ex)
				 {JOptionPane.showMessageDialog(null, "Account Number Should be in Integer.");}
				 
				transVal = Integer.parseInt(transAvBal.getText());
				int afterTrans = Integer.parseInt(viewAvalBal.getText());
				
				
				if(transAmount > transVal )
				{
					JOptionPane.showMessageDialog(null, "you dont have enough balance to avail this service.".toUpperCase());
				}
				else
				{
					d = viewAvalBal.getText();
					String transfer= "INSERT INTO `moneytransfer`( `senderName`, `accountNo`, `TotalAmount`, `tranAmo`, `recAccNo`, `date`)"
							+ " VALUES (?,?,?,?,?,?)";
					try {
						pst= con.prepareStatement(transfer);
						pst.setString(1, viewName.getText());
						pst.setString(2, transAcNo.getText());
						pst.setInt(3,transVal);
						pst.setInt(4, transAmount);
						pst.setLong(5, recieverAccountNumber);
						pst.setString(6, date1);
						trans = pst.executeUpdate();
						if(trans == 1)
						{
						JOptionPane.showMessageDialog(null, "Transfer Successfully");
						int total = afterTrans-transAmount;
						viewAvalBal.setText(""+total);
						withAvBal.setText(""+total);
						depAvlBal.setText(""+total);
						transAvBal.setText(""+total);
						}
						else
						{
							JOptionPane.showMessageDialog(null, "Error! During Transfer");	
						}
						} catch (SQLException e) {}
				}}
				
			}
		});
		btnTransfer.setForeground(Color.BLACK);
		btnTransfer.setFont(new Font("Stencil", Font.PLAIN, 20));
		btnTransfer.setFocusPainted(false);
		btnTransfer.setBorderPainted(false);
		btnTransfer.setBorder(null);
		btnTransfer.setBounds(33, 260, 151, 40);
		moneyTrans.add(btnTransfer);
		
		JButton button_1 = new JButton("Print Slip");
		button_1.setIcon(new ImageIcon("Images\\prin.png"));
		button_1.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e)
			{
				try{
						if(transAmou.getText().equals("")||transRecAcNo.getText().equals(""))
							{
							JOptionPane.showMessageDialog(null, "Please fill the Credentials");
							}
						else
				{
					Document doc  = new Document();
					int count=0;
					count++;
					PdfWriter.getInstance(doc, new FileOutputStream("TransferReceipt\\"+transAcNo.getText()+" Recipt"+count+" .pdf"));
					
					doc.open();
					doc.add(new Paragraph(transSlip.getText().toString()));
					doc.close();
					JOptionPane.showMessageDialog(null, "Slip Generated Succssfully...!".toUpperCase());					
				}
					}
					catch(DocumentException | FileNotFoundException e3)
					{
						JOptionPane.showMessageDialog(null, "Error During Slip Generation!");
					}
			}
		});
		button_1.setForeground(Color.BLACK);
		button_1.setFont(new Font("Stencil", Font.PLAIN, 20));
		button_1.setFocusPainted(false);
		button_1.setBorderPainted(false);
		button_1.setBorder(null);
		button_1.setBounds(411, 260, 150, 40);
		moneyTrans.add(button_1);
		
		JLabel label_11 = new JLabel("Copyright \u00A9 2017");
		label_11.setFont(new Font("Georgia", Font.PLAIN, 15));
		label_11.setBounds(723, 300, 132, 18);
		moneyTrans.add(label_11);
		
		JSeparator separator_4 = new JSeparator();
		separator_4.setBounds(10, 250, 566, 10);
		moneyTrans.add(separator_4);
		
		JSeparator separator_7 = new JSeparator();
		separator_7.setBounds(9, 70, 566, 10);
		moneyTrans.add(separator_7);
		
		JLabel label_3 = new JLabel("");
		label_3.setIcon(new ImageIcon("Images\\backImg.png"));
		label_3.setForeground(Color.WHITE);
		label_3.setBounds(0, 0, 870, 330);
		moneyTrans.add(label_3);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBorder(new LineBorder(new Color(0, 0, 0)));
		panel_1.setBounds(629, 11, 238, 87);
		panel.add(panel_1);
		panel_1.setLayout(null);
		
		JLabel usernameLabel = new JLabel("");
		usernameLabel.setHorizontalAlignment(SwingConstants.CENTER);
		usernameLabel.setFont(new Font("Jokerman", Font.PLAIN, 20));
		usernameLabel.setBounds(0, 11, 238, 28);
		panel_1.add(usernameLabel);
		
		JLabel userDateLabel = new JLabel("");
		userDateLabel.setHorizontalAlignment(SwingConstants.CENTER);
		userDateLabel.setFont(new Font("Times New Roman", Font.PLAIN, 14));
		userDateLabel.setBounds(0, 50, 238, 26);
		panel_1.add(userDateLabel);
		
		
		DBConnection();
		
		try
		{
			String query=MessageFormat
					.format("SELECT * FROM `useraccount_data` where uname = ''{0}''and password = ''{1}''",
							Authentication.userTextField.getText(), Authentication.passTextField.getText());
			pst = con.prepareStatement(query);
			rs=pst.executeQuery();
			while(rs.next())
			{
				count++;
				viewName.setText(rs.getString(4));
				viewAcNo.setText(rs.getString(5));
				viewCnic.setText(rs.getString(6));
				viewCont.setText(rs.getString(14));
				viewActype.setText(rs.getString(15));
				viewAvalBal.setText(rs.getString(18));
				viewPin.setText(rs.getString(7));
				viewEmail.setText(rs.getString(10));
				viewPreAdd.setText(rs.getString(8));
				viewPass.setText(rs.getString(17));
				
				depName.setText(rs.getString(4));
				depAcNo.setText(rs.getString(5));
				depAvlBal.setText(rs.getString(18));
				depoDate.setText(date1);
				
				withName.setText(rs.getString(4));
				withAcNo.setText(rs.getString(5));
				withAvBal.setText(rs.getString(18));
				withDate.setText(""+date1);
				
				transDate.setText(date1);
				transAcNo.setText(rs.getString(5));
				transAvBal.setText(rs.getString(18));
				
			
			}
			if(count>0)
			{
				usernameLabel.setText( ""+Authentication.userTextField.getText());
				
				setVisible(false);
			}
			else
			{
				
				JOptionPane.showMessageDialog(null, "User Not Found.");
				setVisible(false);
				Authentication.main(null);
			}

		} 
		catch (SQLException e1)
		{
			JOptionPane.showMessageDialog(this, "Please Login From User Login");
		}
		userDateLabel.setText("Date : "+date1);
		
		JLabel logout = new JLabel("");
		logout.setToolTipText("Press To Logout");
		logout.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent arg0) {
				logout.setIcon(new ImageIcon("Images\\logout1.png"));
			}
			@Override
			public void mouseExited(MouseEvent e) {
				logout.setIcon(new ImageIcon("Images\\logout.png"));
			}
			@Override
			public void mouseClicked(MouseEvent e) {
				if(JOptionPane.showConfirmDialog(null, "Are you Sure?","", JOptionPane.YES_NO_OPTION)==JOptionPane.YES_NO_OPTION)
			{
			setVisible(false);
			Authentication.main(null);
		}}
		});
		logout.setHorizontalAlignment(SwingConstants.CENTER);
		logout.setIcon(new ImageIcon("Images\\logout.png"));
		logout.setBounds(0, 0, 61, 63);
		panel.add(logout);
			}
}
