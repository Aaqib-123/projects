import javax.swing.*;
public class Loading_Screen extends JFrame
{
	Loading_Screen()
	{
		setLocationRelativeTo(null);
		setResizable(false);
		
	}
	
	public static void main(String[] args)
	{
		try {
			 UIManager.setLookAndFeel("com.jtattoo.plaf.hifi.HiFiLookAndFeel");
		} catch (Exception e) {
			e.printStackTrace();
		}
	 int counter =0;
	 Loader  l = new Loader();
	 l.setVisible(true);
	 try
	 {
		 for( counter = 0;counter<=100;counter++)
		 {
			 Thread.sleep(100);
			 Loader.progressBar.setValue(counter);
		 
		 if(counter ==100)
		 {
			 l.dispose();
			 l.setVisible(false);
			 Authentication.main(null);
		 }
		 }
		 
	 }catch(InterruptedException e)
	 {
		 
	 }
	}

}
