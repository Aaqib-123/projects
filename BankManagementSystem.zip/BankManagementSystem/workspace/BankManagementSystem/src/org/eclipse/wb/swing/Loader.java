package org.eclipse.wb.swing;
import javax.swing.*;
import javax.swing.border.*;
import com.jgoodies.forms.factories.DefaultComponentFactory;
import java.awt.*;
public class Loader extends JFrame {

	private JPanel contentPane;
	public static 	JProgressBar progressBar;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			@Override
			public void run() {
				try {
					 UIManager.setLookAndFeel("com.jtattoo.plaf.hifi.HiFiLookAndFeel");
					Loader frame = new Loader();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Loader() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 798, 453);
		contentPane = new JPanel();
		contentPane.setBackground(Color.BLACK);
		contentPane.setBorder(new LineBorder(new Color(0, 0, 0), 2));
		setContentPane(contentPane);
		setBackground(Color.black);
		contentPane.setLayout(null);
		
		JLabel lblBankManagementSystem = DefaultComponentFactory.getInstance().createTitle("Bank Management System");
		lblBankManagementSystem.setBackground(Color.WHITE);
		lblBankManagementSystem.setForeground(Color.WHITE);
		lblBankManagementSystem.setHorizontalAlignment(SwingConstants.CENTER);
		lblBankManagementSystem.setFont(new Font("Niagara Engraved", Font.PLAIN, 99));
		lblBankManagementSystem.setBounds(10, 31, 762, 107);
		contentPane.add(lblBankManagementSystem);
		
		progressBar = new JProgressBar();
		progressBar.setFont(new Font("OCR A Extended", Font.PLAIN, 30));
		progressBar.setStringPainted(true);
		progressBar.setForeground(new Color(30, 144, 255));
		progressBar.setBounds(107, 175, 583, 43);
		contentPane.add(progressBar);
		
		JLabel counterLabel = new JLabel("");
		counterLabel.setBounds(336, 270, 110, 107);
		contentPane.add(counterLabel);
		
		JLabel msgLabel = new JLabel("Please be Patient while Loading....");
		msgLabel.setForeground(Color.WHITE);
		msgLabel.setHorizontalAlignment(SwingConstants.CENTER);
		msgLabel.setFont(new Font("Serif", Font.PLAIN, 20));
		msgLabel.setBounds(10, 245, 762, 43);
		contentPane.add(msgLabel);
		
		JLabel label = new JLabel("");
		label.setIcon(new ImageIcon("C:\\Users\\Muham\\Desktop\\Dr.Azhar\\Project\\bank Images\\backkk.png"));
		label.setBounds(0, 0, 782, 414);
		contentPane.add(label);
	}
}
