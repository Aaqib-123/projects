<?php
error_reporting(0);
include'connect.php';

$room=$_POST['room'];

$sql="DELETE from userData where room = $room";

	if($_POST['submit'])
	{
		if(mysqli_query($conn,$sql)== true)
		{
			echo "Data deleted Successfully..";
		}
		else
		{
			echo "Error..!Occured During Deletion..";
		}
	}
?>
<html>
<body>
<h2>Enter TO Delete the Data</h2>
<form action="deleteData.php" method="POST">
Room  :<input type="text" name ="room" required placeholder="Enter Room Number.."/><br/><br/>
<input type="submit" name ="submit" value="Delete"/><br/><br/>

</form>
</body>
</html>