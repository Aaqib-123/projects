<html>
<style>
body
{
background-image :URL("http://clevertechie.com/img/bnet-bg.jpg");
background-size : auto;
 background-repeat: no-repeat;
 background-attachment: fixed;

}
p
{
font-size : 20px;
}
#outerBox
{
margin-top : 5%;
width: 480px;
overflow :hidden;
}
#sliderBox
{
	position:relative;
	width:3840px;
	animation-name:Alamgir;
	animation-duration:32s;
	animation-iteration-count : infinite;
}
#sliderBox img
{
		float:left;
}
@keyframes Alamgir
{
	0%
	{
		left : 0px;
	}
	12.5%
	{
		left : 0px;
	}
	15.625%
	{
		left : -480px;
	}
	28.125%
	{
		left:-480px;
	}
	31.25%
	{
		left : -960px
	}
	43.75%
	{
		left : -960px
	}
	46.875%
	{
		left : -1440px
	}
	59.375%
	{
		left : -1440px;
	}
	62.5%
	{
		left : -1920px;
	}
	75%
	{
		left :-1920px;
	}
	78.125%
	{
		left : -2400px;
	}
	90.625%
	{
		left :-2400px;
	}
	93.75%
	{
		left :-2880px;
	}
	100%
	{
		left:-3360px;
	}
	
}


.topnav {
  overflow: hidden;
  background-color: #333;
  
}

.topnav a {
  float: left;
  display: block;
  color: white;
 padding :15px 12px;
  text-decoration: none;
  font-size : 30px;
}

.topnav a:hover {
  background-color: #ddd;
  color: black;
}

.topnav a.active {
    background-color: green;
    color: white;
	font-size : 30px;
}
input[ type="text"],input[ type="password"]
{
font-size:22px;
font-family:Times New Roman,arial;
text-align:left ;
}
.logo {

background-color: white;
	width : 100px;
	height: 64.5px;
	margin-bottom: -15px;
	margin-top :-16px;
	margin-left:-12px;
	margin-right : -12px;
}
a,p,h1
{
	color : white;
}
</style>
<body>
<nav class="topnav">
    <a href ="homepage.php"><img class="logo" src="pageImages/logo.png"></a>
    <a class ="active" href="Homepage.php">Home</a>
    <a href="Services.php">Services</a>
    <a href="contectUs.php">Contact Us</a>
    <a href="aboutUs.php">About US</a>
	<a href="login.php">Log in</a>
    <a href="signUp.php">Create Account</a>
</nav>
<center>
<h1>ELECTRICITY<h1>
		<div id="outerBox">
		<div id="sliderBox">
		<img src="pageImages/1 (1).jpg" />
		<img src="pageImages/1 (1).png" />
		<img src="pageImages/1 (2).jpg" />
		<img src="pageImages/1 (3).jpg" />
		<img src="pageImages/1 (4).jpg" />
		<img src="pageImages/1 (5).jpg" />
		<img src="pageImages/1 (6).jpg" />
		<img src="pageImages/1 (7).jpg" />
		</div>
		</div>
</center>
<ul>
<li>
<p>
Electricity is the presence and flow of electric charge. Its best-known form is the flow of electrons through conductors such as copper wires. Electricity is a form of energy that comes in positive and negative forms, that occur naturally (as in lightning), or is produced (as in generator).<br/>
</p>
</li>
</ul>
<ul>
<li>
<p>
In hostel full system of electricity.Electricity provide in hostel every time.</br></p>
</li>
</ul>
<ul>
<li><p>
When light gone then hostel authority provide a generator facility.</br></p>
</li>
</ul>
<ul>
<li>
<p>
For students easy when generator on. generator help for student to continue their study in exam day.
</p></br>
</li>
</ul>
</body>
</html>