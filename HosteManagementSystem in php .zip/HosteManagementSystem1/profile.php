<?php
session_start();
error_reporting(0);
$_SESSION['message'] = '';
$dbhost = 'localhost';
$dbroot = 'root';
$dbpassword = '';
$dbname = 'hms';

$conn =('$dbhost','$dbroot','','hms');
if($conn)
{
	$_SESSION['message'] = 'Connection established';
}
else
	{
		die();
		$_SESSION['message'] = "Error : connection Aborted ".$conn;
	}
?>