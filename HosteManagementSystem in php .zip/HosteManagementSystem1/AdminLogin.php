
<style>
body
{
 background-image : url("http://clevertechie.com/img/bnet-bg.jpg");
 background-size : 1500px;
 background-repeat: no-repeat;
 background-position: right top;
 background-attachment: fixed;
}
.form1
{
width: 300px;
height: 500px;
background-color :rgba(0,0,0,0.5);
margin-top: 10px;
padding-top: 10px;
padding-left: 30px;
padding-right: 30px; 
border-radius: 15px;
font-weight: bolder;
box-shadow:inset -5px -5px rgba(0,0,0,0.5);
font-size: 20px; 
}
div.container
{
font-size : 20px;
margin-top : -30px;
}
label
{
float:left;
color : black;
font-family:"Helvetica Neue", Helvetica, Arial, sans-serif;
color : white;
}
button
{
border-radius : 10px;
width :100px;
font-size : 20px;
margin-top : 5%;
font-family: "Helvetica Neue", Helvetica, Arial, sans-serif;
}
.imgcontainer
{
margin-top : -30px;
}

.topnav {
  overflow: hidden;
  background-color: #333;
  
}

.topnav a {
  float: left;
  display: block;
  color: white;
 padding :15px 12px;
  text-decoration: none;
  font-size : 30px;
}

.topnav a:hover {
  background-color: #ddd;
  color: black;
}

.topnav a.active {
    background-color: green;
    color: white;
	font-size : 30px;
}
input[ type="text"],input[ type="password"]
{
font-size:22px;
font-family:"Helvetica Neue", Helvetica, Arial, sans-serif;
text-align:left ;
}
.logo {

background-color: white;
	width : 100px;
	height: 64.5px;
	margin-bottom: -15px;
	margin-top :-16px;
	margin-left:-12px;
	margin-right : -12px;
}
a,h1
{
	color : white;
}
.avatar
{
	margin-top : 10%;
	width: 180px;
	height: 180px;
	
}
</style>
<html>
<head>
<title>User Login</title>
<head>
<body>
<nav class="topnav">
    <a href ="#"><img class="logo" src="pageImages/logo.png"></a>
    <a class ="active" href="#">Home</a>
    <a href="facilities.php">Facelities</a>
    <a href="#">Services</a>
	<a href="deleteData.php">Delete Data</a>
    <a href="adduser.php">Add User</a>
	<a href="AdminLogin.php">Log out</a>
</nav>
<center>

 <form class = "form1" method ="POST" action="welcome.php">
 <h1>Admin Login</h1>
  <div class="imgcontainer">
  
    <img src="pageImages/admin.png" alt="Avatar" class="avatar" />
  </div><br><br>

  <div class="container">
	
		<label><b>Username :</b></label><br/>
		<input type="text" required placeholder="Enter Username" name="username" size = "20px" ><br/>

		<label><b>Password :</b></label><br/>
		<input type="password" required placeholder="Enter Password" name="password" size ="20px"><br/>

		<button type="submit">Login</button><br/>	
  </div>
</form>
</center>
</body>