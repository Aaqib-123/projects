
<style>
body
{
background-image : url("http://clevertechie.com/img/bnet-bg.jpg");
background-size:auto;
}
.topnav {
  overflow: hidden;
  background-color: #333;
   margin-left : 30px;
}

.topnav a {
  float: left;
  color: white;
 padding :15px 12px;
  text-decoration: none;
  font-size : 30px;
  margin-left : 30px;
}

.topnav a:hover {
  background-color: #ddd;
  color: black;
   margin-left : 30px;
}

.topnav a.active {
    background-color: green;
    color: white;
	font-size : 30px;
	 margin-left : 0px;
}
.logo {

background-color: white;
	width : 100px;
	height: 64.5px;
	margin-bottom: -15px;
	margin-top :-16px;
	margin-left:-45px;
	margin-right : -12px;
	border-radius :0px;
}
a
{
	color : white;
	text-decoration :none;
}
</style>
<html>
<head>
<title>Facelities</title>
<head>
<body>
<nav class="topnav">
    <a href ="Homepage.php"><img class="logo" src="pageImages/logo.png"></a>
    <a class ="active" href="Homepage.php">Home</a>
    <a href="Services.php">Services</a>
    <a href="contectUs.php">Contact Us</a>
    <a href="aboutUs.php">About US</a>
	<a href="login.php">Log in</a>
    <a href="signUp.php">Create Account</a>
</nav>
<h2>
<a href="Er.php">Electricity</a>	 <br/>
<a href="lundary.php">Laundry</a>   <br/>
<a href="food.php">Food</a>     <br/>
<a href="water.html">Purified Water</a>       <br/>
<a href="internet.php">Internet</a>       <br/>

</h2>
</form>
</center>
</body>