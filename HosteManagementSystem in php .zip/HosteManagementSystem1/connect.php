<?php
	
	$dbserver = "localhost";
	$dbuser 	="root";
	$password = "";
	$dbName 	= "hms";
		
		$conn = new mysqli($dbserver, $dbuser,$password , $dbName);
	if($conn->connect_error)
	{
		die("Error: Connection Aborted ".$conn);
	}
?>