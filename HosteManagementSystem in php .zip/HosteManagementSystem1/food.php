<html>
<style>
body
{
background-image :URL("pageImages/bg1.jpg");
background-size : auto;
 background-repeat: no-repeat;
 background-attachment: fixed;
 }
.topnav {
  overflow: hidden;
  background-color: #333;
  
}
.topnav a {
  float: left;
  display: block;
  color: white;
 padding: 15px;
  text-decoration: none;
  font-size : 30px;
}

.topnav a:hover {
  background-color: #ddd;
  color: black;
}

.topnav a.active {
    background-color: green;
    color: white;
	font-size : 30px;
}

.logo {

background-color:white;
	width : 110px;
	height: 64.5px;
	margin-bottom: -15px;
	margin-top :-16px;
	margin-left:-16px;
	margin-right : -16px;
}
a
{
	color : white;
	text-decoration :none;
}

table,th,td
{
border:2px solid black;
border-collapse:collapse;
front-size:30px;
text-align:center;
margin-left:50px;
}
#outerBox
{
	margin-top : 2%;
width: 480px;
overflow :hidden;
}
#sliderBox
{
	position:relative;
	width:3840px;
	animation-name:Alamgir;
	animation-duration:32s;
	animation-iteration-count : infinite;
}
#sliderBox img
{
		float:left;
}
@keyframes Alamgir
{
	0%
	{
		left : 0px;
	}
	12.5%
	{
		left : 0px;
	}
	15.625%
	{
		left : -480px;
	}
	28.125%
	{
		left:-480px;
	}
	31.25%
	{
		left : -960px
	}
	43.75%
	{
		left : -960px
	}
	46.875%
	{
		left : -1440px
	}
	59.375%
	{
		left : -1440px;
	}
	62.5%
	{
		left : -1920px;
	}
	75%
	{
		left :-1920px;
	}
	78.125%
	{
		left : -2400px;
	}
	90.625%
	{
		left :-2400px;
	}
	93.75%
	{
		left :-2880px;
	}
	100%
	{
		left:-3360px;
	}
	
}
p,h3,h1,li,tr,td
{
color : white;
}
</style>
<head>
<title>Image Slider</title>
<link href="style.css" rel="stylesheet" type="text/css">
</head>
<body>
<nav class="topnav">
    <a href ="Homepage.php"><img class="logo" src="pageImages/logo.png"></a>
    <a class ="active" href="Homepage.php">Home</a>
    <a href="Services.php">Services</a>
    <a href="contectUs.php">Contact Us</a>
    <a href="aboutUs.php">About US</a>
	<a href="login.php">Log in</a>
    <a href="signUp.php">Create Account</a>
</nav>

<center>
<h1 style="font-size:50px"><i>Food</i></h1>
	<div id="outerBox">
		<div id="sliderBox">
		<img src="facilities/0 (1).jpg" />
		<img src="facilities/0 (2).jpg" />
		<img src="facilities/0 (3).jpg" />
		<img src="facilities/0 (4).jpg" />
		<img src="facilities/0 (5).jpg" />
		<img src="facilities/0 (6).jpg" />
		<img src="facilities/0 (7).jpg" />
		<img src="facilities/0 (8).jpg" />
		</div>
		</div>
</center>
</div>
<table >
  <tr>
  
  <th>Days</th>
    <th>breakfast	</th>
    <th>lunch	</th> 
    <th>Dinner	</th>
  </tr>
  
  
  <tr>
    <td>Monday</td>
    <td>Egg + Pratha</td>
	<td>dall</td>
	<td>Aloo chawal</td>
  </tr>
  <tr>
    <td>Tuesday</td>
    <td>Potato Pratha</td>
    <td>sabzi</td>
	<td>chikan kharai</td>
  </tr>
  <tr>
    <td>Wednesday</td>
    <td>paratha+tea</td>
    <td>lubia+putha khalgi</td>
	<td>chikan burani</td>
	
  </tr>
  <tr>
  <td>Thurseday</td>
  <td>Aloo paratha</td>
  <td>qurma</td>
  <td>qeema</td>
  
  </tr>
  <tr>
  <td>Friday</td>
  <td> paratha</td>
  <td>dall</td>
  <td>ahchar chawal</td>
  
  </tr>
  <tr>
  <td>Saturday</td>
  <td>tea+paratha</td>
  <td>kari pokura</td>
  <td>chiken</td>
  
  </tr>
  <tr>
  <td>Sunday</td>
  <td>paratha</td>
  <td>sabzi</td>
  <td>chawal</td>
  
  </tr>
</table>
<div class ="list">
	<ul>
		<li>Food in our hostel is very high quailty.</li>
		<li>Best cooker work in our hostal who make good foods.</li>
		<li>The system of cleanness is very good.</li>
		<li>Good oil use which make the person healty.</li>
		<li>Timing for Breakfast is 7:00am to 9:30am <br/> Timing for Lunch is 12:30pm to 3:00pm <br/> Timing for Dinner is 7:30pm to 10:30pm.</li>
	</ul>
</div>
</body>