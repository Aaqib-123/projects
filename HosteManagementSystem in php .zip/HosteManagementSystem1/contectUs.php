<html>
<head><title>Contact US</title></head>
<body>

<style>
body
{
	background-image :url(http://clevertechie.com/img/bnet-bg.jpg);
	 background-repeat: no-repeat;
    background-position: right top;
    background-attachment: fixed;
	 background-size : auto;
}
.card
{
	border : 2px solid powderblue;
    box-shadow: 0 4px 8px 0 rgba(0, 0, 0.5, 0.2);
	margin-top: 5%;
	width: 300px;
	height :390px;
	background-color : black;
	color :white;
	float :left;
	padding-left : 18px 18px  ;
	margin-left :5px;
}

.container {
	padding-left : -200px;
    
}
.container{
    content: "";
    clear: both;
    display: table;
}

.title {
    color: grey;
}

.button {
    display: inline-block;
    padding: 8px;
    color: black;
	font-weight :bolder;
    background-color: white;
    text-align: center;
    cursor: pointer;
    width: 290px;
	margin-left:5px;
}

.button:hover {
    background-color: #555;
}
.topnav {
  overflow: hidden;
  background-color: #333;
  
}

.topnav a {
  float: left;
  color: white;
 padding :15px 12px;
  text-decoration: none;
  font-size : 30px;
}

.topnav a:hover {
  background-color: #ddd;
  color: black;
}

.topnav a.active {
    background-color: green;
    color: white;
	font-size : 30px;
}
.logo {

background-color: white;
	width : 100px;
	height: 64.5px;
	margin-bottom: -15px;
	margin-top :-16px;
	margin-left:-12px;
	margin-right : -12px;
	border-radius :0px;
}
h1
{
	color : white;
	margin-left :500px;
}
img
{
	margin-left : 60px;
	border-radius :360px;
width : 180px;
height :200px;
}
</style>

<nav class="topnav">
    <a href ="Homepage.php"><img class="logo" src="pageImages/logo.png"></a>
    <a class ="active" href="Homepage.php">Home</a>
    <a href="facilities.php">Facelities</a>
    <a href="Services.php">Services</a>
    <a href="contectUs.php">Contact Us</a>
    <a href="aboutUs.php">About US</a>
    <a href="login.php">Log in</a>
    <a href="signUp.php">Create Account</a>
</nav>
<h1>Developer's Profile</h1>
<!--First card for the developers-->
<div class="row">
  <div class="column">
    <div class="card">
	<div class ="img">
      <img src="pageImages/alam.jpg" alt="mas" >
	  </div>
      <div class="container">
        <h2>Muhammad Alamgir Saeed</h2>
        <p class="title">CEO &amp; Founder</p>
        <p>MuhammadAlamgir10@gmail.com</p>
        <p>0301-8920491</p>
        <p><button class="button">Contact</button></p>
      </div>
    </div>
  </div>
<!--Second card for the developers-->  
  <div class="column">
    <div class="card">
	<div class ="img">
      <img src="pageImages/ik.jpg" alt="ik" >
     </div> 
	 <div class="container">
        <h2>Muhammad Irfan Khan</h2>
        <p class="title">Art Director</p>
        <p>Irfangulzar222@gmail.com</p>
        <p>0331-12346782</p>
        <p><button class="button">Contact</button></p>
      </div>
    </div>
  </div>
<!--Third card for the developers-->
  <div class="column">
    <div class="card">
      <div class ="img">
	  <img src="pageImages/ajk.png" alt="ajk">
      </div>
	  <div class="container">
        <h2>Aaqib Javed Khan Niazi</h2>
        <p class="title">Developer &amp; Designer</p>
        <p>AaqibJavedKhan91@gmail.com</p>
        <p>0300-0698588</p>
        <p><button class="button">Contact</button></p>
      </div>
    </div>
  </div>
<!--Forth card for the developers-->
   <div class="column">
    <div class="card">
      <div class ="img">
	  <img src="pageImages/hmza.jpg" alt="hn">
      </div>
	  <div class="container">
        <h2>Muhammad Hamza Nawaz</h2>
        <p class="title">Developer &amp; Designer</p>
        <p>Hamzanawaz123.hn@gmail.com</p>
        <p>0304-8521422</p>
        <p><button class="button">Contact</button></p>
      </div>
    </div>
  </div>
</div>
</body>
</html>