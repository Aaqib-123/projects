<?php
$user="root";
$pass="";
$host="localhost";
$db="hms";
$con=mysqli_connect($host,$user,$pass,$db);
if(isset($_POST['btn']))
{
	$cnic =$_POST['cnic'];
$sql= "SELECT CNIC FROM signup where CNIC='$cnic'";

$result=mysqli_query($conn,$sql);
if($result->num_rows == 1){

        ?>
        <script> window.location = "saveNewpass.php";</script>
        <?php
    }
}

?>

<style>
body
{
background-size:auto;
background-image : url("http://clevertechie.com/img/bnet-bg.jpg");
}
.container
{
width: 300px;
height: auto;
background-color :rgba(0,0,0,0.5);
margin-top: 80px;
padding-top: 10px;
padding-left: 30px;
padding-right: 30px; 
border-radius: 15px;
font-weight: bolder;
box-shadow:inset -5px -5px rgba(0,0,0,0.5);
font-size: 20px; 
margin-top : -30px;
}
label
{
margin-top : 10%;
float:left;
color : white;
font-family:Times New Roman,arial;
}
button{
  text-overflow: ellipsis;
  margin: 3px 0;
  padding: 6px 20px;
  font-size: 25px;
  line-height: 20px;
  height: 34px;
  background-color: rgba(0, 0, 0, 0.15);
  color: #00aeff;
  border: 1px solid rgba(255, 255, 255, 0.15);
  border-radius: 2px;
  }

.topnav {
  overflow: hidden;
  background-color: black;
  
}

.topnav a {
  float: left;
  display: block;
  color: white;
 padding :15px 12px;
  text-decoration: none;
  font-size : 30px;
}

.topnav a:hover {
  background-color: #ddd;
  color: black;
}

.topnav a.active {
    background-color: green;
    color: white;
	font-size : 30px;
}
input[ type="text"],input[ type="password"]
{
font-size:20px;
font-family:Times New Roman,arial;
text-align:left ;
}
.logo {

background-color: white;
	width : 100px;
	height: 63px;
	margin-bottom: -15px;
	margin-top :-16px;
	margin-left:-12px;
	margin-right : -12px;
}
a , h1,p
{
	color : white;
	text-decoration : none;
}
</style>
<html>
<head><title>Forget Password</title></head>
<form class = "forgPass" method ="POST" >
<body>
<nav class="topnav">
    <a href ="Homepage.php"><img class="logo" src="pageImages/logo.png"></a>
    <a class ="active" href="Homepage.php">Home</a> 
    <a href="facilities.php">Facelities</a> 
    <a href="Services.php">Services</a> 
    <a href="contectUs.php">Contact Us</a> 
    <a href="aboutUs.php">About US</a> 
	<a href="login.php">Log in</a> 
    <a href="userlogin.php">Create Account</a>
</nav>
<center>
<p style="font-size : 40px">Update Your Password</p>
<div class="container">
	
		<label><b>CNIC :</b></label><br/>
		<input type="text" required placeholder="Enter Your CNIC" name="username"  ><br/>

		<label><b>Password :</b></label><br/>
		<input type="password" required placeholder="Enter New Password" name="password1" ><br/>		
		
		
		<label><b>Confirm Password :</b></label><br/>
		<input type="password" required placeholder="Re-Enter New Password" name="password2" ><br/><br/><br/>
	
		<button type="submit" name = "btn">Update</button>
</div>
</center>
</form>
</body>
</html>