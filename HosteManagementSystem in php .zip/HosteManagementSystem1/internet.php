<html>
<head>  
<title> Internet</title>
<style>

body
{
background-image :URL("pageImages/bg1.jpg");
background-size : auto;
 background-repeat: no-repeat;
 background-attachment: fixed;
}

#outerBox
{
margin-top : 2%;
width: 480px;
overflow :hidden;
}
#sliderBox
{
	position:relative;
	width:3840px;
	animation-name:Alamgir;
	animation-duration:32s;
	animation-iteration-count : infinite;
}
#sliderBox img
{
		float:left;
}
@keyframes Alamgir
{
	0%
	{
		left : 0px;
	}
	12.5%
	{
		left : 0px;
	}
	15.625%
	{
		left : -480px;
	}
	28.125%
	{
		left:-480px;
	}
	31.25%
	{
		left : -960px
	}
	43.75%
	{
		left : -960px
	}
	46.875%
	{
		left : -1440px
	}
	59.375%
	{
		left : -1440px;
	}
	62.5%
	{
		left : -1920px;
	}
	75%
	{
		left :-1920px;
	}
	78.125%
	{
		left : -2400px;
	}
	90.625%
	{
		left :-2400px;
	}
	93.75%
	{
		left :-2880px;
	}
	100%
	{
		left:-3360px;
	}
	
}
p,h3,h1
{
color : white;
}

.topnav {
  overflow: hidden;
  background-color: #333;
 }

.topnav a {
  float: left;
  color: white;
 padding :15px 12px;
  text-decoration: none;
  font-size : 15px;
  margin-left : 30px;
}

.topnav a:hover {
  background-color: #ddd;
  color: black;
   margin-left : 30px;
}

.topnav a.active {
    background-color: green;
    color: white;
	font-size : 15px;
	 margin-left : 0px;
}
.logo {

background-color: white;
	width : 100px;
	height: 48px;
	margin-bottom: -15px;
	margin-top :-16px;
	margin-left:-45px;
	margin-right : -12px;
	border-radius :0px;
}
a,p
{
	color : white;
	text-decoration :none;
}

</style>
<body>
<nav class="topnav">
    <a href ="Homepage.php"><img class="logo" src="pageImages/logo.png"></a>
    <a class ="active" href="Homepage.php">Home</a>  
    <a href="Services.php">Services</a> 
    <a href="contectUs.php">Contact Us</a> 
    <a href="aboutUs.php">About US</a> 
	<a href="login.php">Log in</a> 
    <a href="signUp.php">Create Account</a>
</nav>
	
<center>
<h1 style="font-size : 40px;"> Internet Facilities </h1>

		<div id="outerBox">
		<div id="sliderBox">
		<img src="facilities/7 (1).jpg" />
		<img src="facilities/7 (1).png" />
		<img src="facilities/7 (2).jpg" />
		<img src="facilities/7 (2).png" />
		<img src="facilities/7 (3).jpg" />
		<img src="facilities/7 (3).png" />
		<img src="facilities/7 (4).jpg" />
		<img src="facilities/7 (5).png" />
		</div>
		</div>
</center>

<p>As u know that we are  living in modern era of technology <br/>where most of our work are being   done internet application.<br/></p> 
<p>So we are providing our resisdant fast internet <br/>through which they are done their works quickly and improve their daily routine works.<br/></p>
<p>you can connect your Mobile phone and laptops<br/> etc where internet speed is almost 15mbps with 3G and 4G innovation.</p>
</body>
</head>
</html>