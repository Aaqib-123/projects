<html>
<body>
<head>

<style>
body
{
background-image :URL("pageImages/bg1.jpg");
background-size : auto;
 background-repeat: no-repeat;
 background-attachment: fixed;
 }
.topnav {
  overflow: hidden;
  background-color: #333;
  
}
.topnav a {
  float: left;
  display: block;
  color: white;
 padding: 15px;
  text-decoration: none;
  font-size : 30px;
}

.topnav a:hover {
  background-color: #ddd;
  color: black;
}

.topnav a.active {
    background-color: green;
    color: white;
	font-size : 30px;
}

.logo {

background-color:white;
	width : 110px;
	height: 64.5px;
	margin-bottom: -15px;
	margin-top :-16px;
	margin-left:-16px;
	margin-right : -16px;
}
a
{
	color : white;
	text-decoration :none;
}

table,th,td
{
border:2px solid black;
border-collapse:collapse;
front-size:30px;
text-align:center;
margin-left:50px;
}
#outerBox
{
margin-top : 5%;
width: 480px;
overflow :hidden;
}
#sliderBox
{
	position:relative;
	width:3840px;
	animation-name:Alamgir;
	animation-duration:32s;
	animation-iteration-count : infinite;
}
#sliderBox img
{
		float:left;
}
@keyframes Alamgir
{
	0%
	{
		left : 0px;
	}
	12.5%
	{
		left : 0px;
	}
	15.625%
	{
		left : -480px;
	}
	28.125%
	{
		left:-480px;
	}
	31.25%
	{
		left : -960px
	}
	43.75%
	{
		left : -960px
	}
	46.875%
	{
		left : -1440px
	}
	59.375%
	{
		left : -1440px;
	}
	62.5%
	{
		left : -1920px;
	}
	75%
	{
		left :-1920px;
	}
	78.125%
	{
		left : -2400px;
	}
	90.625%
	{
		left :-2400px;
	}
	93.75%
	{
		left :-2880px;
	}
	100%
	{
		left:-3360px;
	}
	
}
p,h3,h1
{
color : white;
}

</style>
<nav class="topnav">
    <a href ="Homepage.php"><img class="logo" src="pageImages/logo.png"></a>
    <a class ="active" href="Homepage.php">Home</a>
    <a href="Services.php">Services</a>
    <a href="contectUs.php">Contact Us</a>
    <a href="aboutUs.php">About US</a>
	<a href="login.php">Log in</a>
    <a href="signUp.php">Create Account</a>
</nav>
<center>
<center>
		<div id="outerBox">
		<div id="sliderBox">
		<img src="facilities/a (1).jpg" />
		<img src="facilities/a (1).png" />
		<img src="facilities/a (2).jpg" />
		<img src="facilities/a (3).jpg" />
		<img src="facilities/a (4).jpg" />
		<img src="facilities/a (5).jpg" />
		<img src="facilities/a (6).jpg" />
		<img src="facilities/a (7).jpg" />
		</div>
		</div>
</center>

</center>
<div>
<title><h1>Laundry</h1></title>

</head>

<table style="width:90%">
  <tr>
 
  
 
<th><h1><i>Dry Clean</i></h1></th>
<th><h1><i>Press</i></h1></th>
<th><h1><i>Wash</i></h1></th>
	
  </tr>
  
 <tr>
 <td><b>15 Piece Per Month</b></td>
 <td><b>20 Piece Per Month</b></td>
 <td><b>30 Piece Per Month</b></td>
 </tr>
 
</table>
</div>
<center>
<h1> Laundry</h1>
</center>
<p>If it is not included in your laundry price, sell individual sachets of washing powder at reception.<br/> Another option besides commercially bought sachets is making your own mini ones out of plastic baggies.<br/> A bulk box of laundry soap.</p>
<p>
Have plenty of clotheslines  clothespins in a garden/outdoor area if possible.<br/> It allows guests to save money on drying and is better for the environment.<br/></p>
<p>Have lots and lots of hooks in rooms.<br/> </p>
<p>This is for multiple reasons, but in this section one reason could be
<br/> the ability to hang up small amounts of washing if clotheslines aren't available.</p>
</body>
</html>
