<?php
session_start();
$_SESSION['message'] = '';
$mysqli = new mysqli('localhost', 'root', '','hms');

if($_SERVER['REQUEST_METHOD'] == 'POST')
	{
		if($_POST['password'] == $_POST['confirmpassword'])
			{
				$fname =($_POST['fname']);
				$lname1 = ($_POST['lname']);
				$username =$_POST['username'];
				$cnic = ($_POST['cnic']);
				$email = ($_POST['email']);
				$password =($_POST['password']);
				$address = ($_POST['address']);
				$phone = ($_POST['phone']);
				$avatar_path =('images/'.$_FILES['avatar']['name']);
				$gender = ($_POST['gender']);
				
				if(preg_match('!image!',$_FILES['avatar']['type']))
					{
						if(copy($_FILES['avatar']['tmp_name'], $avatar_path))
						{
							$_SESSION['username'] = $username;
							$_SESSION['avatar'] = $avatar_path ;
							
$sql = "INSERT INTO signup(CNIC ,firstname, lastname ,username, email, address,phone , password ,gender,avatar_path ) "."VALUES ('$cnic','$fname','$lname1' ,'$username', '$email','$address','$phone' , '$password','$gender','$avatar_path' )";
								
								if($mysqli->query($sql) == true)
									{
										$_SESSION['message'] ="Registration Successfull.";
										header("location: login.php");
									}
								else
								{
									$_SESSION['message'] = "Registration Failed";
								}
						}
						else
						{
							$_SESSION['message'] = "File Upload Failed";
						}
					
					}
				else
				{
					$_SESSION['message'] = "Support Only JPG , PNG and GIF files";
				}
			}
			else
			{
				$_SESSION['message'] = "Sorry Password Mismatch. ";
			}
	}
?>
<html>
<head><title>Sign Up Page</title></head>

<body>
<style>
body
{
background-color:cyan;
background-image:url(http://clevertechie.com/img/bnet-bg.jpg);
background-size : 1500px ;
}
input[ type="text"],input[ type="password"]
{
	
font-size:15px;
font-family:Times New Roman,arial;
text-align:left ;
}



button{
  text-overflow: ellipsis;
  margin: 3px 0;
  padding: 6px 20px;
  font-size: 25px;
  line-height: 20px;
  height: 34px;
  background-color: rgba(0, 0, 0, 0.15);
  color: #00aeff;
  border: 1px solid rgba(255, 255, 255, 0.15);
  border-radius: 2px;
  }



label
{
float:left;
color : white;
font-family:Times New Roman,arial;
}
.formStyle
{
width: 300px;
height: 490px auto;
background-color :rgba(0,0,0,0.5);
margin-top: 30px;
padding-top: 10px;
padding-left: 30px;
padding-right: 30px; 
border-radius: 15px;
color: white;
font-weight: bolder;
 box-shadow:inset -5px -5px rgba(0,0,0,0.5)
font-size: 20px; 
}
label
{
float:red;
color : white;
font-family:Times New Roman,arial;
}
h1
{
	margin-top : 10px;
}
h2
{
	font-family : Times New Roman;
	font-size : 35px;
	margin-top : -10px;
}
.alert-error {
  color: #f00;
  background-color: #360e10;
  box-shadow: 0 0 0 1px #551e21 inset, 0 5px 10px rgba(0, 0, 0, 0.75);
  font-size : 20px;
}
.alert-success {
  color: green;
  background-color: #15360e;
  box-shadow: 0 0 0 1px #2a551e inset, 0 5px 10px rgba(0, 0, 0, 0.75);
}
a
{
	
font-family : Times New Roman;
	color : white;
	font-size: 23px;
}
.topnav {
  overflow: hidden;
  background-color: #333;
  height : 50px;
  
}
.topnav a {
  float: left;
  display: block;
  color: white;
 padding: 18px 14px;
  text-decoration: none;
  font-size : 20px;
}

.topnav a:hover {
  background-color: #ddd;
  color: black;
}

.topnav a.active {
    background-color: green;
    color: white;
	font-size : 20px;
	margin-left :3px;
}

.logo {

background-color: white;
	width : 100px;
	height: 50px;
	margin-bottom: -15px;
	margin-top :-16px;
	margin-left:-16px;
	margin-right : -16px;
}
a
{
	color : white;
	text-decoration :none;
}

</style>

<nav class="topnav">
    <a href ="Homepage.php"><img class="logo" src="pageImages/logo.png"></a>
    <a class ="active" href="Homepage.php">Home</a>
    <a href="facilities.php">Facelities</a>
    <a href="Services.php">Services</a>
    <a href="contectUs.php">Contact Us</a>
    <a href="aboutUs.php">About US</a>
	<a href="login.php">Log in</a>
</nav>
<center>
<form class = "formStyle" method = "POST">
 <div > 
 <h2> Sign Up Form</h2>
 <div class="alert alert-error"> <?= $_SESSION['message']?></div><br/>
 <label><b>First Name:</b></label><br/>
 <input type="text" placeholder="Enter First Name " name="fname" required><br/>
 
 
 <label><b>Last Name:</b></label><br/>
 <input type="text" placeholder="Enter Last Name " name="lname" required><br/>
 
 <label><b>CNIC :</b></label><br/>
 <input type="text" placeholder="Enter Your CNIC " name="cnic" required><br/>

 
 <label><b>Username:</b></label><br/>
 <input type="text" placeholder="Enter Your Username " name="username" required><br/>
 
 
 <label><b>Email:</b></label><br/>
 <input type="text" placeholder="Enter Email " name="email" required><br/>
 
 <label><b>Password:</b></label><br/>
 <input type="password" placeholder="Enter Password " name="password" required maxlength= "15"><br/>
 
 <label><b>Confirm Password:</b></label><br/>
 <input type="password" placeholder="Re-Enter Password " name="confirmpassword"  required maxlength ="15"><br/>
 
 
 <label><b>Address:</b></label><br/>
 <input type="text" placeholder="Enter Address " name="address" required><br/>
 

<label><b>Phone:</b></label><br/>
 <input type="text" placeholder="Enter Phone Number " name="phone" maxlength="12" required><br/><br/>
 
 <label><b>Gender:</b></label><br/>
<input type="radio" name="gender" value="female" required>Female
<input type="radio" name="gender" value="male" required>Male<br/>
 
 <div class="avatar"><label>Select your photo: </label><input type="file" name="avatar" accept="image/*" required /></div>

 <br/><button>Submit</button>
 
 
 
 </div>
<div>
<a href="login.php">Already have an account?</a>
</div>
 
 
 
</form>
</center>
</body>
</html>