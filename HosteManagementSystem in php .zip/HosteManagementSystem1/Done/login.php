
<?php
$user="root";
$pass="";
$host="localhost";
$db="hms";
$con=mysqli_connect($host,$user,$pass,$db);
$_SESSION['message']='';

if(isset($_POST['login']))
{

$username=$_POST['username'];
$password=$_POST['password'];
$cnic=$_POST['cnic'];

    $sql="SELECT * FROM signup WHERE username='$username'AND CNIC = '$cnic' AND password='$password'";
    $result = mysqli_query($con,$sql);

//echo $result;
    if($result->num_rows == 1){

        ?>
        <script> window.location = "Show.php";</script>
        <?php
    }
	else
	{
		$_SESSION['message']= "Error During Login ";
	}
}
?>
<style>
body
{
background-size:auto;
background-image : url("http://clevertechie.com/img/bnet-bg.jpg");
}
.form1
{
width: 300px;
height: auto;
background-color :rgba(0,0,0,0.5);
margin-top: 50px;
padding-top: 10px;
padding-left: 30px;
padding-right: 30px; 
border-radius: 15px;
font-weight: bolder;
box-shadow:inset -5px -5px rgba(0,0,0,0.5);
font-size: 20px; 
}
div.container
{
font-size : 20px;
margin-top : -30px;
}
.footer
{
margin-top : 5%;
}
label
{
float:left;
color : white;
font-family:Times New Roman,arial;
}
button{
  text-overflow: ellipsis;
  margin: 3px 0;
  padding: 6px 20px;
  font-size: 25px;
  line-height: 20px;
  height: 34px;
  background-color: rgba(0, 0, 0, 0.15);
  color: #00aeff;
  border: 1px solid rgba(255, 255, 255, 0.15);
  border-radius: 2px;
  }

.imgcontainer
{
margin-top : -20px;
}

.topnav {
  overflow: hidden;
  background-color: #333;
  height : 50px;
  
}
.topnav a {
  float: left;
  display: block;
  color: white;
 padding: 18px 14px;
  text-decoration: none;
  font-size : 20px;
}

.topnav a:hover {
  background-color: #ddd;
  color: black;
}

.topnav a.active {
    background-color: green;
    color: white;
	font-size : 20px;
	margin-left :3px;
}

.logo {

background-color: white;
	width : 100px;
	height: 50px;
	margin-bottom: -15px;
	margin-top :-16px;
	margin-left:-16px;
	margin-right : -16px;
}
a,h1
{
	color : white;
	text-decoration :none;
}
input[ type="text"],input[ type="password"]
{
font-size:22px;
font-family:Times New Roman,arial;
text-align:left ;
}
.alert-error {
  color: #f00;
  background-color: #360e10;
  box-shadow: 0 0 0 1px #551e21 inset, 0 5px 10px rgba(0, 0, 0, 0.75);
  font-size : 20px;
}
</style>
<html>
<head>
<title>User Login</title>
<head>
<body>
<nav class="topnav">
    <a href ="Homepage.php"><img class="logo" src="pageImages/logo.png"></a>
    <a class ="active" href="Homepage.php">Home</a> 
    <a href="facilities.php">Facelities</a> 
    <a href="Services.php">Services</a> 
    <a href="contectUs.php">Contact Us</a> 
    <a href="aboutUs.php">About US</a> 
    <a href="signUp.php">Create Account</a>
</nav>

<center>

 <form class = "form1" method ="POST">
 <h1 style="color :white">User Login</h1>
  <div class="alert alert-error"> <?= $_SESSION['message']?></div><br/>
  <div class="imgcontainer">
  
    <img src="pageImages/as.png" alt="Avatar" class="avatar" style = "border-radius :360px ">
  </div><br><br>

  <div class="container">
	
		<label><b>Username :</b></label><br/>
		<input type="text" required placeholder="Enter Username" name="username" size = "15px" ><br/>
		
		<label><b>CNIC :</b></label><br/>
		<input type="text" required placeholder="Enter Your CNIC" name="cnic" size = "15px" ><br/>

		<label><b>Password :</b></label><br/>
		<input type="password" required placeholder="Enter Password" name="password" size ="15px"><br/>

		<button type="submit" name="login">Login</button><br/>	
</div>
               
  <div class="footer">
   
    <span class="psw"> <a href="newPassword.php">Forget Password ?</a></span>
  </div>
</form>
</center>
</body>