<?php
$user="root";
$pass="";
$host="localhost";
$db="hms";
$con=mysqli_connect($host,$user,$pass,$db);

if(isset($_POST['login']))
{

$fname=$_POST['username'];
$pass1=$_POST['password1'];
$pass2=$_POST['password2'];
if($_POST['password1'] == $_POST['password2'])
{
		$sql = "UPDATE signup SET password='$pass1' WHERE CNIC='$fname'";

		$result = mysqli_query($con,$sql);
if($result == true)
{
//echo $result;
		?>
        <script> window.location = "login.php";</script>
        <?php
    }

}
else
{
	echo "wrong password";
}
}
?>
<style>
body
{
background-size:auto;
background-image : url("http://clevertechie.com/img/bnet-bg.jpg");
}
.form1
{
width: 300px;
height: auto;
background-color :rgba(0,0,0,0.5);
margin-top: 50px;
padding-top: 10px;
padding-left: 30px;
padding-right: 30px; 
border-radius: 15px;
font-weight: bolder;
box-shadow:inset -5px -5px rgba(0,0,0,0.5);
font-size: 20px; 
}
div.container
{
font-size : 20px;
margin-top : -30px;
}
.footer
{
margin-top : 5%;
}
label
{
float:left;
color : white;
font-family:Times New Roman,arial;
font-size :30px;
}
button{
  text-overflow: ellipsis;
  margin: 3px 0;
  margin-top : 5%;
  padding: 6px 20px;
  font-size: 25px;
  line-height: 20px;
  height: 34px;
  background-color: rgba(0, 0, 0, 0.15);
  color: #00aeff;
  border: 1px solid rgba(255, 255, 255, 0.15);
  border-radius: 2px;
  }

.imgcontainer
{
margin-top : -20px;
}

.topnav {
  overflow: hidden;
  background-color: #333;
   margin-left : 30px;
}

.topnav a {
  float: left;
  color: white;
 padding :15px 12px;
  text-decoration: none;
  font-size : 30px;
  margin-left : 30px;
}

.topnav a:hover {
  background-color: #ddd;
  color: black;
   margin-left : 30px;
}

.topnav a.active {
    background-color: green;
    color: white;
	font-size : 30px;
	 margin-left : 0px;
}
.logo {

background-color: white;
	width : 100px;
	height: 64.5px;
	margin-bottom: -15px;
	margin-top :-16px;
	margin-left:-45px;
	margin-right : -12px;
	border-radius :0px;
}
a
{
	color : white;
	text-decoration :none;
}
input[ type="text"],input[ type="password"]
{
font-size:22px;
font-family:Times New Roman,arial;
text-align:left ;
}
</style>
<html>
<head>
<title>User Login</title>
<head>
<body>
<nav class="topnav">
    <a href ="home.php"><img class="logo" src="pageImages/logo.png"></a>
    <a class ="active" href="home.php">Home</a> 
    <a href="facilities.php">Facelities</a> 
    <a href="Services.php">Services</a> 
    <a href="contectUs.php">Contact Us</a> 
    <a href="aboutUs.php">About US</a> 
	<a href="login.php">Log in</a> 
    <a href="signUp.php">Create Account</a>
</nav>

<center>

 <form class = "form1" method ="POST">
 <h1 style="color :white">Reset Password</h1>
  <div class="imgcontainer">
  
    <img src="pageImages/as.png" alt="Avatar" class="avatar" style = "border-radius :360px ">
  </div><br><br>

  <div class="container">
	
		<label><b>CNIC :</b></label><br/>
		<input type="number_format" maxlength="14" required placeholder="Enter Username" name="username" size = "20px" ><br/>

		<label><b>Password :</b></label><br/>
		<input type="password" required placeholder="Enter Password" name="password1" size ="20px"><br/>		
		
		
		<label><b>Confirm Password :</b></label><br/>
		<input type="password" required placeholder="Re-Enter Password" name="password2" size ="20px"><br/>

		<button type="submit" name ="login">Login</button><br/>	
</div>
               
</form>
</center>
</body>