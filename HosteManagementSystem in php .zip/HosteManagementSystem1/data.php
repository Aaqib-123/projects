<?php
error_reporting(0);
include'connect.php';

$room=$_POST['room'];
$rent=$_POST['rent'];
$secFee=$_POST['secFee'];
$sql="INSERT into userData(room,rent,secFee)". "values('$room','$rent','$secFee')";

	if($_POST['submit'])
	{
		if(mysqli_query($conn,$sql)== true)
		{
			echo "Data added Successfully..";
		}
		else
		{
			echo "Error..!Occured During Insertion..";
		}
	}
?>
<style>
body
{
	background-image :url(http://clevertechie.com/img/bnet-bg.jpg);
	 background-repeat: no-repeat;
    background-position: right top;
    background-attachment: fixed;
	 background-size : 1500px;
}
label
{
	color : white;
	font-size : 20px;
}

.button:hover {
    background-color: #555;
}
.topnav {
  overflow: hidden;
  background-color: #333;
  
}

.topnav a {
  float: left;
  color: white;
 padding :15px 12px;
  text-decoration: none;
  font-size : 30px;
}

.topnav a:hover {
  background-color: #ddd;
  color: black;
}

.topnav a.active {
    background-color: green;
    color: white;
	font-size : 30px;
}
.logo {

background-color: white;
	width : 100px;
	height: 64.5px;
	margin-bottom: -15px;
	margin-top :-16px;
	margin-left:-12px;
	margin-right : -12px;
	border-radius :0px;
}
h2
{
	color : white;
}
img
{
	margin-left : 60px;
	border-radius :360px;
width : 180px;
height :200px;
}
</style>

<nav class="topnav">
    <a href ="home.php"><img class="logo" src="pageImages/logo.png"></a>
    <a class ="active" href="home.php">Home</a>
    <a href="facilities.php">Facelities</a>
    <a href="Services.php">Services</a>
    <a href="contectUs.php">Contact Us</a>
    <a href="aboutUs.php">About US</a>
    <a href="login.php">Log in</a>
    <a href="userlogin.php">Create Account</a>
</nav>
<html>
<center>
<body>
<h2>ENTER THE DATA</h2>
<form action="data.php" method="POST">
<label><b>Room Number :</b></label>
<input type="text" name ="room" required  placeholder="Alocate the room Number.."/><br/><br/>
<label><b>Room Rent :</b></label>         
<input type="text" name ="rent" required  placeholder="Enter the Room rent.."/><br/><br/>
<label><b>Security Fee :</b></label>      
<input type="text" name ="secFee" required placeholder="Enter the Security Fee.."/><br/><br/>
<input type="submit" name ="submit" value="Edit"/><br/><br/>

</form>
</center>
</body>
</html>
