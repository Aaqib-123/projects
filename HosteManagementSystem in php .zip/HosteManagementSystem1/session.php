<?php
   include('config.php');
   session_start();
   
   $user_check = $_SESSION['userLogin'];
   
   $ses_sql = mysqli_query($db,"select * from userLogin where fname = '$user_check' ");
   
   $row = mysqli_fetch_array($ses_sql,MYSQLI_ASSOC);
   
   $login_session = $row['fname'];
   $login_session = $row['lname'];
   
   if(!isset($_SESSION['userLogin'])){
      header("location:profile.php");
   }
?>