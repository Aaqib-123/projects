<?php
$con = mysqli_connect('localhost' , 'root','','hms');
if(isset($_POST['btn']))
{
	$username=$_POST['username'];
	$password=$_POST['password'];
	$cnic = $_POST['cnic'];
	$sql ="SELECT * from signup where firstname = '$username' AND CNIC ='$cnic' AND password = '$password'";
	
	$result = mysqli_query($con,$sql);
	if(mysqli_num_rows($result)>0)
	{
	echo "<h2><center>Avalible Data</center></h2>";  
	while($rows=mysqli_fetch_assoc($result))
	{
		echo "ID :".$rows["id"]."</br>"."First Name :".$rows["firstname"]."<br/>"."Last Name :".$rows["lastname"]."<br/>" . "Username :".$rows["username"]."<br/>"."Email :".$rows["email"]."<br/>"."Address : " .$rows["address"]."<br/>"."Phone : ".$rows["Phone"]."<br/>"."Avatar:".$rows['avatar_path']."<br/>"."Gender :".$rows["gender"]."<br/>";
	}
}

else
{
	echo "<h2>No Data Found</h2>";
}
}
else
{
}
	

?>