package com;



import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import java.sql.*;

@ManagedBean(name = "aBean")
public class AdminBean {


    public AdminBean() {
    }

    public Admin getA() {
        return a;
    }

    public void setA(Admin a) {
        this.a = a;
    }

    Admin a;
    @PostConstruct
    public void init() {
        a = new Admin();
    }


    //  Login Method

    public String Login() {
        try {
            String driverName = "com.mysql.jdbc.Driver";
            Connection connection = null;
            connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/semester", "root", "");
            String name = a.getA_username();
            String pass= a.getA_password();
            ResultSet rs = null;

            PreparedStatement pst =  connection.prepareStatement("SELECT  from login where username = '"+name+"' and password = '"+pass+"'");

            rs = pst.executeQuery();

            if (rs.next()) {
                // pst.setString(1, this.a.getA_username());
                //pst.setString(2, this.a.getA_password());

                //result found, means valid inputs
                System.out.println("Succeeded");
                //return true;
            }
        } catch (SQLException ex) {
            System.out.println("Login error -->" + ex.getMessage());


        }

        return "main";
    }
}
