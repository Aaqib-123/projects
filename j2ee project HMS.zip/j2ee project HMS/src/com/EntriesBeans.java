package com;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by pc on 6/16/2019.
 */
@ManagedBean(name = "entriesBean")
@SessionScoped
public class EntriesBeans {
    Entries e;
    public Entries getE() {
        return e;
    }

    public void setE(Entries e) {
        this.e = e;
    }
 public    EntriesBeans()
 {

 }
    @PostConstruct
    public void init()
    {
        e=new Entries();
    }
    public String SaveToDB() throws SQLException {

        String driverName = "com.mysql.jdbc.Driver";


        try {
            Class.forName(driverName);
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }

        Connection connection = null;
        connection= DriverManager.getConnection("jdbc:mysql://localhost:3306/semester", "root", "");
        System.out.println("Opened database successfully");
        PreparedStatement pstmt=connection.prepareStatement("INSERT INTO register(newmenu,roomnumber,day,fees,roomtype) VALUES (?,?,?,?,?)");

        pstmt.setString(1, this.e.getNewMenu());
        pstmt.setString(2, this.e.getRoomnumber());

        pstmt.setString(3, this.e.getDay());
        pstmt.setString(4, this.e.getFees());
        pstmt.setString(5, this.e.getRoomtype());

        pstmt.executeUpdate();
        System.out.println("Success!");
        return "bean.xhtml?faces-redirect=true";
    }

    public List<Entries> getUserList() throws SQLException {

        String driverName = "com.mysql.jdbc.Driver";


        try {
            Class.forName(driverName);
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }

        Connection connection = null;
        connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/semester","root","");
        System.out.println("Opened database successfully");

        List<Entries> list=new ArrayList<Entries>();
        PreparedStatement pstmt=connection.prepareStatement("select * from register");
        ResultSet rs=pstmt.executeQuery();
        while (rs.next())
        {
            Entries u=new Entries();
            u.newMenu=rs.getString("newmenu");
            u.day=rs.getString("day");
            u.fees=rs.getString("fees");
            u.roomnumber=rs.getString("roomnumber");
            u.roomtype=rs.getString("roomtype");


            list.add(u);
        }
        return list;
    }

    public String DeleteUser(Entries u) throws SQLException{
        String driverName = "com.mysql.jdbc.Driver";


        try {
            Class.forName(driverName);
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }

        Connection connection = null;
        connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/semester","root","");


        List<Entries> list=new ArrayList<Entries>();
        String username=u.newMenu;
        String password=u.day;
        String jobId=u.fees;
        String name=u.roomnumber;
        String fathername=u.roomtype;

        String sql="delete from register where roomnumber='"+name+"'";
        Statement stmt=connection.createStatement();
        stmt.executeUpdate(sql);
        list.remove(u);
        System.out.print("Success!");
        return null;
    }










}




