package com;


public class Admin {
    private String a_username;
    private String a_password;
    private String a_name;
    private String a_fathername;
    private String a_email;
    private String a_phone;
    private String a_gender;
    private String a_designation;

    public String getA_username() {
        return a_username;
    }

    public void setA_username(String a_username) {
        this.a_username = a_username;
    }

    public String getA_password() {
        return a_password;
    }

    public void setA_password(String a_password) {
        this.a_password = a_password;
    }

    public String getA_name() {
        return a_name;
    }

    public void setA_name(String a_name) {
        this.a_name = a_name;
    }

    public String getA_fathername() {
        return a_fathername;
    }

    public void setA_fathername(String a_fathername) {
        this.a_fathername = a_fathername;
    }

    public String getA_email() {
        return a_email;
    }

    public void setA_email(String a_email) {
        this.a_email = a_email;
    }

    public String getA_phone() {
        return a_phone;
    }

    public void setA_phone(String a_phone) {
        this.a_phone = a_phone;
    }

    public String getA_gender() {
        return a_gender;
    }

    public void setA_gender(String a_gender) {
        this.a_gender = a_gender;
    }

    public String getA_designation() {
        return a_designation;
    }

    public void setA_designation(String a_designation) {
        this.a_designation = a_designation;
    }

    public String getA_dateofbirth() {
        return a_dateofbirth;
    }

    public void setA_dateofbirth(String a_dateofbirth) {
        this.a_dateofbirth = a_dateofbirth;
    }

    public String getA_address() {
        return a_address;
    }

    public void setA_address(String a_address) {
        this.a_address = a_address;
    }

    private String a_dateofbirth;
    private String a_address;



}
