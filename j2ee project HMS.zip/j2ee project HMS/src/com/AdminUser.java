package com;


import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;
import java.sql.*;
import java.util.Calendar;
import java.util.Date;
@ManagedBean(name = "adminBean")
@SessionScoped

public class AdminUser {
    static int id=0;
    String firstName;
    String lastName;
    Date dob;
    String address;
    String userType;
    String email;
    String ausername;
    String apassword;

    public String getApassword() {
        return apassword;
    }

    public void setApassword(String apassword) {
        this.apassword = apassword;
    }

    public String getAusername() {
        return ausername;
    }

    public void setAusername(String ausername) {
        this.ausername = ausername;
    }



    Connection con = null;
    PreparedStatement pstmt = null;
    Statement stmt = null;
    ResultSet rs = null;
    boolean flag =false;

    public static int getId() {
        return id;
    }



    public AdminUser() {
        id++;
        flag=false;
        try{
            con = new ConnectionFactory().getConnection();
            stmt = con.createStatement();}
        catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public Date getDob() {
        return dob;
    }

    public void setDob(Date dob) {
        this.dob = dob;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getUserType() {
        return userType;
    }

    public void setUserType(String userType) {
        this.userType = userType;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }



    public String validateUser()
    {
        String query="SELECT * FROM login WHERE username='"+ausername+"' AND password='"+apassword+"'";
        try{
            rs=stmt.executeQuery(query);
            while(rs.next()){
                flag=true;
            }
        }catch(Exception e){
            e.printStackTrace();
        }
        if(flag==true)
            return "main.xhtml?faces-redirect=true";
        else
            return "";
    }

    public String reg()
    {
        return "userRegisterView.xhtml?faces-redirect=true";
    }

    public void register()
    {
        String query="INSERT INTO user (userid, username, uemail, upassword, utype) VALUES (NULL, '"+ausername+"', '"+email+"', '"+apassword+"', 'customer');";
        try{
            int x=stmt.executeUpdate(query);
            if(x>0){
                flag=true;
            }
        }catch(Exception e){
            e.printStackTrace();
        }
        if(flag==true)
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "User Added", "Username: "+ausername+" Email: "+email+""));
        else
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "User Not Added", "Username: "+ausername+" Email: "+email+""));
    }
}
