package com;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

/**
 * Created by pc on 6/16/2019.
 */
@ManagedBean(name = "Bean")
@SessionScoped
public class Entries {
    String roomnumber;
    String newMenu;

    public String getRoomnumber() {
        return roomnumber;
    }

    public void setRoomnumber(String roomnumber) {
        this.roomnumber = roomnumber;
    }

    public String getNewMenu() {
        return newMenu;
    }

    public void setNewMenu(String newMenu) {
        this.newMenu = newMenu;
    }

    public String getDay() {
        return day;
    }

    public void setDay(String day) {
        this.day = day;
    }

    public String getRoomtype() {
        return roomtype;
    }

    public void setRoomtype(String roomtype) {
        this.roomtype = roomtype;
    }

    public String getFees() {
        return fees;
    }

    public void setFees(String fees) {
        this.fees = fees;
    }

    String day;
    String roomtype;
    String fees;

}
