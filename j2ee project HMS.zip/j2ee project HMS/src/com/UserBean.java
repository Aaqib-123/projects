package com;

import com.sun.faces.context.SessionMap;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;



@ManagedBean(name = "userBean")
@SessionScoped
public class UserBean
        {
            Map<String,Object> sessionMap = FacesContext.getCurrentInstance().getExternalContext().getSessionMap();
            //Map<String,String> sessionMap=FacesContext.getCurrentInstance().getExternalContext().getSessionMap();
public User getU() {
        return u;
        }
public void setU(User u) {
        this.u = u;
        }
User u;
public UserBean(){}
            @PostConstruct
            public void init()
            {
                u=new User();
            }

    public String SaveToDB() throws SQLException {

        String driverName = "com.mysql.jdbc.Driver";


        try {
            Class.forName(driverName);
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }

        Connection connection = null;
        connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/semester","root","");
        System.out.println("Opened database successfully");
        PreparedStatement pstmt=connection.prepareStatement("INSERT INTO userdetail(username,password,roomnumber,name,fathername,email,contact,gender,designation,dob,address,type) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)");

        pstmt.setString(1, this.u.getU_username());
        pstmt.setString(2, this.u.getU_password());

        pstmt.setString(3, this.u.getJobId());
        pstmt.setString(4, this.u.getU_name());
        pstmt.setString(5, this.u.getU_fatherName());
        pstmt.setString(6,this.u.getU_email());
        pstmt.setString(7,this.u.getU_phone());
        pstmt.setString(8,this.u.getU_gender());
        pstmt.setString(9,this.u.getU_designation());

        pstmt.setString(10,this.u.getU_dateOfBirth());
        pstmt.setString(11, this.u.getU_address());
        pstmt.setString(12, this.u.getU_type());
        pstmt.executeUpdate();
        System.out.println("Success!");
        return "main2.xhtml?faces-redirect=true";
    }

            public List<User> getUserList() throws SQLException {

                String driverName = "com.mysql.jdbc.Driver";


                try {
                    Class.forName(driverName);
                } catch (ClassNotFoundException e) {
                    e.printStackTrace();
                }

                Connection connection = null;
                connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/semester","root","");
                System.out.println("Opened database successfully");

                List<User> list=new ArrayList<User>();
                PreparedStatement pstmt=connection.prepareStatement("select * from userdetail");
                ResultSet rs=pstmt.executeQuery();
                while (rs.next())
                {
                    User u=new User();
                    u.u_username=rs.getString("username");
                    u.u_password=rs.getString("password");
                    u.jobId=rs.getString("roomnumber");
                    u.u_name=rs.getString("name");
                    u.u_fatherName=rs.getString("fathername");

                    u.u_email=rs.getString("email");
                    u.u_phone=rs.getString("contact");
                    u.u_gender=rs.getString("gender");

                    u.u_designation=rs.getString("designation");
                    u.u_dateOfBirth=rs.getString("dob");

                    u.u_address=rs.getString("address");
                    u.u_type=rs.getString("type");
                    list.add(u);
                }
                return list;
            }

            public String DeleteUser(User u) throws SQLException{
                String driverName = "com.mysql.jdbc.Driver";


                try {
                    Class.forName(driverName);
                } catch (ClassNotFoundException e) {
                    e.printStackTrace();
                }

                Connection connection = null;
                connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/semester","root","");


                List<User> list=new ArrayList<User>();
                String username=u.u_username;
                String password=u.u_password;
                String jobId=u.jobId;
                String name=u.u_name;
                String fathername=u.u_fatherName;
                String email=u.u_email;
                String phone=u.u_phone;
                String gender=u.u_gender;
                String designation=u.u_designation;

                String dob=u.u_dateOfBirth;
                String address=u.u_address;
                String type=u.u_type;

                String sql="delete from userdetail where name='"+name+"'"+"AND email='"+email+"'";
                Statement stmt=connection.createStatement();
                stmt.executeUpdate(sql);
                list.remove(u);
                System.out.print("Success!");
                return null;
            }





            public String EditUser(){
                FacesContext fc= FacesContext.getCurrentInstance();
                Map<String,String> params=fc.getExternalContext().getRequestParameterMap();
                String u_name=params.get("action");
                System.out.println("unames="+u_name);
                String driverName = "com.mysql.jdbc.Driver";

try {
    Connection connection = null;
    try {
        Class.forName(driverName);
    } catch (ClassNotFoundException e) {
        e.printStackTrace();
    }


    connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/semester", "root", "");
    System.out.println("Opened database successfully");
    String sql = "select * from userdetail where name ='" + u_name + "'" ;
    Statement st = connection.createStatement();
    System.out.println(sql);
   // SessionMap sessionMap=new SessionMap();
    ResultSet rs = st.executeQuery(sql);
    User u = new User();
    while (rs.next()) {
        u.setU_username(rs.getString("username"));
        u.setU_password(rs.getString("password"));
        u.setJobId(rs.getString("roomnumber"));
        u.setU_name(rs.getString("name"));
        u.setU_fatherName(rs.getString("fathername"));
        u.setU_email(rs.getString("email"));
        u.setU_phone(rs.getString("contact"));
        u.setU_gender(rs.getString("gender"));
        u.setU_designation(rs.getString("designation"));

        u.setDateOfBirth(rs.getDate("dob"));
        u.setU_address(rs.getString("address"));
        u.setU_type(rs.getString("type"));
       sessionMap.put("editUser", u);
        return "main2.xhtml?faces-redirect=true";
    }
} catch(Exception e){
                    System.out.println(e);
                }
return "main.xhtml?faces-redirect=true";
            }
            public String updateUser() {
                FacesContext fc= FacesContext.getCurrentInstance();
                Map<String,String> params=fc.getExternalContext().getRequestParameterMap();
                String u_name=params.get("action");
                System.out.println("unames="+u_name);
                String driverName = "com.mysql.jdbc.Driver";

                try {
                    Connection connection = null;
                    try {
                        Class.forName(driverName);
                    } catch (ClassNotFoundException e) {
                        e.printStackTrace();
                    }
                    User std =(User)sessionMap.get("edit");
                    PreparedStatement pstmt = connection.prepareStatement("UPDATE userdetail SET username=?,password=?,roomnumber=?,name=?,fathername=?,email=?,contact=?,gender=?,designation=?,dob=?,address=?,type=? WHERE 1")  ;
                    pstmt.setString(1, this.u.getU_username());
                    pstmt.setString(2, this.u.getU_password());

                    pstmt.setString(3, this.u.getJobId());
                    pstmt.setString(4, this.u.getU_name());
                    pstmt.setString(5, this.u.getU_fatherName());
                    pstmt.setString(6,this.u.getU_email());
                    pstmt.setString(7,this.u.getU_phone());
                    pstmt.setString(8,this.u.getU_gender());
                    pstmt.setString(9,this.u.getU_designation());

                    pstmt.setString(10,this.u.getU_dateOfBirth());
                    pstmt.setString(11, this.u.getU_address());
                    pstmt.setString(12, this.u.getU_type());
                    pstmt.executeUpdate();


                }catch (Exception e){e.printStackTrace();}
                return "/main2.xhtml?faces-redirect=true";
            }
        }
