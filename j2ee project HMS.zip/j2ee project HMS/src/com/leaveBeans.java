package com;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by pc on 6/16/2019.
 */
@ManagedBean(name = "leaveBean")
@SessionScoped
public class leaveBeans {
    public leave getL() {
        return l;
    }

    public void setL(leave l) {
        this.l = l;
    }

    leave l;
   public leaveBeans()
    {

    }
    @PostConstruct
    public void init()
    {
        l=new leave();
    }
    public String SaveToDB() throws SQLException {

        String driverName = "com.mysql.jdbc.Driver";


        try {
            Class.forName(driverName);
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }

        Connection connection = null;
        connection= DriverManager.getConnection("jdbc:mysql://localhost:3306/semester", "root", "");
        System.out.println("Opened database successfully");
        PreparedStatement pstmt=connection.prepareStatement("INSERT INTO leaveRoom(room,reason) VALUES (?,?)");

        pstmt.setString(1, this.l.getRoomnumber());
        pstmt.setString(2, this.l.getReason());



        pstmt.executeUpdate();
        System.out.println("Success!");
        return "deatile.xhtml?faces-redirect=true";
    }

    public List<leave> getUserList() throws SQLException {

        String driverName = "com.mysql.jdbc.Driver";


        try {
            Class.forName(driverName);
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }

        Connection connection = null;
        connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/semester","root","");
        System.out.println("Opened database successfully");

        List<leave> list=new ArrayList<leave>();
        PreparedStatement pstmt=connection.prepareStatement("select * from leaveroom");
        ResultSet rs=pstmt.executeQuery();
        while (rs.next())
        {
          leave u=new leave();
            u.roomnumber=rs.getString("room");
            u.reason=rs.getString("reason");



            list.add(u);
        }
        return list;
    }

    public String DeleteUser(leave u1) throws SQLException{
        String driverName = "com.mysql.jdbc.Driver";


        try {
            Class.forName(driverName);
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }

        Connection connection = null;
        connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/semester","root","");


        List<leave> list=new ArrayList<leave>();
        String username=u1.roomnumber;
        String password=u1.reason;

        String sql="delete from leaveroom where room='"+username+"'";
        Statement stmt=connection.createStatement();
        stmt.executeUpdate(sql);
        list.remove(u1);
        System.out.print("Success!");
        return null;
    }



}
