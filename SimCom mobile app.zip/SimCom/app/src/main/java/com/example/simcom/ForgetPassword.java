package com.example.simcom;

public class ForgetPassword {
    public ForgetPassword(String email) {
        this.email = email;
    }

    public String getEmail() {
        return email;
    }

    String email;

}
