package com.example.simcom;

import android.content.*;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.*;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class LoginActivity extends AppCompatActivity {

    EditText etemail,etpassword,ettype;
    Context context;
    Button login_btn;

    String Email1,Password1,Type1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        TextView forget_pass =(TextView)findViewById(R.id.forget_password);
        TextView skip_login =(TextView)findViewById(R.id.skip_login);
        TextView create_account =(TextView)findViewById(R.id.create_new_account);

        etemail=findViewById(R.id.edit_email);
        etpassword=findViewById(R.id.edit_password);
        ettype=findViewById(R.id.edit_loginType);

        login_btn =findViewById(R.id.sign_in_button);

        context = LoginActivity.this;

        login_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Email1 = etemail.getText().toString().trim();
                Password1= etpassword.getText().toString().trim();
                Type1 = ettype.getText().toString().trim();
                Call<LoginModel> call = RetrofitClient
                        .getInstance()
                        .getApi()
                        .login(Email1,Password1,Type1);

                call.enqueue(new Callback<LoginModel>() {
                    @Override
                    public void onResponse(Call<LoginModel> call, Response<LoginModel> response) {

                        LoginModel s = response.body();
                        if (s.getSuccess().equals("true")) {
                            Toast.makeText(context, s.getMessage(), Toast.LENGTH_LONG).show();
                            Intent intent = new Intent(context, HomepageActivity.class);
                            startActivity(intent);

                        }
                        else{
                            Toast.makeText(context, s.getMessage(), Toast.LENGTH_LONG).show();
                        }
                    }

                    /* Do user registration using the api call*/
                    @Override
                    public void onFailure(Call<LoginModel> call, Throwable t) {
                        Toast.makeText(context, t.getMessage(), Toast.LENGTH_LONG).show();
                    }

                });

            }
        });
    }
    public void forgetPassword(View view) {
        Intent intent = new Intent(getApplicationContext(),ForgetPasswordActivity.class);
        startActivity(intent);
    }

    public void createAccount(View view) {
        Intent intent = new Intent(getApplicationContext(),RegistrationActivity.class);
        startActivity(intent);
    }

    public void skipLogin(View view) {
       Intent intent = new Intent(getApplicationContext(),HomepageActivity.class);
       startActivity(intent);

    }
}