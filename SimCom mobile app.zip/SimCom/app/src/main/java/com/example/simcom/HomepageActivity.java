package com.example.simcom;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ListView;

public class HomepageActivity extends AppCompatActivity {

   // ViewFlipper v_flipper;
    Context context;
    ListView listView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_homepage);

        listView = findViewById(R.id.listview);
        context = HomepageActivity.this;
             /*
        int images[]={R.drawable.shop1,R.drawable.shop2,R.drawable.shop3};
        v_flipper = findViewById(R.id.flipperView);

        for(int image:images)
        {
            flipperImages(image);
        }

    }

    public void flipperImages(int images)
    {
        ImageView imageView = new ImageView(this);
        imageView.setBackgroundResource(images);
        v_flipper.addView(imageView);
        v_flipper.setFlipInterval(2500);
        v_flipper.setAutoStart(true);

        v_flipper.setOutAnimation(this,android.R.anim.slide_out_right);
        v_flipper.setInAnimation(this,android.R.anim.slide_in_left);
    }
*/
    }
        public void extended_activity (View view){
            Intent intent = new Intent(getApplicationContext(), ExtendedActivity.class);
            startActivity(intent);
        }
    public void allProducts(View view) {
        Intent intent = new Intent(getApplicationContext(),HomeActivity.class);
        startActivity(intent);
    }

    public void searchProduct(View view) {
        Intent intent = new Intent(getApplicationContext(),ProductActivity.class);
        startActivity(intent);
    }

    public void pbyc(View view) {
        Intent intent = new Intent(getApplicationContext(),PbycActivity.class);
        startActivity(intent);
    }
}
