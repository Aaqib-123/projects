package com.example.simcom;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class RegistrationActivity extends AppCompatActivity {

    EditText etname,etemail,etpassword,ettype;
    Button login;
    Context context;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);
        etname=findViewById(R.id.edit_fullname);
        etemail=findViewById(R.id.edit_email);
        etpassword=findViewById(R.id.edit_password);
        ettype=findViewById(R.id.edit_login_type);
        login=findViewById(R.id.registration_button);
        context=RegistrationActivity.this;

        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String Name = etname.getText().toString().trim();
                String Email = etemail.getText().toString().trim();
                String Password = etpassword.getText().toString().trim();
                String Type = ettype.getText().toString().trim();


                Call<LoginModel> call = RetrofitClient
                        .getInstance()
                        .getApi()
                        .register(Name,Email, Password,Type);

                call.enqueue(new Callback<LoginModel>() {
                    @Override
                    public void onResponse(Call<LoginModel> call, Response<LoginModel> response) {

                        LoginModel s = response.body();
                        if (s.getSuccess().equals("true")) {
                            Toast.makeText(context, s.getMessage(), Toast.LENGTH_LONG).show();
                            Intent intent = new Intent(context, LoginActivity.class);
                            startActivity(intent);

                        }
                        else{
                            Toast.makeText(context, s.getMessage(), Toast.LENGTH_LONG).show();
                        }
                    }

                    /* Do user registration using the api call*/
                    @Override
                    public void onFailure(Call<LoginModel> call, Throwable t) {
                        Toast.makeText(context, t.getMessage(), Toast.LENGTH_LONG).show();
                    }

                });
            }
        });
    }

    public void loginActivity(View view) {
        Intent intent = new Intent(getApplicationContext(),LoginActivity.class);
        startActivity(intent);
    }
}
