package com.example.simcom;

public class CategoriesData {
    public String getCategory_name() {
        return category_name;
    }

    public CategoriesData(String category_name) {
        this.category_name = category_name;
    }

    private String category_name;
}
