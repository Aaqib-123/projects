package com.example.simcom;

import android.content.Context;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ForgetPasswordActivity extends AppCompatActivity {

    Context context;
    EditText email;
    Button enter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forget_password);

        email = findViewById(R.id.edit_email_forget);
        enter = findViewById(R.id.forget_button);
        context=ForgetPasswordActivity.this;

        enter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email1 = email.getText().toString().trim();
                Call<ForgetPassword> call = RetrofitClient
                        .getInstance()
                        .getApi()
                        .forgetPassword(email1);

                call.enqueue(new Callback<ForgetPassword>() {
                    @Override
                    public void onResponse(Call<ForgetPassword> call, Response<ForgetPassword> response) {

                        try {
                            ForgetPassword s = response.body();
                            Toast.makeText(context, "Success", Toast.LENGTH_LONG).show();
                        } catch (Exception e) {
                            e.printStackTrace();
                        }

                    }
                    /* Do user registration using the api call*/
                    @Override
                    public void onFailure(Call<ForgetPassword> call, Throwable t) {
                        Toast.makeText(context, t.getMessage(), Toast.LENGTH_LONG).show();
                    }

                });
            }
        });
    }
}
